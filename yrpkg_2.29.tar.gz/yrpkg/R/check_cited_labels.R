check_cited_labels <-
function (reportfile, ignore = c("sec", "eq", "app")) 
{
    if (!grepl("^/|^~", reportfile)) 
        reportfile <- sprintf("%s/%s", getwd(), reportfile)
    txt <- readLines(reportfile)
    comments <- grepl("^ *%", txt)
    txt <- txt[!comments]
    inputs <- grep("\\\\input\\{", txt, value = T)
    inputs <- gsub("^ *\\\\input\\{(.*)\\}", "\\1", inputs)
    alltext <- NULL
    alllabels <- NULL
    f = inputs[4]
    for (f in inputs) {
        file <- f
        if (!grepl("^/|^~", file)) 
            file <- sprintf("%s/%s", getwd(), file)
        file <- sprintf("%s.tex", file)
        txt <- readLines(file)
        comments <- grepl("^ *%", txt) | txt == ""
        txt <- txt[!comments]
        alltext[[f]] <- txt
        labels0 <- grep("\\\\label\\{", txt)
        labels <- gsub("^ *\\\\label\\{(.*)\\}", "\\1", txt[labels0])
        c <- sapply(strsplit(labels, ":"), function(x) x[1]) %in% 
            ignore
        labels <- labels[!c]
        alllabels[[f]] <- labels
    }
    l <- unlist(alllabels)[1]
    for (l in unlist(alllabels)) {
        wh <- grep(l, unlist(alltext), value = T)
        c <- grepl("\\\\label\\{", wh)
        cited <- wh[!c]
        if (!length(cited)) 
            cat(sprintf(sprintf("Not referenced: %%%is  in  %%s\n", 
                max(nchar(unlist(alllabels)))), l, names(alltext[grep(sprintf("\\\\label\\{%s\\}", 
                l), alltext)])))
    }
}
