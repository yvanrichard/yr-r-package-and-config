killallr <-
function (user = "yvan", comps = c("jeremy", "tieke", "frank", 
    "taiko", "leon", "robin"), proc = "R") 
{
    for (cp in comps) {
        cat("*****", cp, "\n")
        cmd <- sprintf("ssh -A %1$s@%2$s \"killall %3$s -u %1$s\"", 
            user, cp, proc)
        cat(cmd, "\n")
        system(cmd, wait = T)
        cat("\n\n")
    }
    cat("Done.\n\n")
}
