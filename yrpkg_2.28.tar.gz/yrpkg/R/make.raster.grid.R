make.raster.grid <-
function (from.df, reso = NULL, xcol = NULL, ycol = NULL, projs = "+init=epsg:4326") 
{
    library(raster)
    library(rgdal)
    if (class(from.df) != "SpatialPointsDataFrame") {
        if (is.null(ycol) | is.null(xcol)) 
            stop("Need a SpatialPointsDataFrame, or ycol & xcol specified")
        from.df <- from.df[!is.na(from.df[[ycol]]) & !is.na(from.df[[xcol]]), 
            ]
        coordinates(from.df) <- eval(parse(text = sprintf("~%s+%s", 
            xcol, ycol)))
        proj4string(from.df) <- CRS(projs)
    }
    else projs <- proj4string(from.df)
    bb <- bbox(from.df)
    span <- diff(t(bb))
    if (is.null(reso)) 
        reso <- max(span)/100
    dims <- span/reso
    cellsize <- c(reso, reso)
    grid <- SpatialGrid(GridTopology(bb[, 1], cellsize, ceiling(dims)))
    proj4string(grid) <- CRS(projs)
    return(grid)
}
