myRasterize <-
function (df, valcol, fun, reso = NULL, xcol = NULL, ycol = NULL, 
    projs = "+init=epsg:4326", grid = NULL) 
{
    library(raster)
    library(rgdal)
    if (!(all(class(df) == "SpatialPointsDataFrame"))) {
        if (is.null(ycol) | is.null(xcol)) 
            stop("Need a SpatialPointsDataFrame, or ycol & xcol specified")
        df <- df[!is.na(df[[ycol]]) & !is.na(df[[xcol]]), ]
        coordinates(df) <- eval(parse(text = sprintf("~%s+%s", 
            xcol, ycol)))
        proj4string(df) <- CRS(projs)
    }
    else projs <- proj4string(df)
    if (is.null(reso) & !is.null(grid)) 
        reso <- grid@grid@cellsize[1]
    if (is.null(grid)) 
        grid <- make.raster.grid(df, reso, xcol, ycol, projs)
    rast <- rasterize(df, raster(grid), valcol, fun = fun)
    return(rast)
}
