checkgitprojects <-
function () 
{
    dirs <- system("ls -d ~/dragonfly/*/", intern = T)
    base <- getwd()
    for (d in dirs) {
        setwd(d)
        status <- system("git status", intern = T)
        if (!any(grepl("nothing to commit", status)) & !any(grepl("Not a git repository", 
            status))) {
            cat("\n######################################################################\n")
            cat("#### ", d, "\n")
            cat("######################################################################\n")
            cat(status, sep = "\n")
        }
        cat("\n")
    }
    setwd(base)
}
