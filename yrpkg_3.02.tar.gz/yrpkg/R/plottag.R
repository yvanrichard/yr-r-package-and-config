plottag <-
function (word = "observer_species", tagfile = "~/dragonfly/oreo/tags", 
    agent = "dot", tooltip_len = 10) 
{
    op <- options("useFancyQuotes")
    options(useFancyQuotes = F)
    tags <- read.table(tagfile, sep = "\t", as.is = T)
    names(tags) <- c("tag", "file", "pos")
    t <- tags[tags$tag == word, ]
    dot <- c("graph {", "ratio=auto;", "ranksep = 0.2;", "rankdir = LR;", 
        sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=\"#FFAAAA\", shape=rectangle] %s", 
            dQuote(word)))
    conns <- NULL
    files <- unique(t$file)
    files2 <- paste0(dirname(tagfile), "/", files)
    for (fi in 1:length(files)) {
        cat(fi, "\n")
        f <- files[fi]
        t1 <- t[t$file == f, ]
        filecontent <- readLines(files2[fi])
        fc <- filecontent[!grepl("^[[:blank:]]*--", filecontent)]
        t1$valid <- !grepl("^[[:blank:]]*--", filecontent[as.numeric(t1$pos)])
        creations <- which(grepl("\\bcreate.* as", fc, ignore.case = T) & 
            !grepl("^[[:blank:]]+--", fc, ignore.case = T))
        creat <- gsub(" +as", "", gsub("^[[:blank:]]*create +", 
            "", fc[creations], ignore.case = T), ignore.case = T)
        t1$clocs <- sapply(as.numeric(t1$pos), function(l) {
            max(creations[creations <= l])
        }, simplify = T)
        t1$labs <- sprintf("%s - l.%s", gsub(" +as", "", gsub("^[[:blank:]]*create +", 
            "", fc[t1$clocs], ignore.case = T), ignore.case = T), 
            t1$pos)
        if (any(valid)) {
            dot <- c(dot, sprintf("subgraph cluster%1$i {\nlabel=%2$s; style=\"rounded,filled\"; color=gray50; fillcolor=%3$s; fontcolor=black; fontsize=20;", 
                fi, dQuote(f), "gray90"))
            t1$tooltip <- NA
            for (i in which(t1$valid)) {
                l <- as.numeric(t1$pos[i])
                t1$tooltip[i] <- gsub("\"", "'", paste(gsub("^[[:blank:]]+", 
                  "&#9;&#9;&#9;&#9;", filecontent[max(1, l - 
                    tooltip_len):min(length(filecontent), l + 
                    tooltip_len)]), collapse = "&#10;"))
                conns <- c(conns, sprintf("%s -- %s;", dQuote(word), 
                  dQuote(t1$labs[i])))
                dot <- c(dot, sprintf("node [style=filled tooltip=\"%s\" URL=\"%s\"] %s;", 
                  t1$tooltip[i], files2[fi], dQuote(t1$labs[i])))
            }
            dot <- c(dot, "}")
        }
    }
    dot <- c(dot, conns, "}")
    tmpfile <- tempfile(fileext = ".dot")
    outfile <- tempfile(fileext = ".svg")
    writeLines(dot, tmpfile)
    system(sprintf("%s -Tsvg -o %s %s", agent, outfile, tmpfile))
    system(sprintf("google-chrome %s", outfile))
    options(useFancyQuotes = op)
}
