find_common_seq <-
function (v1, v2, size) 
{
    library(data.table)
    res <- NULL
    for (i in 1:(length(v1) - size)) {
        x1 <- v1[i:(i + size - 1)]
        for (j in 1:(length(v2) - size)) {
            x2 <- v2[j:(j + size - 1)]
            if (identical(x1, x2)) {
                res <- rbind(res, data.table(seq = paste(x1, 
                  collapse = ","), i = i, j = j))
            }
        }
    }
    return(res)
}
