find_common_seq1 <-
function (v, size) 
{
    library(data.table)
    res <- NULL
    for (i in 1:(length(v) - size)) {
        x1 <- v[i:(i + size - 1)]
        for (j in (i + 1):(length(v) - size)) {
            if (j != i) {
                x2 <- v[j:(j + size - 1)]
                if (identical(x1, x2)) {
                  res <- rbind(res, data.table(seq = paste(x1, 
                    collapse = ","), i = i, j = j))
                }
            }
        }
    }
    return(res)
}
