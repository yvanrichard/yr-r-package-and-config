peepinto <-
function (rdata, more = F) 
{
    e1 <- new.env()
    load(rdata, envir = e1)
    z = sapply(ls(envir = e1), function(x) object.size(get(x, 
        envir = e1)))
    z = data.frame(object = names(z), size = z, stringsAsFactors = F)
    z = z[order(z$size, decreasing = T), ]
    z$dim <- NULL
    z$length <- NULL
    z$type <- NULL
    for (i in 1:nrow(z)) {
        o <- get(z$object[i], envir = e1)
        z$dim[i] <- list(dim(o))
        z$length[i] <- length(o)
        z$type[i] <- typeof(o)
    }
    if (more) {
        z$summ <- NULL
        for (i in 1:nrow(z)) {
            o <- get(z$object[i], envir = e1)
            z$summ[i] <- list(summary(o))
        }
    }
    rownames(z) <- z$object
    return(z[, -1])
}
