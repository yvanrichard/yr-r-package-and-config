Pprint <-
function (x, sep = ",", use.quotes = T) 
{
    if (use.quotes) 
        cat(paste(sprintf("'%s'", x), collapse = sep), "\n")
    else cat(paste(sprintf("%s", x), collapse = sep), "\n")
}
