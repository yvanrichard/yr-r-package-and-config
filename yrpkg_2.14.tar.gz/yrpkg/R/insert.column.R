insert.column <-
function (df, pos, ...) 
{
    if (pos <= 1) 
        df <- cbind(..., df)
    else if (pos >= ncol(df)) 
        df <- cbind(df, ...)
    else df <- cbind(df[, 1:(pos - 1)], ..., df[, pos:ncol(df)])
    return(df)
}
