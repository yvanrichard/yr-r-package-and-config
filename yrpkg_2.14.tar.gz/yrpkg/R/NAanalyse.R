NAanalyse <-
function (df) 
{
    sumna <- apply(df, 2, function(x) sum(is.na(x)))
    propna <- sort(round(100 * sumna/nrow(df), 1), decreasing = T)
    cat("\n===", sum(propna > 0), "columns with some NAs (out of", 
        ncol(df), ",", round(100 * sum(propna > 0)/length(propna), 
            1), "%)\n")
    cat("\n=== Proportion of NAs:\n")
    print(propna[propna > 0])
    cat("\n===", sum(propna == 0), "columns without NAs:\n")
    print(names(propna[propna == 0]))
    naom <- na.omit(df)
    cat("\n===", nrow(naom), "rows without NAs (out of", nrow(df), 
        ",", round(100 * nrow(naom)/nrow(df), 1), "%)\n\n")
}
