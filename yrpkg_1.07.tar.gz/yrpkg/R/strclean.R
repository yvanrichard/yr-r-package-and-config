strclean <-
function (x) 
{
    return(gsub("[\t ]{2,}", " ", gsub("\t{2,}", "\t", gsub(" {2,}", 
        " ", gsub("^ *| *$", "", x)))))
}
