placeleg <-
function (X, Y, ...) 
{
    poss <- c("topleft", "top", "topright", "left", "center", 
        "right", "bottomleft", "bottom", "bottomright")
    d <- NULL
    pos <- poss[1]
    for (pos in poss) {
        l <- legend(pos, ..., plot = F)
        d <- c(d, sum(X >= l$rect$left & X <= (l$rect$left + 
            l$rect$w) & Y >= (l$rect$top - l$rect$h) & Y <= l$rect$top))
    }
    pos <- poss[which.min(d)]
    legend(pos, ...)
}
