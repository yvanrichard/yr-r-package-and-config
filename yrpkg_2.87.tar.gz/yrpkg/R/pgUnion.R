pgUnion <-
function (inname = "tmpshp", outname = "out_union", incol = "geom", 
    outcol = "geom", dbname = "mygis", dbuser = "dba") 
{
    system(sprintf("psql %1$s -U %6$s -c 'drop table if exists %2$s;\n                    create table %2$s as select st_multi(st_union(%3$s)) as %4$s from %5$s'", 
        dbname, outname, incol, outcol, inname, dbuser))
    return(outname)
}
