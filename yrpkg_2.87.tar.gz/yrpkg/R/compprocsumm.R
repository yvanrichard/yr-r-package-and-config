compprocsumm <-
function (comps = c("robin", "leon", "titi", "tieke", "frank", 
    "jeremy"), user = "yvan", getres = F) 
{
    res <- NULL
    cp = comps[1]
    for (cp in comps) {
        cmd <- sprintf("ssh -A %s@%s \"ps -eo \\\"%%c|%%C|%%x|%%z|%%U\\\" --no-heading | column -t\"", 
            user, cp)
        r <- system(cmd, intern = T)
        if (length(r)) {
            l <- strsplit(gsub(" +", "", r), "\\|")
            r <- as.data.frame(do.call("rbind", l), stringsAsFactors = F)
            names(r) <- c("command", "%cpu", "time", "%mem", 
                "user")
            r$computer <- cp
            r <- r[, c("computer", "command", "%cpu", "time", 
                "%mem", "user")]
            res <- rbind(res, r)
        }
    }
    res2 <- res
    for (c in 1:ncol(res)) res2[, c] <- type.convert(res2[, c], 
        as.is = T)
    res <- res2
    cat("\n\n\n***************  All processes sorted by %mem  (first 10)  ***************\n\n")
    print(head(res[order(res$"%mem", decreasing = T), ], 10))
    cat("\n\n\n***************  All processes sorted by %cpu  (first 10)  ***************\n\n")
    print(head(res[order(res$"%cpu", decreasing = T), ], 10))
    cat("\n\n\n***************  All processes sorted by cpu time  (first 10)  ***************\n\n")
    print(head(res[order(res$time, decreasing = T), ], 10))
    if (getres) 
        return(res)
}
