preview_tex <-
function (texfile, dir = ".") 
{
    if (dir != ".") {
        dir.create(dir)
        file.copy(texfile, sprintf("%s/", dir))
    }
    tex <- c("\n\\documentclass[a4paper,11pt]{article}\n\\usepackage{amsmath}\n\\usepackage{rotating}\n\\usepackage{Sweave}\n\\usepackage{lineno}\n\\usepackage{setspace}\n\\usepackage{dcolumn}\n\\usepackage{placeins}\n\\usepackage[utf8]{inputenc}\n\\newcolumntype{d}[0]{D{.}{.}{-1}}\n\n\\newcommand{\\plaintitle}{Temp output}\n\\newcommand{\\reporttitle}{Temp output}\n\\newcommand{\\pdftitle}{Temp output}\n\\newcommand{\\pdfauthors}{authors}\n\\newcommand{\\reportno}{??}\n\n\\usepackage{type1cm}\n\\usepackage{eso-pic}\n\n\\input{/dragonfly/latex/mfish/aebr.tex}\n\n\\usepackage[textsize=scriptsize]{todonotes}\n\n\\begin{document}\n", 
        sprintf("\\input{%s}", sub(".tex", "", texfile)), "\\end{document}\n")
    writeLines(tex, sprintf("%s/tex_output.tex", dir), sep = "\n")
    system(sprintf("cd %s && pdflatex tex_output && xdg-open tex_output.pdf", 
        dir))
}
