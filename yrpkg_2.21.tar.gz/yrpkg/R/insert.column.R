insert.column <-
function (df, pos, ...) 
{
    if (pos <= 1) 
        df <- cbind(..., df)
    else if (pos >= ncol(df)) 
        df <- cbind(df, ...)
    else df <- cbind(df[, 1:(pos - 1), drop = F], ..., df[, pos:ncol(df), 
        drop = F])
    return(df)
}
