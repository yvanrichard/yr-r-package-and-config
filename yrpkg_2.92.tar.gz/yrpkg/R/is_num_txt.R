is_num_txt <-
function (x) 
return(suppressWarnings(!is.na(as.numeric(x))))
