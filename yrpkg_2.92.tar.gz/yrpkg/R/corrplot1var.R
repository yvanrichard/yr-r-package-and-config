corrplot1var <-
function (dat, depvar, alpha = 0.3, psample = 1) 
{
    library(ggplot2)
    library(data.table)
    corrvars <- setdiff(names(dat)[sapply(names(dat), function(v) class(dat[[v]])) == 
        "numeric"], depvar)
    nvars <- length(corrvars)
    c <- rbindlist(lapply(corrvars, function(v) {
        d <- data.table(depvar = depvar, y = dat[[depvar]], corrvar = v, 
            x = dat[[v]])
        return(d[sample(1:nrow(d), round(psample * nrow(d)))])
    }))
    ggplot(c, aes(x = x, y = y, group = corrvar)) + geom_point(alpha = alpha) + 
        facet_wrap(~corrvar, scales = "free")
}
