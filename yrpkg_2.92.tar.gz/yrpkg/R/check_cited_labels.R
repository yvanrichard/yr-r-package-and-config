check_cited_labels <-
function (reportfile = "report.tex", ignore = c("sec", "subsec", 
    "eq", "app", "page"), debug = F, save = T) 
{
    if (!grepl("^/|^~", reportfile)) 
        reportfile <- sprintf("%s/%s", getwd(), reportfile)
    get_inputs <- function(file) {
        file <- sprintf("%s.tex", gsub("^[[:blank:]]*|[[:blank:]]*$", 
            "", sub("\\.tex$", "", file)))
        txt <- readLines(file, warn = F)
        txt <- txt[!grepl("^[[:blank:]]*%", txt)]
        inputs <- grep("\\\\input\\{", txt, value = T)
        inputs <- gsub(".*\\\\input\\{([^}]+)\\}.*", "\\1", inputs)
        subinputs <- sapply(inputs, get_inputs)
        return(as.vector(c(names(subinputs), unlist(subinputs))))
    }
    inputs <- c(reportfile, unique(get_inputs(reportfile)))
    alltext <- NULL
    alllabels <- NULL
    cat("\nGetting list of labels...\n")
    for (f in inputs) {
        if (debug) 
            cat(f, "\n")
        file <- f
        if (!grepl("^/|^~", file)) 
            file <- sprintf("%s/%s", getwd(), file)
        file <- sprintf("%s.tex", sub("\\.tex$", "", file))
        txt <- readLines(file, warn = F)
        comments <- grepl("^ *%", txt) | txt == ""
        txt <- txt[!comments]
        alltext[[f]] <- txt
        labels0 <- grep("\\\\label\\{", txt, val = T)
        labels <- gsub(".*\\\\label\\{([^}]+)\\}.*", "\\1", labels0)
        c <- sapply(strsplit(labels, ":"), function(x) x[1]) %in% 
            ignore
        labels <- labels[!c]
        alllabels[[f]] <- labels
    }
    alllabs <- do.call("rbind", sapply(names(alllabels), function(x) {
        if (length(alllabels[[x]])) 
            data.frame(file = x, label = alllabels[[x]], stringsAsFactors = F)
    }, simplify = F))
    rownames(alllabs) <- NULL
    alltext <- unlist(alltext)
    cat("\nChecking use of labels...\n")
    library(parallel)
    uncited <- mclapply(1:nrow(alllabs), function(i) {
        l <- alllabs$label[i]
        if (debug) 
            cat(l, "\n")
        cited <- grep(sprintf("ref\\{ *%s *\\}", l), alltext, 
            value = T)
        if (!length(cited)) {
            return(data.frame(file = alllabs$file[i], label = l))
        }
    }, mc.cores = 6)
    uncited <- do.call("rbind", uncited)
    uncited <- unique(uncited)
    if (save) {
        cat("\nSaving results to uncited_labels.csv...\n")
        write.csv(uncited, "uncited_labels.csv")
    }
    cat("\n\n----- Non-cited labels:\n\n")
    print(uncited)
}
