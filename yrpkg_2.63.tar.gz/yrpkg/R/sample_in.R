sample_in <-
function (x, n = 100, ...) 
{
    if (length(dim(x))) 
        stop("Not a vector")
    else return(x[sample(1:length(x), n, ...)])
}
