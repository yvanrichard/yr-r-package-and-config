sql_all_but_geom <-
function (tablename = "all_captures", compl_txt = "", schema = "public", 
    dbname = "oreo-2014v1", host = "titi", port = 5433, verbose = F) 
{
    if (grepl("\\.", tablename)) {
        schema = strsplit(tablename, "\\.")[[1]][1]
        tablename1 = strsplit(tablename, "\\.")[[1]][2]
    }
    else {
        schema = "public"
        tablename1 = tablename
    }
    library(RPostgreSQL)
    drv <- dbDriver("PostgreSQL")
    conn <- dbConnect(drv, dbname = dbname, host = host, port = port)
    cols <- rev(unlist(dbGetQuery(conn, sprintf("\nSELECT c.column_name FROM information_schema.columns As c\n            WHERE table_name = '%s' AND table_schema = '%s' AND udt_name <> 'geometry'\n", 
        gsub("[\"']", "", tablename1), schema))))
    names(cols) <- NULL
    selcols <- paste(cols, collapse = ", ")
    sqlquery <- sprintf("SELECT %s from %s %s", selcols, tablename, 
        compl_txt)
    if (verbose) 
        cat("\n", sqlquery, "\n")
    sqlres <- dbGetQuery(conn, sqlquery)
    dbDisconnect(conn)
    dbUnloadDriver(drv)
    return(sqlres)
}
