duplicated_rows <-
function (df, cols = names(df)) 
{
    id <- apply(df[, cols], 1, paste, collapse = "_")
    isdup <- duplicated(df[, cols])
    d <- df[id %in% id[isdup], ]
    return(d[order(id), ])
}
