getdefaultargs <-
function (fun) 
{
    fls <- formals(fun)
    sy <- sapply(fls, is.symbol)
    sy <- names(sy)[sy & names(sy) != "..."]
    if (length(sy)) 
        warning(sprintf("Variables not set:  %s", paste(sy, collapse = ", ")))
    for (i in 1:length(fls)) {
        if (!is.symbol(fls[[i]])) {
            val <- eval(fls[[i]])
            assign(names(fls)[i], val, envir = .GlobalEnv)
        }
    }
}
