get_in_out_from_scripts <-
function (fold = ".", returnlist = F, recursive = F) 
{
    fls <- dir(fold, pattern = "*.r$", full.names = T, recursive = recursive)
    istxt <- NULL
    for (i in 1:length(fls)) {
        a <- system(sprintf("file %s", fls[i]), intern = T)
        istxt <- c(istxt, ifelse(length(grep("text", a)), T, 
            F))
    }
    fls <- fls[istxt]
    f = fls[1]
    outlist <- NULL
    for (f in fls) {
        if (!returnlist) {
            cat("\n")
            cat(f, ":\n")
            cat(paste(rep("-", nchar(f)), collapse = ""), "\n")
        }
        sc <- readLines(f)
        sc <- sc[!grepl("^ *#", sc) & sc != ""]
        ins <- NULL
        rcsv <- grep("read.csv", sc, val = T)
        if (length(rcsv)) {
            withsq <- grepl("'.*'", rcsv)
            ins <- c(ins, gsub(".*'(.*)'.*", "\\1", rcsv[withsq]))
            withdq <- grepl("\".*\"", rcsv)
            ins <- c(ins, gsub(".*\"(.*)\".*", "\\1", rcsv[withdq]))
        }
        lds <- grep("load\\(", sc, value = T)
        if (length(lds)) {
            withsq <- grepl("'.*'", lds)
            ins <- c(ins, gsub(".*'(.*)'.*", "\\1", lds[withsq]))
            withdq <- grepl("\".*\"", lds)
            ins <- c(ins, gsub(".*\"(.*)\".*", "\\1", lds[withdq]))
        }
        outs <- NULL
        rcsv <- grep("write.csv", sc, val = T)
        if (length(rcsv)) {
            withsq <- grepl("'.*'", rcsv)
            outs <- c(outs, gsub(".*'(.*)'.*", "\\1", rcsv[withsq]))
            withdq <- grepl("\".*\"", rcsv)
            outs <- c(outs, gsub(".*\"(.*)\".*", "\\1", rcsv[withdq]))
        }
        lds <- grep("save\\(", sc, value = T)
        if (length(lds)) {
            withsq <- grepl("'.*'", lds)
            outs <- c(outs, gsub(".*'(.*)'.*", "\\1", lds[withsq]))
            withdq <- grepl("\".*\"", lds)
            outs <- c(outs, gsub(".*\"(.*)\".*", "\\1", lds[withdq]))
        }
        outlist[[f]] <- list(ins = ins, outs = outs)
        if (!returnlist & length(c(ins, outs))) {
            cat("INPUTS:\n")
            print(ins)
            cat("OUTPUTS:\n")
            print(outs)
        }
    }
    if (returnlist) 
        return(outlist)
}
