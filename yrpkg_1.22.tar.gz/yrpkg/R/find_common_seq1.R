find_common_seq1 <-
function (v, size, na.rm = T, cores = 6) 
{
    library(data.table)
    ids <- data.table(v = v, id_ori = 1:length(v))
    if (na.rm == T) 
        ids <- na.omit(ids)
    ids[, `:=`(id_new, 1:.N)]
    v <- ids[, v]
    rbindlist(mclapply(1:(length(v) - size), function(i) {
        x1 <- v[i:(i + size - 1)]
        rbindlist(lapply((i + 1):(length(v) - size + 1), function(j) {
            if (j != i) {
                x2 <- v[j:(j + size - 1)]
                if (identical(x1, x2)) {
                  return(data.table(seq = paste(x1, collapse = ","), 
                    i = ids[id_new == i, id_ori], j = ids[id_new == 
                      j, id_ori]))
                }
            }
        }))
    }, mc.cores = cores))
}
