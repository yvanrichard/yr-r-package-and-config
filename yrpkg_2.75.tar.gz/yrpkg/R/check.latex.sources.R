check.latex.sources <-
function (fold = normalizePath("."), paths.ignore = c("^/usr/|^/var/lib|^/etc/tex|sweave/|^/dragonfly|/share/"), 
    ext.ignore = c("sty", "def", "lbx", "fd", "tfm", "cfg", "bbx", 
        "cbx", "cnf", "clo", "fmt", "cls", "map", "ldf", "dbx"), 
    only = c("/"), recursive = T, save_deps = T, use.xelatex = T, 
    ignore.rnw = F, source.types = c("r")) 
{
    extension <- function(x) {
        y <- x
        c <- grepl("\\.", y)
        y[c] <- sub(".*\\.([^.]*)$", "\\1", y[c])
        y[!c & !is.na(y)] <- ""
        return(y)
    }
    alldeps <- NULL
    prevdir <- getwd()
    setwd(fold)
    if (!ignore.rnw) {
        rnw <- dir(".", "*.rnw$|*.Rnw$", recursive = recursive)
        basedir <- getwd()
        r1 = rnw[2]
        for (r1 in rnw) {
            cat("\n************  ", r1, "  ************\n")
            rdir <- dirname(r1)
            setwd(rdir)
            r2 <- basename(r1)
            r <- readLines(r2)
            c1 <- r[grepl("\\bload\\(", r) & !grepl("^[[:blank:]]*#", 
                r)]
            fs1 <- sub("load\\(['\"]+(.*)['\"]+.*", "\\1", c1)
            c2 <- r[grepl("\\bread\\.csv\\(", r) & !grepl("^[[:blank:]]*#", 
                r)]
            fs2 <- sub(".*read.csv\\(['\"]+(.*)['\"]+.*", "\\1", 
                c2)
            fs <- c(fs1, fs2)
            c <- grepl("load\\([a-zA-Z]+", fs)
            alldeps1 <- sub(".*load\\((.*).*\\).*", "\\1", fs[c])
            s <- unlist(sapply(dir(".", "*.mk.parsed"), function(mk) readLines(mk), 
                simplify = F))
            if (!is.null(s)) {
                s1 <- do.call("rbind", strsplit(s, "[[:blank:]]*=[[:blank:]]*"))
                s2 <- sapply(alldeps1, function(x) s1[which(s1[, 
                  1] %in% x), 2], simplify = F)
                fs[c] <- ifelse(sapply(s2, length), sapply(s2, 
                  "[", 1), names(s2))
            }
            cat(paste(fs, collapse = "\n"), "\n")
            fs <- normalizePath(fs)
            if (length(fs)) {
                alldeps <- rbind(alldeps, data.frame(infile = r1, 
                  dep = fs, stringsAsFactors = F))
            }
            else alldeps <- rbind(alldeps, data.frame(infile = r1, 
                dep = NA, stringsAsFactors = F))
            setwd(basedir)
            cat("\n")
        }
    }
    tex <- dir(".", "*.tex$", recursive = recursive)
    tex <- tex[!(tex %in% "aebr.tex")]
    basedir <- getwd()
    t = tex[3]
    for (t in tex) {
        cat("\n************  ", t, "  ************\n")
        tdir <- dirname(t)
        setwd(tdir)
        t2 <- basename(t)
        bt <- sub("\\.tex", "", t2)
        tmp <- readLines(t2)
        if (any(grepl("begin\\{document\\}", tmp))) {
            if (!use.xelatex) {
                s <- system(sprintf("pdflatex -recorder -interaction=nonstopmode %s", 
                  bt), intern = T)
            }
            else {
                s <- system(sprintf("xelatex -recorder -interaction=nonstopmode %s", 
                  bt), intern = T)
            }
            f <- sprintf("%s.fls", bt)
            if (file.exists(f)) {
                fls <- readLines(f)
                fls <- sapply(strsplit(fls, " "), function(x) x[2])
                fls <- sub("^\\./", "", fls)
                fls <- unique(fls)
                fls <- fls[!grepl(sprintf("^%s", bt), fls)]
                fls <- fls[!(fls %in% normalizePath(fold))]
                fs <- normalizePath(fls)
                if (length(fs)) {
                  alldeps <- rbind(alldeps, data.frame(infile = t, 
                    dep = fs, stringsAsFactors = F))
                }
                else alldeps <- rbind(alldeps, data.frame(infile = t, 
                  dep = NA, stringsAsFactors = F))
                cat(paste(fs[!(extension(fs) %in% ext.ignore) & 
                  !grepl(paths.ignore, fs)], collapse = "\n"))
                cat("\n")
            }
            else cat("fls file inexistent. There is a problem with this file...\n")
        }
        else cat("Not a master file. Skip...\n")
        setwd(basedir)
    }
    cat("\n\n")
    alldeps <- alldeps[!grepl("^[[:blank:]]*\\%", alldeps$dep), 
        ]
    alldeps$dep <- strtrim(alldeps$dep)
    alldeps$ignored <- ifelse(extension(alldeps$dep) %in% ext.ignore | 
        grepl(paths.ignore, alldeps$dep) | is.na(alldeps$dep), 
        T, F)
    alldeps <- subset(alldeps, ignored == F)
    sources <- sapply(1:nrow(alldeps), function(i) {
        cat(i, "\n")
        d <- alldeps[i, ]
        f <- basename(d$dep)
        match <- system(sprintf("grep -r --include=\"*.r\" %s .", 
            f), intern = T)
        if (length(match)) {
            m <- do.call("rbind", sapply(strsplit(match, ":"), 
                function(x) {
                  as.data.frame(rbind(x), stringsAsFactors = F)
                }, simplify = F))
            names(m) <- c("source", "call")
            m <- cbind(infile = d$infile, dep = sub(normalizePath(fold), 
                "", d$dep), m)
            m$source_mk <- sapply(m$source, function(sc) {
                fr <- basename(sc)
                matchr <- system(sprintf("grep -r --include=\"makefile\" %s .", 
                  fr), intern = T)
                if (length(matchr)) {
                  mr <- paste(unique(sapply(strsplit(matchr, 
                    ":"), "[", 1)), collapse = "; ")
                }
                else mr <- NA
                return(mr)
            })
        }
        else {
            m <- cbind(infile = d$infile, dep = sub(normalizePath(fold), 
                "", d$dep), source = NA, call = NA, source_mk = NA)
        }
        return(m)
    }, simplify = F)
    src <- do.call("rbind", sources)
    rownames(src) <- NULL
    src$loadsave <- ifelse(is.na(src$source), NA, ifelse(grepl("save\\(", 
        src$call), "save", ifelse(grepl("load\\(", src$call), 
        "load", "?")))
    if (save_deps) {
        out <- sprintf("%s/latex-deps-in-r-files.csv", fold)
        cat("Dependencies saved in", out, "\n")
        write.csv(src, out, row.names = F)
    }
    return(src)
}
