get_stats <-
function (x, na.rm = T) 
{
    return(c(mean = mean(x, na.rm = na.rm), med = median(x, na.rm = na.rm), 
        lcl = quantile(x, 0.025, names = F, na.rm = na.rm), ucl = quantile(x, 
            0.975, names = F, na.rm = na.rm)))
}
