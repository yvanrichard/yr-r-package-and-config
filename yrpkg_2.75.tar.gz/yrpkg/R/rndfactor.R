rndfactor <-
function (n = 15, nlev = 4) 
return(factor(sample(LETTERS[1:nlev], n, replace = T)))
