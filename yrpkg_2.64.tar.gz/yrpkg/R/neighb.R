neighb <-
function (x, at, window = 5, add.nas = T) 
{
    if (is.null(dim(x))) {
        if (add.nas) {
            print(x[c((at - window):(at - 1), NA, at, NA, (at + 
                1):(at + window))])
        }
        else {
            print(x[(at - window):(at + window)])
        }
    }
    else {
        if (length(dim(x) > 2)) 
            stop("Dimensions of more than 2 not treated")
        if (add.nas) {
            print(x[c((at - window):(at - 1), NA, at, NA, (at + 
                1):(at + window)), ])
        }
        else {
            print(x[(at - window):(at + window), ])
        }
    }
}
