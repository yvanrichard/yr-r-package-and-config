modifiedfiles <-
function (fold = "~/dragonfly", days = 7, type = "f", extra = "-lgo") 
{
    out <- system(sprintf("find %s -type %s -mtime -%i |xargs -r ls %s |column -t", 
        fold, type, days, extra), intern = T)
    out <- out[!grepl("\\.git", out)]
}
