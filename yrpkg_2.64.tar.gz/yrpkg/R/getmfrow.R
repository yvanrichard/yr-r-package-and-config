getmfrow <-
function (n, dim = c(7, 9)) 
{
    rat <- dim[2]/dim[1]
    d <- expand.grid(y = 1:n, x = 1:n)
    d <- d[, c("x", "y")]
    d$z <- d$x * d$y
    d <- do.call("rbind", by(d, d$x, function(x) {
        x2 <- x[x$z >= n, ]
        return(x2[which.min(x2$y), ])
    }))
    d$r <- d$y/d$x
    rr <- d[which.min(abs(d$r - rat)), ]
    return(c(rr$x, rr$y))
}
