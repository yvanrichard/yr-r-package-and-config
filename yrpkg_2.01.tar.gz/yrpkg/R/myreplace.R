myreplace <-
function (what, lookup, verbose = T, warn = T) 
{
    w = what
    lkup = matrix(lookup, ncol = 2, byrow = T)
    c = w %in% lkup[, 1]
    if (warn) {
        cond = !(lkup[, 1] %in% what)
        if (sum(cond)) 
            warning(sum(cond), " value(s) in lookup vector not in original data")
    }
    w[c] = lkup[match(w[c], lkup[, 1]), 2]
    s = sum(w != what)
    if (verbose) 
        cat("\nReplaced ", s, " values out of ", length(w), " (", 
            round(100 * s/length(w), 2), "%).\n", sep = "")
    return(w)
}
