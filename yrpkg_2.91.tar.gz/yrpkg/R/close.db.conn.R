close.db.conn <-
function () 
{
    library(RPostgreSQL)
    sapply(dbListConnections(dbDriver("PostgreSQL")), dbDisconnect)
}
