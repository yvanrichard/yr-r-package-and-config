shinyCorr <-
function (df, ...) 
{
    require(shiny)
    require(ggplot2)
    shinyApp(ui = fluidPage(sidebarLayout(sidebarPanel(width = 3, 
        uiOutput("xvar"), uiOutput("xtrans"), hr(), uiOutput("yvar"), 
        uiOutput("ytrans"), hr(), uiOutput("groupvar"), hr(), 
        uiOutput("panelvar"), uiOutput("panelscale")), mainPanel(width = 9, 
        plotOutput("theplot", height = "800px")))), server = function(input, 
        output) {
        output$xvar <- renderUI({
            selectInput("xvar", label = "X variable", choices = names(df), 
                selected = names(df)[1])
        })
        output$xtrans <- renderUI({
            selectInput("xtrans", label = "X transformation", 
                choices = c("None", "log10", "sqrt"), selected = "None")
        })
        output$yvar <- renderUI({
            selectInput("yvar", label = "Y variable", choices = names(df), 
                selected = names(df)[2])
        })
        output$ytrans <- renderUI({
            selectInput("ytrans", label = "Y transformation", 
                choices = c("None", "log10", "sqrt"), selected = "None")
        })
        output$groupvar <- renderUI({
            selectInput("groupvar", label = "Group variable", 
                choices = c(names(df), "<None>"), selected = "<None>")
        })
        output$panelvar <- renderUI({
            selectInput("panelvar", label = "Panel variable", 
                choices = c(names(df), "<None>"), selected = "<None>")
        })
        output$panelscale <- renderUI({
            selectInput("panelscale", label = "Panel scaling", 
                choices = c(`Free X & Y` = "free", `Same X` = "free_y", 
                  `Same Y` = "free_x", `Same X & Y` = "fixed"), 
                selected = "free")
        })
        plotdata <- reactive({
            if (!is.null(input$xvar)) 
                df$tmpX <- df[[input$xvar]]
            if (!is.null(input$yvar)) 
                df$tmpY <- df[[input$yvar]]
            if (!is.null(input$groupvar)) 
                if (input$groupvar != "<None>") 
                  df$tmpGroup <- df[[input$groupvar]]
                else df$tmpGroup <- NA
            if (!is.null(input$panelvar)) 
                if (input$panelvar != "<None>") 
                  df$tmpPanel <- df[[input$panelvar]]
                else df$tmpPanel <- NA
            return(df)
        })
        output$theplot <- renderPlot({
            dat <- plotdata()
            if ("tmpX" %in% names(dat) & "tmpY" %in% names(dat) & 
                "tmpGroup" %in% names(dat) & "tmpPanel" %in% 
                names(dat)) {
                if (input$groupvar != "<None>") {
                  g <- ggplot(dat, aes(x = tmpX, y = tmpY, group = tmpGroup, 
                    colour = tmpGroup))
                }
                else g <- ggplot(dat, aes(x = tmpX, y = tmpY))
                g <- g + geom_point(alpha = 0.5)
                if (input$panelvar != "<None>") 
                  g <- g + facet_wrap(~tmpPanel, scales = input$panelscale)
                if (input$xtrans == "log10") 
                  g <- g + scale_x_log10()
                if (input$ytrans == "log10") 
                  g <- g + scale_y_log10()
                if (input$xtrans == "sqrt") 
                  g <- g + scale_x_sqrt()
                if (input$ytrans == "sqrt") 
                  g <- g + scale_y_sqrt()
                if (class(dat[[input$groupvar]]) == "numeric") 
                  g <- g + scale_colour_gradientn(name = input$groupvar, 
                    colours = viridis::magma(50))
                g <- g + labs(x = input$xvar, y = input$yvar)
                return(g)
            }
        })
    })
}
