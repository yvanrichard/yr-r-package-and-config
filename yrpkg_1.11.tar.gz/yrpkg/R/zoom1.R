zoom1 <-
function (spobj, new = T, ...) 
{
    x11()
    plot(spobj, ...)
    xys <- locator(2)
    plot(spobj, xlim = c(min(xys$x), max(xys$x)), ylim = c(min(xys$y), 
        max(xys$y)), ...)
    cat(paste0("xlim=c(", min(xys$x), ",", max(xys$x), "), ylim=c(", 
        min(xys$y), ",", max(xys$y), ")\n"))
}
