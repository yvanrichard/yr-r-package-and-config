taxonomytree <-
function (spp, clean.names = T, verbose = T, debug = F) 
{
    library(taxize)
    library(data.table)
    if (clean.names) {
        sppp <- gsub("_", " ", as.character(spp))
        sppp <- sub("\\bsubsp.*$", "", sppp)
        sppp <- gsub("[0-9]", "", sppp)
        sppp <- gsub("\\(.*\\)", "", sppp)
        sppp <- gsub("\\bsp\\.", "", sppp)
        sppp <- gsub("\\b[a-zA-Z]\\b", "", sppp)
        sppp <- gsub("^[[:blank:]]+|[[:blank:]]+$", "", sppp)
    }
    else sppp <- spp
    if (verbose) 
        cat("Getting classification...\n")
    cl_ncbi <- classification(sppp, db = "ncbi")
    if (debug) 
        str(cl_ncbi)
    if (verbose) 
        cat("Completing with ITIS db...\n")
    for (c in sppp[sapply(cl_ncbi, class) != "data.frame"]) {
        cat(c, "\n")
        cl_ncbi[[c]] <- classification(c, db = "itis")[[1]]
    }
    if (verbose) 
        cat("Re-organising results...\n")
    l <- lapply(cl_ncbi, function(x) {
        if (class(x) == "data.frame") {
            y <- x[x$rank != "no rank", ]
            dt <- as.data.table(t(y$name))
            setnames(dt, names(dt), tolower(y$rank))
        }
        else {
            dt <- data.table(kingdom = NA, order = NA, family = NA, 
                genus = NA, species = NA)
        }
        return(dt)
    })
    l2 <- rbindlist(l, fill = T)
    pnas <- sapply(names(l2), function(x) sum(is.na(l2[[x]])/nrow(l2)))
    cols2keep <- names(pnas[pnas < 0.2])
    l3 <- l2[, rev(cols2keep), with = F]
    if (nrow(l3)) {
        l4 <- data.table(orig_spp = spp, l3)
        if (verbose & any(is.na(l4$class))) 
            warning("Some species may not have any classification: ", 
                paste(l4$orig_spp[is.na(l4$class)], collapse = ", "), 
                "\n")
        return(l4)
    }
    else {
        return(NULL)
    }
}
