as.mdtable <-
function (df, col.names = colnames(df), row.names = rownames(df), 
    signif = 4) 
{
    res <- NULL
    numcols <- apply(df, 2, class) %in% "numeric"
    df[, numcols] <- apply(df[, numcols], 2, function(x) signif(x, 
        signif))
    rows <- apply(df, 1, function(x) paste(x, collapse = " | "))
    res <- c(res, rows)
    if (!is.null(row.names)) 
        res <- sprintf("%s | %s", row.names, res)
    if (!is.null(col.names)) {
        if (!is.null(row.names)) {
            frst <- paste(c(" ", col.names), collapse = " | ")
            scnd <- paste(rep("-", max(nchar(res)) + 3 + max(nchar(row.names))), 
                collapse = "")
        }
        else {
            frst <- paste(col.names, collapse = " | ")
            scnd <- paste(rep("-", max(nchar(res))), collapse = "")
        }
        res <- c(frst, scnd, res)
    }
    return(paste(res, collapse = "\n"))
}
