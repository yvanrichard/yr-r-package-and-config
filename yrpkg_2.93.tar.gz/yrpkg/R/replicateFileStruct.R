replicateFileStruct <-
function (fold = ".", outdir = "~/test", overwrite = F, remove.base = T, 
    ignore = c("dead\\.letter", "ed_music", "fin_music", "Podcasts")) 
{
    op <- options("useFancyQuotes")
    options(useFancyQuotes = F)
    library(data.table)
    if (!file.exists(outdir)) 
        dir.create(outdir, recursive = T)
    fs <- normalizePath(dir(fold, recursive = T, full.names = T, 
        include.dirs = T))
    finfos <- file.info(fs)
    toign <- NULL
    for (ign in ignore) {
        toign <- c(toign, grep(ign, fs))
    }
    fs <- fs[!((1:length(fs)) %in% toign)]
    finfos <- finfos[!((1:nrow(finfos)) %in% toign), ]
    if (remove.base) {
        fs <- gsub(normalizePath(fold), "", fs)
        fs <- gsub("^/", "", fs)
    }
    fs <- paste0(outdir, "/", fs)
    dirs <- fs[finfos$isdir == T]
    dir = dirs[1]
    for (dir in dirs) {
        dir.create(dir, recursive = T, showWarnings = F)
    }
    fs <- fs[!finfos$isdir]
    for (f in fs) {
        if (!file.exists(f)) 
            r <- file.create(f, showWarnings = F)
    }
    options(useFancyQuotes = op)
}
