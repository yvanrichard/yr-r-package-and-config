Dim <-
function (dat) 
{
    dm <- dim(dat)
    if (is.null(dm)) 
        return(length(dat))
    else return(dm)
}
