applyalphagrad <-
function (colors, grad = "exp", curv = 15, inv = F, startalpha = 0, 
    endalpha = 1) 
{
    n = length(colors)
    if (curv <= 1) 
        stop("Choose a value above 1")
    if (grad == "exp") {
        alphas <- exp(seq(curv, 1, length.out = n))
    }
    else if (grad == "log") {
        alphas <- log(seq(curv, 1, length.out = n))
    }
    else alphas <- seq(1, 0, length.out = n)
    alphas <- scaleminmax(alphas, startalpha, endalpha)
    if (inv) 
        cols <- rev(alpha(colors, alphas))
    else cols <- alpha(colors, alphas)
    return(cols)
}
