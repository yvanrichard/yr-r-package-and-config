make_0_360 <-
function (polyg, split_lon = 0, namefield = "code") 
{
    library(sf)
    shp <- tempfile(fileext = ".shp")
    shp_p1 <- tempfile(fileext = ".shp")
    shp_p2 <- tempfile(fileext = ".shp")
    shp_p1_s <- tempfile(fileext = ".shp")
    shp_out_raw <- tempfile(fileext = ".shp")
    shp_out_split <- tempfile(fileext = ".shp")
    shp_out <- tempfile(fileext = ".shp")
    write_sf(polyg, shp)
    cmd <- sprintf("\nogr2ogr %2$s %1$s -clipsrc -180 -90 %11$f 90\nogr2ogr %3$s %1$s -clipsrc %11$f -90 180 90\nogr2ogr %4$s %2$s -dialect sqlite -sql \"SELECT ShiftCoords(geometry,360,0), %12$s FROM %5$s\"\nogr2ogr %6$s %3$s\nogr2ogr -update -append %6$s %4$s -nln %7$s\nogr2ogr %8$s %6$s -dialect sqlite -sql \"SELECT ST_Union(Geometry), %12$s FROM \"%7$s\" GROUP BY %12$s\"\nogr2ogr %9$s %8$s -dialect sqlite -sql \"SELECT %12$s, ST_Union(ST_Buffer(Geometry, 0.000001)) as geometry FROM \"%10$s\" GROUP BY %12$s\"\n", 
        shp, shp_p1, shp_p2, shp_p1_s, sub("\\.shp", "", basename(shp_p1)), 
        shp_out_raw, sub("\\.shp", "", basename(shp_out_raw)), 
        shp_out_split, shp_out, sub("\\.shp", "", basename(shp_out_split)), 
        split_lon, namefield)
    system(cmd)
    polyg_out <- read_sf(shp_out)
    return(polyg_out)
}
