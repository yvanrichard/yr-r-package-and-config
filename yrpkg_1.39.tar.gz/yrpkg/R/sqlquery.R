sqlquery <-
function (query, db = "oreo-2013v1", host = "titi", port = 5433) 
{
    library(RPostgreSQL)
    drv <- dbDriver("PostgreSQL")
    conn <- dbConnect(drv, dbname = db, host = host, port = port)
    tryCatch(dat <- dbGetQuery(conn, query), finally = {
        dbDisconnect(conn)
        dbUnloadDriver(drv)
    })
    dbDisconnect(conn)
    dbUnloadDriver(drv)
    return(dat)
}
