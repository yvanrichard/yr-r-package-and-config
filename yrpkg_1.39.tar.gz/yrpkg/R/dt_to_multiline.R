dt_to_multiline <-
function (dt, coords, byvars, crs = sf::NA_crs_) 
{
    library(data.table)
    library(sf)
    st_as_sf(as.data.table(st_as_sf(dt, coords = coords))[, .(geometry = list(st_cast(do.call(c, 
        geometry), "LINESTRING"))), byvars], crs = crs)
}
