settoroot <-
function () 
{
    root <- find_root_folder()
    if (length(root)) {
        setwd(root)
        cat("Working directory is now", root, "\n")
    }
    else {
        warning("Project root not found")
    }
}
