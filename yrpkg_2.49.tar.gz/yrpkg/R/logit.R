logit <-
function (x) 
{
    return(log(x/(1 - x)))
}
