is.git.tracked <-
function (f) 
{
    s <- suppressWarnings(system(sprintf("git ls-files %s", f), 
        intern = T, ignore.stderr = T))
    if (!length(s)) 
        return(F)
    else return(T)
}
