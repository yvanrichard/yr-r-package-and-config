getbibrefs <-
function (texdir = ".", overwrite = T, outbib = "bib.bib", bibfile = "~/dragonfly/bibliography/mfish.bib") 
{
    texdir <- normalizePath(texdir)
    texfiles <- grep("\\.tex$|\\.[Rr]nw$", dir(texdir), val = T)
    bib <- readLines(bibfile)
    refstarts <- grep("^[[:blank:]]*@", bib)
    bibtags <- as.character(sort(unlist(sapply(texfiles, function(tex) {
        t <- readLines(paste0(texdir, "/", tex))
        t <- gsub("\\[[^]]*\\]", "", gsub("[[:blank:]]+", " ", 
            paste(t, collapse = " ")))
        locs <- gregexpr("\\\\cite[pt]*", t)[[1]]
        if (!any(locs == -1)) {
            return(grep("_", sort(unique(gsub(" +", "", unlist(sapply(locs, 
                function(i) {
                  strsplit(sub("\\\\cite[pt]*\\{([^\\}]+)\\}.*", 
                    "\\1", substr(t, i, nchar(t))), ",")
                }, simplify = F))))), val = T))
        } else return(NULL)
    }, simplify = F))))
    cat(length(bibtags), "references used in total.\n")
    subbib <- sapply(bibtags, function(tag) {
        refstart <- grep(sprintf("\\<%s\\>", tag), bib)[1]
        if (!is.na(refstart)) {
            return(bib[refstart:(min(refstarts[refstarts > refstart]) - 
                1)])
        }
        else cat("WARNING!! Could not find ref: ", dQuote(tag), 
            "\n")
    })
    if (!file.exists(outbib) | overwrite) {
        cat(paste(unlist(subbib), collapse = "\n"), file = "bib.bib")
        cat("References exported to ", dQuote(outbib), ".\n", 
            sep = "")
    }
    else cat("File", outbib, "exists and overwrite=FALSE\n")
}
