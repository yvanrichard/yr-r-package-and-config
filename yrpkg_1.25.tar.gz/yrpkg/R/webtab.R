webtab <-
function (d, rownames = T, fontsize = "10px") 
{
    library(DT)
    headstyle <- "<span style=\"color:DarkSlateBlue;font-size:small\">%s</span>"
    rowstyle <- "<span style=\"color:DarkSlateBlue;font-size:small\">%s</span>"
    d <- as.data.frame(d)
    names(d) <- sprintf(headstyle, names(d))
    rownames(d) <- sprintf(rowstyle, rownames(d))
    datatable(d, escape = F, options = list(autoWidth = FALSE, 
        paging = FALSE, searching = TRUE, info = TRUE), rownames = rownames, 
        filter = "bottom", class = "stripe order-column hover compact", 
        extensions = c("FixedHeader")) %>% formatStyle(1:ncol(d), 
        `font-size` = fontsize)
}
