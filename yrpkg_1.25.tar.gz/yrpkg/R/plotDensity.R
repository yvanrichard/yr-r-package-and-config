plotDensity <-
function (x, normalise = F, col = "#44004444", border = "#440044AA", 
    add = F, ...) 
{
    d <- density(x)
    if (normalise) 
        d$y <- d$y/max(d$y)
    if (add == F) {
        plot(NA, xlim = range(d$x), ylim = c(0, max(d$y) * 1.04), 
            yaxs = "i", ...)
    }
    polygon(x = c(d$x, tail(d$x, 1), d$x[1]), y = c(d$y, 0, 0), 
        col = col, border = border)
}
