localc <-
function (df, row.names = T, newl.at = 100, ...) 
{
    library(data.table)
    df <- as.data.table(df)
    f <- tempfile(fileext = ".csv")
    if (!is.na(newl.at)) {
        nch <- lapply(df, function(x) max(na.omit(nchar(as.character(x)))))
        toolongcols <- names(nch[nch > newl.at])
        for (c in toolongcols) {
            df[[c]] <- as.character(df[[c]])
            toolongvals = nchar(df[[c]]) > newl.at
            df[[c]][toolongvals] <- sapply(df[[c]][toolongvals], 
                function(x) {
                  s = strsplit(x, "")[[1]]
                  s1 = grep("[[:blank:]]", s)
                  s0 = c(seq(1, nchar(x), newl.at), nchar(x))
                  i = findInterval(s1, s0, rightmost.closed = T)
                  s2 = s1[(i[-length(i)] - i[-1]) == -1]
                  s[s2] <- "\n"
                  return(paste(s, collapse = ""))
                })
        }
    }
    lstcols <- sapply(df, is.list)
    df[, `:=`(names(lstcols[lstcols == T]), NULL)]
    fwrite(df, f, row.names = row.names, ...)
    res <- system(sprintf("localc %s", f), wait = F)
}
