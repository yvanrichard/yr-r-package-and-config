simplify_str <-
function (x) 
{
    y <- strsplit(x, "")
    maxchar <- max(unlist(lapply(y, function(z) length(z))))
    y <- do.call("rbind", lapply(y, function(z) c(z, rep(NA, 
        maxchar - length(z)))))
    keep <- apply(y, 2, function(z) length(unique(z)) > 1)
    good <- apply(y[, keep, drop = F], 1, function(z) paste(na.omit(z), 
        collapse = ""))
    removed <- unique(apply(y[, !keep, drop = F], 1, function(z) paste(na.omit(z), 
        collapse = "")))
    attr(good, "removed") <- removed
    return(good)
}
