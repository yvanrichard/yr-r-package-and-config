upper1st <-
function (x) 
{
    if (is.factor(x)) 
        x0 <- levels(x)
    else x0 <- as.character(x)
    nc <- nchar(x0)
    x0[nc > 1] <- sprintf("%s%s", toupper(substr(x0[nc > 1], 
        1, 1)), substr(x0[nc > 1], 2, nchar(x0[nc > 1])))
    x0[nc == 1] <- toupper(x0[nc == 1])
    if (is.factor(x)) 
        levels(x) <- x0
    else x <- x0
    return(x)
}
