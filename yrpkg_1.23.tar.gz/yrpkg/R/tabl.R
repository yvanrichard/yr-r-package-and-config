tabl <-
function (x, sort = T, include.na = T) 
{
    if (length(x)) {
        t <- as.data.frame(table(x, useNA = ifelse(include.na, 
            "always", "ifany")), stringsAsFactors = F)
        names(t) <- c("value", "freq")
        if (sort) 
            t <- t[order(t$freq, decreasing = T), ]
        rownames(t) <- NULL
        return(t)
    }
    else stop("x is empty")
}
