make_filename <-
function (x) 
{
    gsub("[^-_a-zA-Z0-9]", "", gsub("[[:blank:]]+", "_", x))
}
