namap <-
function (dt, alpha.trans = "sqrt") 
{
    namap <- as.data.table(lapply(dt, is.na))
    namap <- namap[, .N, names(namap)][order(-N)]
    na_n <- namap$N
    namap[, `:=`(row, seq_len(.N))]
    namap <- melt(namap, id.vars = c("row", "N"), measure.vars = setdiff(names(namap), 
        c("row", "N")))
    namap[, `:=`(h, log(N + 1))]
    namapfile <- file.path(tmpfold, "na-map.png")
    g <- ggplot(namap, aes(x = variable, y = row, fill = value)) + 
        geom_tile(aes(alpha = N), size = 0.1, colour = "white") + 
        scale_fill_manual(name = "is NA?", values = c(`TRUE` = "#E41A1C", 
            `FALSE` = "#A6CEE3")) + scale_y_continuous(breaks = 1:max(namap$row), 
        labels = na_n, expand = c(0, 0), trans = "reverse") + 
        scale_x_discrete(position = "top") + scale_alpha_continuous(trans = alpha.trans, 
        guide = "none") + theme(axis.text.x.top = element_text(angle = 90, 
        hjust = 0, vjust = 0.5), panel.grid = element_blank()) + 
        labs(x = NULL, y = "No. rows")
    return(g)
}
