check_txt_num <-
function (d, details = F, maxn = 10) 
{
    check1 <- function(x, maxn = 10) {
        if (details == T & is.numeric(x)) 
            cat("ALREADY NUMERIC!\n")
        xnum <- suppressWarnings(as.numeric(as.character(x)))
        xint <- as.integer(xnum)
        couldbenum <- !(is.na(xnum) & !is.na(x))
        couldbeint <- couldbenum & (is.na(xnum) | as.numeric(xint) == 
            xnum)
        ngoodnum <- sum(couldbenum, na.rm = T)
        ngoodint <- sum(couldbeint, na.rm = T)
        n <- length(x)
        numbutnotint <- !is.na(couldbeint) & !couldbeint & couldbenum
        notgood <- sort(table(x[!couldbenum]), decr = T)
        notint <- sort(table(x[numbutnotint]), decr = T)
        if (details) {
            cat(sprintf("%i values (%0.2f%%) can be converted to numeric\n", 
                ngoodnum, 100 * ngoodnum/n))
            cat(sprintf("%i values (%0.2f%%) can be converted to integer\n\n", 
                ngoodint, 100 * ngoodint/n))
            if (any(!couldbenum)) {
                if (details) {
                  cat(sprintf("%i values (%0.2f%%) cannot be converted to numeric\n", 
                    n - ngoodnum, 100 * (n - ngoodnum)/n))
                }
                if (length(notgood) <= 20) {
                  cat("\n* All values not convertible to numeric:\n\n")
                  print(notgood)
                }
                else {
                  cat(sprintf("\n* First %i most common values not convertible to numeric:\n", 
                    maxn))
                  print(head(notgood, maxn))
                }
            }
            if (any(numbutnotint)) {
                if (length(notint) <= 20) {
                  cat("\n* All numericable values not convertible to integer:\n\n")
                  print(notint)
                }
                else {
                  cat(sprintf("\n* First %i most common numericable values not convertible to integer:\n", 
                    maxn))
                  print(head(notint, maxn))
                }
            }
        }
        exnotnum <- names(notgood)[1]
        if (length(exnotnum) == 0 | is.na(c(exnotnum, NA))[1]) 
            exnotnum <- ""
        if (nchar(exnotnum) > 15) 
            exnotnum <- paste0(substr(exnotnum, 1, 15), "...")
        if (any(couldbenum)) {
            exnotint <- names(notint)[1]
            if (length(exnotint) == 0 | is.na(c(exnotint, NA))[1]) 
                exnotint <- ""
            if (nchar(exnotint) > 8) 
                exnotint <- paste0(substr(exnotint, 1, 8), "...")
        }
        else exnotint <- ""
        return(data.table(perc_na = round(100 * mean(is.na(x)), 
            1), isnum = all(couldbenum), isint = all(couldbeint), 
            exnotnum = exnotnum, exnotint = exnotint))
    }
    if ("data.frame" %in% class(d)) {
        return(rbindlist(lapply(names(d), function(m) {
            if (details) cat("\n\n===", m, "\n\n")
            cbind(column = m, class = paste(class(d[[m]]), collapse = ","), 
                check1(d[[m]]))
        }), fill = T))
    }
    else check1(d)
}
