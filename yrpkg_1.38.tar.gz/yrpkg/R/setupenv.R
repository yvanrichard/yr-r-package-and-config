setupenv <-
function (verb = F, envs = sort(dir(".", "*.env$")), warn = T) 
{
    if (!length(envs) & warn) 
        warning("No environment file found")
    parseval <- function(x) {
        done <- any(gregexpr("\\$\\{[^\\)]+\\}", x)[[1]] == -1)
        while (!done) {
            locs <- gregexpr("\\$\\{[^\\}]+\\}", x)[[1]]
            var <- substr(x, locs[1] + 2, locs[1] + attr(locs, 
                "match.length")[1] - 2)
            repl <- get(var, .GlobalEnv)
            if (repl == "") {
                cat("\n")
                stop("Environment variable ", var, " not found in ", 
                  x)
            }
            x <- sub(sprintf("\\$\\{%s\\}", var), repl, x)
            done <- any(gregexpr("\\$\\([^\\)]+\\)", x)[[1]] == 
                -1)
        }
        return(x)
    }
    for (f in envs) {
        if (verb) 
            cat("\n=== Loading ", f, "\n")
        env <- readLines(f)
        env <- gsub("[[:blank:]]*=[[:blank:]]*", "=", gsub("[[:blank:]]+", 
            "", gsub("#.*$", "", env)))
        env <- env[env != ""]
        env <- do.call("rbind", strsplit(env, "="))
        for (i in 1:nrow(env)) {
            repl <- parseval(env[i, 2])
            if (verb) {
                cat(env[i, 1], " ")
                if (env[i, 1] %in% ls(.GlobalEnv)) 
                  prev <- get(env[i, 1])
                if (prev != repl) 
                  cat("\tOverwriting different value !!!\n\tWas:", 
                    prev, "\n\tNow:", repl, "\n")
                if (prev == repl) 
                  cat("\tOverwriting same value")
            }
            eval(parse(text = sprintf("%s = \"%s\"", env[i, 1], 
                repl)), envir = .GlobalEnv)
            if (verb) 
                cat("\tok\n")
        }
        if (verb) 
            cat("\n")
    }
}
