make.spdf <-
function (df, xcol = NULL, ycol = NULL, projs = "+init=epsg:4326", 
    verbose = F) 
{
    c <- is.na(df[[ycol]]) & is.na(df[[xcol]])
    if (sum(c) & verbose == T) 
        cat("Removed", sum(c), "rows", "out of", nrow(df), "because of NA coordinates\n")
    df <- df[!c, ]
    coordinates(df) <- eval(parse(text = sprintf("~%s+%s", xcol, 
        ycol)))
    proj4string(df) <- CRS(projs)
    return(df)
}
