col3d <-
function (x, y, z, space = "rgb") 
{
    f <- switch(space, rgb = rgb, hcl = hcl, hsv = hsv)
    return(f(scaleminmax(x), scaleminmax(y), scaleminmax(z)))
}
