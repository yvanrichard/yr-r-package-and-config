myZoom <-
function (plotfun, verbose = T) 
{
    plotfun()
    ext <- clicks2extent(verbose)
    plotfun(ext)
}
