rnd_round <-
function (K) 
{
    l <- floor(K)
    r <- K - l
    o <- rep(NA, length(K))
    rn <- runif(length(K))
    o[rn > r] <- l[rn > r]
    o[rn <= r] <- l[rn <= r] + 1
    o <- ifelse(rn > r, l, l + 1)
    return(o)
}
