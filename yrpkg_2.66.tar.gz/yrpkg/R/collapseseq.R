collapseseq <-
function (x, with.attr = F) 
{
    if (!(class(x) %in% c("numeric", "integer"))) 
        return(NA)
    if (length(x) > 1) {
        x <- sort(unique(x))
        n <- length(x)
        d <- x[2:n] - x[1:(n - 1)]
        d2 <- c(2, d)
        s <- cumsum(d2 - 1)
        r <- split(x, s)
        rs <- sapply(r, function(x) {
            nx <- length(x)
            if (nx > 1) 
                return(sprintf("%s-%s", x[1], x[nx]))
            else return(x)
        }, simplify = T)
        ns <- sapply(r, length)
        txt <- paste(rs, collapse = ",")
        if (with.attr) {
            attr(txt, "elements") <- rs
            attr(txt, "ns") <- ns
        }
        return(txt)
    }
    else {
        txt <- as.character(x)
        if (with.attr) {
            attr(txt, "elements") <- as.character(x)
            attr(txt, "ns") <- 1
        }
        return(txt)
    }
}
