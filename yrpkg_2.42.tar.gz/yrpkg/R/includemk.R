includemk <-
function (Mk = "vars.mk", warn = T, save.parsed = T) 
{
    op <- options("useFancyQuotes")
    options(useFancyQuotes = F)
    startdir <- dirname(Mk)
    getsubincl <- function(fl) {
        basedir <- dirname(fl)
        mk <- readLines(fl)
        while (any(grepl("^include +", mk))) {
            incpos <- grep("^include +", mk)[1]
            subfl <- paste0(basedir, "/", sub("^include +", "", 
                mk[incpos]))
            incmk <- getsubincl(subfl)
            mk <- c(mk[0:(incpos - 1)], incmk, mk[(incpos + 1):length(mk)])
        }
        return(mk)
    }
    mk <- getsubincl(Mk)
    mk <- mk[!grepl("^[[:blank:]]*#", mk)]
    mk <- mk[grep("=", mk)]
    mk <- gsub("\t*", "", mk)
    r <- rapply(strsplit(mk, "="), trim, how = "replace")
    if (any(duplicated(sapply(r, "[", 1)))) {
        vars <- sapply(r, "[", 1)
        stop("Duplicated entries in makefile include: ", paste(vars[duplicated(vars)], 
            collapse = ", "))
    }
    rr <- list()
    for (i in 1:length(r)) rr[[r[[i]][1]]] <- r[[i]][2]
    if (warn & any(names(rr) %in% ls(envir = .GlobalEnv))) 
        warning(sprintf("Variables %s overwritten while parsing makefile", 
            paste(names(rr)[names(rr) %in% ls(envir = .GlobalEnv)], 
                collapse = ", ")))
    if (save.parsed) 
        parsed <- mk
    for (i in 1:length(rr)) {
        c <- trim(strsplit(mk[i], "=")[[1]])
        if (length(c) != 2) 
            stop(sprintf("Problem parsing makefile. Assignment #%i non-standard", 
                i))
        if (grepl("\\$\\(.*\\)", c[2])) {
            vars <- c(sapply(regmatches(c[2], gregexpr(sprintf("\\$\\(([^\\)]+)\\)"), 
                c[2])), function(x) gsub("\\$\\((.*)\\)", "\\1", 
                x)))
            for (j in 1:length(vars)) if (vars[j] %in% ls(envir = .GlobalEnv)) 
                regmatches(c[2], regexec(sprintf("\\$\\([^\\)]+\\)"), 
                  c[2])) <- get(vars[j], envir = .GlobalEnv)
            else stop(sprintf("Problem parsing makefile. Variable %s not declared?", 
                vars[j]))
        }
        if (save.parsed) 
            parsed[i] <- paste(c, collapse = " = ")
        val <- type.convert(c[2], as.is = T)
        assign(c[1], val, envir = .GlobalEnv)
    }
    options(useFancyQuotes = op)
    if (save.parsed) 
        cat(parsed, file = paste0(Mk, ".parsed"), sep = "\n")
}
