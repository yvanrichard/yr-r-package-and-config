upper1st <-
function (x) 
{
    x1 <- strsplit(x, "")
    x <- sapply(x1, function(x) {
        x[1] <- toupper(x[1])
        return(paste(x, collapse = ""))
    })
    return(x)
}
