numlitt <-
function (x, cap = F) 
{
    if (length(x) > 1) 
        stop("More than one value for numlitt")
    if (!is.numeric(x)) 
        x <- as.numeric(x)
    if (!identical(round(x), x)) 
        stop("x is not in a an integer form")
    if (!is.finite(x)) 
        stop("x not finite")
    litt <- c("one", "two", "three", "four", "five", "six", "seven", 
        "eight", "nine", "ten", "eleven", "twelve")
    if (x == 0) {
        res <- "zero"
    }
    else if (x <= length(litt)) {
        res <- litt[x]
    }
    else res <- as.character(x)
    if (cap) 
        res <- upper1st(res)
    return(res)
}
