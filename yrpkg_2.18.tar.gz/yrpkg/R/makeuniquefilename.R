makeuniquefilename <-
function (x) 
{
    if (length(x) > 1) 
        stop("Function takes only one file name")
    ext <- extension(x)
    basefile <- sub(ext, "", x)
    f <- x
    ii <- 0
    while (file.exists(f)) {
        f <- sprintf("%s%i%s", basefile, ii, ext)
        ii <- ii + 1
    }
    return(f)
}
