runoncluster <-
function (f, x, vars2export = NULL, libs2load = NULL, clust = c(rep("robin", 
    5), rep("leon", 5), rep("frank", 3), rep("taiko", 3))) 
{
    library(snow)
    cl <- makeSOCKcluster(clust)
    clusterExport(cl, list(c("f", vars2export)))
    if (!is.null(libs2load)) 
        for (i in length(libs2load)) clusterEvalQ(cl, eval(parse(text = sprintf("library(%s)", 
            libs2load[i]))))
    res <- clusterApply(cl, x, f)
    stopCluster(cl)
}
