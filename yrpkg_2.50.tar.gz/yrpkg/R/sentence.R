sentence <-
function (x) 
{
    if (length(x) == 2) {
        sent <- paste(x, collapse = " and ")
    }
    else if (length(x) > 2) {
        sent <- paste0(paste(x[1:(length(x) - 1)], collapse = ", "), 
            ", and ", x[length(x)])
    }
    else sent <- x
    return(sent)
}
