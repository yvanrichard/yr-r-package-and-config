Q <-
function () 
{
    base::q("no")
}
