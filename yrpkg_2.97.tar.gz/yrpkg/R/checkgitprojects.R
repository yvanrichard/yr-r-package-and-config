checkgitprojects <-
function () 
{
    dirs <- system("ls -d ~/dragonfly/*/", intern = T)
    base <- getwd()
    d = dirs[40]
    for (d in dirs) {
        cat("\n######################################################################\n")
        cat("#### ", d, "\n")
        cat("######################################################################\n")
        setwd(d)
        status <- system("git status", intern = T)
        if (!any(grepl("nothing to commit", status))) 
            cat(status, sep = "\n")
        cat("\n")
    }
    setwd(base)
}
