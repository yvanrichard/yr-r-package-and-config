zoom <-
function (plotfun, new = T) 
{
    if (new | !length(dev.list())) {
        x11()
        plotfun()
    }
    xys <- locator(2)
    plotfun(xlim = c(min(xys$x), max(xys$x)), ylim = c(min(xys$y), 
        max(xys$y)))
}
