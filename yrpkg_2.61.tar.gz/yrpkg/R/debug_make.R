debug_make <-
function (makefile = "makefile") 
{
    dbg0 <- system(sprintf("make -f %s -dn", makefile), intern = T)
    dbg0 <- dbg0[(min(which(dbg0 == "")) + 2):length(dbg0)]
    ni <- gsub("^[[:blank:]]+|[[:blank:]]+$", "", dbg0)
    dbg <- gsub("`[^']+'", "'X'", ni)
    print(tabl(dbg))
    cat("\n--- Non-existent files:\n")
    g <- gsub(".*`([^']+)'.*", "\\1", grep("File .* does not exist", 
        dbg0, val = T))
    print(g)
    cat("\n--- Nothing to be done for:\n")
    g <- gsub(".*`([^']+)'.*", "\\1", grep("Nothing to be done for", 
        dbg0, val = T))
    print(g)
    cat("\n--- Must remake targets:\n")
    g <- gsub(".*`([^']+)'.*", "\\1", grep("Must remake target", 
        dbg0, val = T))
    print(g)
    cat("\n--- Prerequisite 'X' is older than target 'Y':\n")
    g <- gsub(".*`([^']+)'.*`([^']+)'.*", "'\\1'\tolder than\t'\\2'", 
        grep("Prerequisite .* is older than target .*", dbg0, 
            val = T))
    cat(g, sep = "\n")
}
