toqgis <-
function (x, plot.nz = T, plot.eez = F) 
{
    library(rgdal)
    p <- proj4string(x)
    if (class(x) == "SpatialPolygons") {
        e <- SpatialPolygonsDataFrame(x, data.frame(v = rep(NA, 
            length(x))))
        writeOGR(e, "/tmp", "x_temp", "ESRI Shapefile", overwrite_layer = T)
    }
    if (class(x) == "SpatialPolygonsDataFrame") {
        e <- x
        writeOGR(e, "/tmp", "x_temp", "ESRI Shapefile", overwrite_layer = T)
    }
    if (class(x) == "SpatialPoints") {
        e <- SpatialPointsDataFrame(x, data.frame(v = rep(NA, 
            length(x))))
        writeOGR(e, "/tmp", "x_temp", "ESRI Shapefile", overwrite_layer = T)
    }
    if (class(x) == "SpatialPointsDataFrame") {
        e <- x
        writeOGR(e, "/tmp", "x_temp", "ESRI Shapefile", overwrite_layer = T)
    }
    if (class(x) == "SpatialLines") {
        e <- SpatialLinesDataFrame(x, data.frame(v = rep(NA, 
            length(x))))
        writeOGR(e, "/tmp", "x_temp", "ESRI Shapefile", overwrite_layer = T)
    }
    if (class(x) == "SpatialLinesDataFrame") {
        e <- x
        writeOGR(e, "/tmp", "x_temp", "ESRI Shapefile", overwrite_layer = T)
    }
    if (class(x) == "RasterLayer") {
        e <- as(x, "SpatialGridDataFrame")
        writeGDAL(e, "/tmp/x_temp.img", "HFA")
    }
    if (plot.nz | plot.eez) {
        load("~/share/dragonfly/gis/nz_isl_eez.rdata")
        if (plot.nz) {
            nz <- spTransform(nz, CRS(p))
            writeOGR(nz, "/tmp", "nz_temp", "ESRI Shapefile", 
                overwrite_layer = T)
        }
        if (plot.eez) {
            eez <- spTransform(eez, CRS(p))
            writeOGR(eez, "/tmp", "eez_temp", "ESRI Shapefile", 
                overwrite_layer = T)
        }
    }
    ext <- bbox(x)
    cmd <- sprintf("qgis --nologo --noplugins --extent %f,%f,%f,%f %s /tmp/x_temp.%s %s", 
        ext[1, 1], ext[2, 1], ext[1, 2], ext[2, 2], ifelse(plot.nz, 
            "/tmp/nz_temp.shp", ""), ifelse(grepl("^Spatial", 
            class(x)) & !grepl("Gridl", class(x)), "shp", "img"), 
        ifelse(plot.eez, "/tmp/eez_temp.shp", ""))
    system(cmd, wait = F)
}
