lsmem <-
function () 
{
    z = sapply(ls(envir = .GlobalEnv), function(x) object.size(get(x, 
        envir = .GlobalEnv)))
    z = data.frame(var = names(z), size = z)
    z = z[order(z$size, decreasing = T), ]
    rownames(z) <- NULL
    return(z)
}
