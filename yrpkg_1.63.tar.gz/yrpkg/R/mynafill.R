mynafill <-
function (x, ...) 
{
    if (is.factor(x)) {
        lkup <- data.table(x = levels(x))
        lkup[, `:=`(id, .I)]
        initvec <- data.table(x = x)
        initvec[lkup, `:=`(id, i.id), on = "x"]
        initvec[, `:=`(id, nafill(id, ...))]
        initvec[lkup, `:=`(out, i.x), on = "id"]
        return(initvec$out)
    }
    else if (is.character(x)) {
        lkup <- data.table(x = unique(x))
        lkup <- lkup[!is.na(x)]
        lkup[, `:=`(id, .I)]
        initvec <- data.table(x = x)
        initvec[lkup, `:=`(id, i.id), on = "x"]
        initvec[, `:=`(id, nafill(id, ...))]
        initvec[lkup, `:=`(out, i.x), on = "id"]
        return(initvec$out)
    }
    else if (is.numeric(x)) {
        return(nafill(x, ...))
    }
    else stop("`x` needs to be either of type `character`, `factor`, or `numeric`")
}
