nearest <-
function (x, val = 0.20000000000000001) 
{
    coeff <- 1/val
    return(round(x * coeff)/coeff)
}
