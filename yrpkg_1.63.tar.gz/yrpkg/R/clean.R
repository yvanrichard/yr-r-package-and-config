clean <-
function (d, reason, cond, expr = NULL, verbose = getOption("datachanges.verbose", 
    0), intern = getOption("datachanges.internal", T), idvars = getOption("datachanges.idvars", 
    NULL)) 
{
    library(data.table)
    if (!(is.data.table(d))) 
        d <- as.data.table(d, keep.rownames = T)
    if (!(".rowid" %in% names(d))) {
        d[, `:=`(.rowid, seq_len(.N))]
    }
    if (!is.null(attr(d, "n_actions"))) {
        action_no <- attr(d, "n_actions") + 1
    }
    else action_no <- 1
    if (intern) {
        .changed <- attr(d, "datachanges")
    }
    else {
        if (!exists(".datachanges", envir = .GlobalEnv)) {
            assign(".datachanges", NULL, envir = .GlobalEnv)
            .changed <- NULL
        }
        else {
            .changed <- .datachanges
        }
        .Last <<- function() {
            fwrite(.datachanges, tempfile("datachanges-", tmpdir = getwd(), 
                ".csv"))
        }
    }
    cl <- match.call()
    now <- Sys.time()
    if (verbose > 1) {
        cat("\ncl:\n")
        str(cl)
        print(names(cl))
        cat("\n")
    }
    outl <- list()
    outl$datetime <- now
    outl$table <- deparse(substitute(d))
    outl$reason <- reason
    outl$cond <- as.character(as.expression(cl$cond))
    if (verbose > 1) 
        cat(sprintf("\n`cond`: %s\n", outl$cond), "\n")
    if (!is.null(cl$expr)) {
        if (verbose > 1) 
            cat("... Replacing\n")
        if (!(".changed" %in% names(d))) {
            d[, `:=`(.changed, "")]
        }
        l <- as.list(cl$expr)
        if (verbose > 1) {
            cat("`cl$expr`:\n")
            str(l)
        }
        if (as.character(l[[1]]) != ":=") 
            stop("Expression is not an assignment with `:=` nor a deletion with `!`")
        outl$action <- "Update"
        if (is.symbol(l[[2]])) {
            outl$field <- as.character(l[[2]])
            if (verbose > 1) 
                print(outl$field)
            if (verbose > 1) 
                print(d[eval(cl$cond)])
            outl$expr <- as.character(as.expression(l[[3]]))
            outl$.rowid <- d[eval(cl$cond), .rowid]
            outl$preval <- d[eval(cl$cond), eval(l[[2]])]
            if (verbose > 1) 
                print(outl$preval)
            invisible(d[eval(cl$cond), eval(substitute(expr))])
            d[eval(cl$cond), `:=`(.changed, "*")]
            outl$postval <- d[eval(cl$cond), eval(l[[2]])]
            if (verbose > 1) 
                print(outl$postval)
            outdt <- as.data.table(outl)
            outdt <- cbind(outdt, d[eval(cl$cond), ..idvars])
            outdt <- outdt[is.na(preval) & !is.na(postval) | 
                !is.na(preval) & is.na(postval) | preval != postval]
            if (verbose > 1) 
                print(outdt)
            if (verbose >= 1) {
                if (nrow(outdt) > 0) {
                  cat(sprintf("Cleaning #%i (%s when `%s`): %i changes to `%s`\n", 
                    action_no, reason, outl$cond, nrow(outdt), 
                    outl$field))
                }
                else {
                  cat(sprintf("Cleaning #%i (%s when `%s`): No change made to `%s`\n", 
                    action_no, reason, outl$cond, outl$field))
                }
            }
        }
        else {
            outdt <- rbindlist(lapply(2L:length(l), function(i) {
                v <- names(l)[i]
                if (verbose > 1) 
                  cat(v, "\n")
                outl1 <- copy(outl)
                outl1$field <- v
                if (verbose > 1) 
                  print(outl1$field)
                if (verbose > 1) 
                  print(d[eval(cl$cond)])
                outl1$.rowid <- d[eval(cl$cond), .rowid]
                outl1$preval <- d[eval(cl$cond), get(v)]
                outl1$expr <- as.character(as.expression(l[[i]]))
                if (verbose > 1) 
                  print(outl1$preval)
                invisible(d[eval(cl$cond), `:=`(eval(v), eval(l[[i]]))])
                d[eval(cl$cond), `:=`(.changed, "*")]
                outl1$postval <- d[eval(cl$cond), get(v)]
                if (verbose > 1) 
                  print(outl1$postval)
                outdt <- as.data.table(outl1)
                outdt <- cbind(outdt, d[eval(cl$cond), ..idvars])
                setattr(outdt, "idvars", idvars)
                outdt <- outdt[is.na(preval) & !is.na(postval) | 
                  !is.na(preval) & is.na(postval) | preval != 
                  postval]
                if (verbose > 1) 
                  print(outdt)
                if (verbose >= 1) {
                  if (nrow(outdt) > 0) {
                    cat(sprintf("Cleaning #%i (%s when `%s`): %i changes to `%s`\n", 
                      action_no, reason, outl1$cond, nrow(outdt), 
                      outl1$field))
                  }
                  else {
                    cat(sprintf("Cleaning #%i (%s when `%s`): No change made to `%s`\n", 
                      action_no, reason, outl1$cond, outl1$field))
                  }
                }
                outdt
            }))
        }
    }
    else {
        if (verbose > 1) 
            cat("... Deleting\n")
        outl$action <- "Deletion"
        outl$.rowid <- d[eval(cl$cond), .rowid]
        outdt <- as.data.table(outl)
        outdt <- cbind(outdt, d[eval(cl$cond), ..idvars])
        if (verbose > 1) 
            print(outdt)
        if (nrow(outdt) > 0) {
            if (verbose > 1) {
                print(as.character(as.expression(cl$d)))
                print(d[!(eval(cl$cond))])
            }
            if (verbose >= 1) 
                cat(sprintf("Cleaning #%i (%s when `%s`): %i rows removed\n", 
                  action_no, reason, outl$cond, nrow(outdt)))
            assign(as.character(as.expression(cl$d)), d[!(eval(cl$cond))], 
                envir = .GlobalEnv)
        }
        else if (verbose >= 1) {
            cat(sprintf("Cleaning #%i (%s when `%s`): No rows removed\n", 
                action_no, reason, outl$cond, nrow(outdt)))
        }
    }
    setattr(d, "n_actions", action_no)
    if (nrow(outdt) > 0) {
        outdt[, `:=`(change_id, action_no)]
        previdvars <- attr(.changed, "idvars")
        .changed <- rbind(.changed, outdt, fill = T)
        setattr(.changed, "idvars", unique(c(previdvars, idvars)))
        if (intern == T) {
            setattr(eval(cl$d), "datachanges", .changed)
        }
        else {
            assign(".datachanges", .changed, envir = .GlobalEnv)
        }
    }
}
