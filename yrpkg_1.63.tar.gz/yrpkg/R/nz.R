nz <-
function (type = "contour", corners = list(x = c(162, 189), y = c(-54, 
    -30)), pshift = 0.0050000000000000001, simple = F, title = NA) 
{
    if (!length(dev.list())) 
        par(mar = c(0, 0, 0, 0))
    require(maptools)
    gpclibPermit()
    minx <- min(corners$x)
    maxx <- max(corners$x)
    miny <- min(corners$y)
    maxy <- max(corners$y)
    xshift <- diff(range(corners$x)) * pshift
    yshift <- -diff(range(corners$y)) * pshift
    cols <- colorRampPalette(c("#AAAAFF", "#EEEEFF"))
    NZ <- Rgshhs("/dragonfly/gis/gshhs/gshhs_i.b", level = 1, 
        xlim = c(minx, maxx), ylim = c(miny, maxy))
    plot(NA, xlim = c(minx, maxx), ylim = c(miny, maxy), main = title)
    if (!simple) {
        load("/dragonfly/gis/r/bathy.rdata")
        if (type == "raster") {
            image(bathy$lon, bathy$lat, bathy$height, add = T, 
                col = cols(50), useRaster = T)
            plot(elide(NZ$SP, shift = c(xshift, yshift)), col = grey(0.10000000000000001), 
                border = grey(0.10000000000000001), add = T)
            plot(NZ$SP, add = T, col = grey(0.69999999999999996), 
                border = grey(0.68000000000000005))
        }
        if (type == "contour") {
            plot(elide(NZ$SP, shift = c(xshift, yshift)), col = grey(0.10000000000000001), 
                border = grey(0.10000000000000001), add = T)
            plot(NZ$SP, add = T, col = grey(0.69999999999999996), 
                border = grey(0.68000000000000005))
            contour(bathy$lon, bathy$lat, -bathy$height, levels = c(200, 
                500, 1000, 2000, 5000), col = gray(log(seq(exp(0.5 * 
                5), exp(0.84999999999999998 * 5), length.out = 5))/5), 
                add = TRUE, labcex = 0.20000000000000001, lwd = 0.5, 
                drawlabels = F)
        }
    }
    else plot(NZ$SP, col = grey(0.69999999999999996), border = grey(0.68000000000000005))
}
