optimise_y <-
function (f, target, lims, incr = 0.01, tol = 1.0000000000000001e-05, 
    ...) 
{
    xys <- NULL
    xi <- lims[1]
    ci <- lims
    yi <- f(xi, ...)
    slope <- sign(f(ci[2], ...) - f(ci[1], ...))
    dir = ifelse(sign(yi - target) == slope, -1, 1)
    samedir = 0
    steps = 0
    stillhunt = T
    first <- T
    while (stillhunt) {
        steps = steps + 1
        if (!first) {
            yi <- f(xi, ...)
        }
        else first <- F
        xys = rbind(xys, c(xi, yi, dir, incr))
        if (dir < 0 & yi < target) {
            ci[1] = xi
            stillhunt = F
        }
        if (dir > 0 & yi > target) {
            ci[2] = xi
            stillhunt = F
        }
        if (dir > 0 & yi < target) {
            ci[1] = xi
        }
        if (dir < 0 & yi > target) {
            ci[2] = xi
        }
        if (stillhunt) {
            incr = incr * (sqrt(5) + 1)/2
            xi = xi + dir * incr
        }
        else {
            incr = incr * (sqrt(5) - 1)/2
            dir = -1 * dir
            xi = xi + dir * incr
        }
    }
    while (abs(yi - target) > tol & incr > 9.9999999999999995e-07 & 
        incr != tol & steps < 666) {
        steps = steps + 1
        yi <- f(xi, ...)
        xys <- rbind(xys, c(xi, yi, dir, incr))
        incr <- incr * (sqrt(5) - 1)/2
        dir = -sign(yi - target)
        ci[ifelse(dir > 0, 1, 2)] <- xi
        xi = xi + dir * incr
    }
    xys = cbind(xys, xys[, 2] - target)
    colnames(xys) <- c("x", "y", "dir", "incr", "dist")
    if (xys[steps, "dist"] > tol) 
        warning("Final accuracy greater than specified tolerance")
    return(list(x = xys[steps, "x"], acc = xys[steps, "dist"], 
        step = xys))
}
