groomplot <-
function (d, ids = NULL, plotly = F) 
{
    library(ggplot2)
    grooms <- attr(d, "grooming")
    if (is.null(ids)) 
        ids <- grooms[, sort(unique(.rowid))]
    if (!is.null(grooms)) {
        grooms <- grooms[.rowid %in% ids]
        grooms[, `:=`(step, rleid(table, reason, action, datetime))]
        dels <- grooms[action == "Deletion"]
        adddels <- grooms[, .N, .(table, .rowid, par)][dels, 
            on = c("table", ".rowid")]
        adddels[, `:=`(nopar, all(is.na(par))), .(table, .rowid)]
        adddels <- adddels[!(is.na(par) & nopar == F)]
        adddels <- adddels[, .(datetime, table, .rowid, reason, 
            cond, action, par, step)]
        grooms <- rbind(grooms[action != "Deletion"], adddels, 
            fill = T)
        setorder(grooms, table, .rowid, par, step)
        grooms[is.na(par), `:=`(par, "all")]
        grooms[, `:=`(pch, fifelse(action == "Update", 16, 4))]
        grooms[, `:=`(col, fifelse(action == "Update", "#377EB8", 
            "#E41A1C"))]
        grooms[, `:=`(lab, fifelse(action == "Update", sprintf("Reason: %s\nFor: %s\nChanged from: %s to %s\nat %s", 
            reason, cond, preval, postval, datetime), sprintf("Reason: %s\nFor: %s\nDeleted\nat %s", 
            reason, cond, datetime)))]
        g <- ggplot() + geom_line(data = grooms, aes(x = step, 
            y = par, text = lab), colour = "#377EB8", size = 1) + 
            geom_point(data = grooms, aes(x = step, y = par, 
                shape = pch, colour = col, text = lab), size = 5, 
                stroke = 2) + scale_shape_identity() + scale_color_identity() + 
            facet_wrap(~.rowid, ncol = 1, scales = "free_y", 
                strip.position = "right", dir = "v") + labs(x = "Grooming step", 
            y = "Field") + theme_light() + theme(legend.position = "none", 
            strip.text.y = element_text(angle = 0, colour = "black"), 
            strip.background.y = element_rect(colour = "grey50", 
                fill = "grey95"))
        if (plotly) {
            plotly::ggplotly(g)
        }
        else return(g)
    }
}
