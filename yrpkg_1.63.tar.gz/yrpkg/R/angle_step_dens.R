angle_step_dens <-
function (angle, step, angle_bins = 12, step_bins = 20, range_step = range(step), 
    transformation = I, col.trans = function(x) log(x + 0.050000000000000003), 
    by.bins = NULL) 
{
    nbins <- length(unique(by.bins))
    nw <- ceiling(sqrt(nbins))
    nr <- ceiling(nbins/nw)
    if (!is.null(by.bins) & length(unique(by.bins)) > 30) 
        stop("Too many `by.bins` values. Try with less bins")
    angle <- angle + pi/2
    xy <- function(step, angle) {
        cbind(step * Re(exp((0 + (0+1i)) * angle)), step * Im(exp((0 + 
            (0+1i)) * angle)))
    }
    allxy <- xy(transformation(step), angle)
    lims <- apply(allxy, 2, range)
    plt <- function(angle1, step1, main = "") {
        smoothScatter(xy(transformation(step1), angle1), colramp = function(n) rev(terrain.colors(n)), 
            transformation = function(x) col.trans(x), axes = F, 
            postPlotHook = NULL, xlab = "", ylab = "", asp = 1, 
            xlim = lims[, 1], ylim = lims[, 2])
        axis(2, transformation(seq(0, range_step[2], length.out = 10)))
        text(mean(par("usr")[1:2]), par("usr")[3], expression(pi), 
            pos = 3)
        text(mean(par("usr")[1:2]), par("usr")[4], expression(0), 
            pos = 1)
        text(par("usr")[2], mean(par("usr")[3:4]), expression(-pi/2), 
            pos = 2)
        text(par("usr")[1], mean(par("usr")[3:4]), expression(pi/2), 
            pos = 4)
        points(0, 0, pch = "+")
        text(mean(par("usr")[1:2]), par("usr")[4], main, adj = c(0.5, 
            1.5))
    }
    oldpar <- par()
    if (!is.null(by.bins)) {
        par(mfrow = c(nr, nw), mar = c(0, 0, 0, 0))
        for (i in 1:nbins) {
            c <- by.bins %in% unique(by.bins)[i]
            angle1 <- angle[c]
            step1 <- step[c]
            plt(angle1, step1, main = unique(by.bins)[i])
        }
    }
    else {
        par(mar = c(0, 0, 0, 0))
        plt(angle, step)
    }
}
