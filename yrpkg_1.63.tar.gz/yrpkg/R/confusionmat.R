confusionmat <-
function (actual, pred) 
{
    actual <- ifelse(actual == "y", 1L, 0L)
    pred <- ifelse(pred == "y", 1L, 0L)
    TP <- sum(actual == 1L & pred == 1L)
    FP <- sum(actual == 0L & pred == 1L)
    TN <- sum(actual == 0L & pred == 0L)
    FN <- sum(actual == 1L & pred == 0L)
    ccr <- (TP + TN)/(TP + TN + FP + FN)
    precision <- TP/(TP + FP)
    recall <- TP/(TP + FN)
    kappa <- cohens_kappa(TP, FN, FP, TN)
    list(TP = TP, FP = FP, TN = TN, FN = FN, ccr = ccr, precision = precision, 
        recall = recall, kappa = kappa)
}
