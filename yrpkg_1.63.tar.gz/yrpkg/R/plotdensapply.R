plotdensapply <-
function (y, by, col = "red", alph = 0.5, col.border = NULL, 
    xmin = NULL, at = NULL, ylevels = NULL, ylab = NA, cap1st = T, 
    gridx = 0, gridy = 0, gridcol = grey(0.80000000000000004), 
    ltxtcex = 1, ...) 
{
    if (!is.factor(by)) 
        by <- factor(by, levels = sort(unique(by)))
    by <- factor(by, levels = rev(levels(by)))
    spp <- levels(by)
    nspp <- nlevels(by)
    dd <- tapply(y, by, density)
    minx <- min(sapply(dd, function(x) min(x$x)))
    maxx <- max(sapply(dd, function(x) max(x$x)))
    rngx <- extendrange(c(minx, maxx), f = 0.040000000000000001)
    plot(NA, xlim = switch(is.null(xmin) + 1, c(xmin, rngx[2]), 
        rngx), ylim = c(0, nspp + 1), ylab = ylab, yaxs = "i", 
        xaxs = "i", yaxt = "n", ...)
    grid(gridx, gridy, gridcol)
    if (is.null(at)) 
        at <- 1:nspp
    if (length(at) != nspp) 
        stop("Length of \"at\" does not match that of levels of \"by\"")
    if (length(col) == 1) 
        col <- rep(col, nspp)
    if (is.null(col.border)) 
        col.border <- col
    col <- rev(col)
    col.border <- rev(col.border)
    for (di in 1:nspp) {
        d1 <- dd[[di]]
        d1$y2 <- d1$y/max(d1$y)
        polygon(c(d1$x, rev(d1$x)), 0.5 * c(d1$y2, -rev(d1$y2)) + 
            at[di], col = alpha(col[di], alph), border = col.border[di], 
            lwd = 0.5)
    }
    if (is.null(ylevels)) 
        ylevels <- spp
    z <- sapply(tapply(ylevels, at, unique), function(x) paste(x, 
        collapse = ","))
    ylev2 <- z
    at2 <- as.numeric(names(z))
    if (cap1st) 
        ylev2 <- upper1st(ylev2)
    mtext(ylev2, 2, at = at2, las = 1, line = 0.5, cex = ltxtcex)
}
