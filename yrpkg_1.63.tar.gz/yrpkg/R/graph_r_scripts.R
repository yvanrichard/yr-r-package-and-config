graph_r_scripts <-
function (fold = ".", recursive = T) 
{
    fold <- sub("^\\.", getwd(), fold)
    fold <- path.expand(fold)
    opt <- options("useFancyQuotes")
    options(useFancyQuotes = FALSE)
    inout <- get_in_out_from_scripts(fold, recursive = recursive)
    scripts <- names(inout)
    ins <- sapply(inout, function(x) x$ins)
    outs <- sapply(inout, function(x) x$outs)
    nodes <- dQuote(na.omit(c(unlist(ins), unlist(outs))))
    rnodes <- dQuote(scripts)
    gf <- "digraph G {\nnodesep=1; ranksep=1; ratio=\"compress\"; size=\"100,100\"; spline=true; \n"
    gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=filled, fillcolor=grey, shape=rectangle] %s;", 
        paste(nodes, collapse = " ")))
    gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=filled, fillcolor=yellow, shape=rectangle] %s;", 
        paste(rnodes, collapse = " ")))
    i = 2
    for (i in 1:length(inout)) {
        op <- inout[[i]]
        if (!is.null(op$ins)) 
            gf <- c(gf, sprintf("{%s} -> %s;", paste(dQuote(op$ins), 
                collapse = "; "), dQuote(names(inout[i])), collapse = "\\n"))
        if (!is.null(op$outs)) 
            gf <- c(gf, sprintf("%s -> {%s};", dQuote(names(inout[i])), 
                paste(dQuote(op$outs), collapse = "; ")))
    }
    gf <- c(gf, "}")
    dotfile <- sprintf("%s/graph-r-scripts.dot", fold)
    pdffile <- sub("\\.dot", ".pdf", dotfile)
    cat(gf, sep = "\n", file = dotfile)
    options(useFancyQuotes = opt)
    uffile <- sub("\\.dot", "_uf.dot", dotfile)
    system(sprintf("unflatten %s -o %s", dotfile, uffile))
    system(sprintf("neato -Tpdf %s -o %s", uffile, pdffile))
    system(sprintf("xdot %s", uffile), wait = F)
}
