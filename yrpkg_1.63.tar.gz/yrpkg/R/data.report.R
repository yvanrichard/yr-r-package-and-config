data.report <-
function (dt) 
{
    library(data.table)
    library(inspectdf)
    library(magrittr)
    rmdfile <- tempfile(fileext = ".rmd")
    tmpfile <- tempfile(fileext = ".rds")
    saveRDS(dt, tmpfile)
    dtname <- deparse(substitute(dt))
    Sys.setenv(DF_TMPFILE = tmpfile)
    Sys.setenv(DF_NAME = dtname)
    cat("---\ntitle: Data report for `r Sys.getenv(\"DF_NAME\")`\nauthor: \n  - name: \"Y Richard\"\n    affiliation: \"http://www.dragonfly.co.nz\"\ndate: \"`r Sys.Date()`\"\noutput:\n  rmdformats::readthedown:\n    mathjax: null\n    use_bookdown: false\n    lightbox: true\n    thumbnails: false\n    gallery: true\n    toc_depth: 3\n    toc_float:\n      collapsed: false\n      smooth_scoll: true\nmode: selfcontained\n---\n\n```{r, echo=F}\nlibrary(rmarkdown)\nlibrary(knitr)\nlibrary(DT)\nlibrary(data.table)\nlibrary(kableExtra)\nlibrary(inspectdf)\n\nopts_chunk$set(message = FALSE, echo = FALSE, warning = FALSE, error = FALSE, tidy = FALSE, cache = FALSE)\n\ndat <- readRDS(Sys.getenv(\"DF_TMPFILE\"))\n\n```\n\n# Summary\n\n```{r, echo=F}\nsummary(dat)\n```\n\n## Head\n\n```{r, echo=F}\nhead(dat)\n```\n\n## Random sample\n\n```{r, echo=F}\nsample_df(dat)\n```\n\n## Tail\n\n```{r, echo=F}\ntail(dat)\n```\n\n<!-- ```{r, echo=F, cache=F} -->\n<!-- x <- kable(ocapt_summ,  -->\n<!-- \tdigits = c(NA, rep(0, 7)), booktabs = T, align = \"lrrrrrrr\", format = \"html\", -->\n<!-- \t\t   format.args=list(big.mark = \" \")) %>% -->\n<!--     kable_styling(bootstrap_options = c(\"condensed\", \"hover\"), full_width=F, font_size = 4) -->\n<!-- x <- add_header_above(x, c(\" \", \" \", \"Trawl\" = 4, \"Longline\" = 2)) -->\n<!-- x <- gsub(\"#ddd\", \"#bbb\", x) -->\n<!-- x <- scroll_box(x, height = \"550px\") -->\n<!-- print(x) -->\n<!-- ``` -->\n\n# Types\n\n```{r}\ninspect_types(dat) %>% show_plot()\n```\n\n# Memory and rows\n\n```{r}\ninspect_mem(dat) %>% show_plot()\n```\n\n# Missing values\n\n```{r}\ninspect_na(dat) %>% show_plot()\n```\n\n# Numeric values\n\n```{r}\ninspect_num(dat) %>% show_plot()\n```\n\n# Categorical values\n\n```{r}\ninspect_imb(dat) %>% show_plot()\n```\n\n```{r}\ninspect_cat(dat) %>% show_plot()\n```\n\n# Correlations\n\n```{r}\ninspect_cor(dat) %>% show_plot()\n```\n\n", 
        file = rmdfile)
    out <- rmarkdown::render(rmdfile)
    browseURL(out)
}
