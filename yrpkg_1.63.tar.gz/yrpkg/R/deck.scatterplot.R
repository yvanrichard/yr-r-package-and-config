deck.scatterplot <-
function (dt, xvar, yvar, colvar = NULL, tooltipvar = NULL, zoom = NULL, 
    width = 1000, height = 800, opacity = 0.80000000000000004) 
{
    d <- copy(dt)
    d[, `:=`(deckx, get(xvar))]
    d[, `:=`(decky, get(yvar))]
    d[, `:=`(deckcol, get(colvar))]
    d[, `:=`(decktip, get(tooltipvar))]
    d <- d[, .(deckx, decky, deckcol, decktip)]
    library(deckgl)
    properties <- list(getPosition = get_position("deckx", "decky"))
    if (!is.null(colvar)) {
        properties[["getColor"]] <- get_color_to_rgb_array("deckcol")
        properties[["getFillColor"]] <- get_color_to_rgb_array("deckcol")
    }
    if (!is.null(tooltipvar)) {
        properties[["getTooltip"]] <- JS("object =>`${object.decktip}`")
    }
    xm <- d[, median(deckx, na.rm = T)]
    ym <- d[, median(decky, na.rm = T)]
    deck <- deckgl(latitude = ym, longitude = xm, width = width, 
        height = height, style = list(background = "white")) %>% 
        add_scatterplot_layer(data = d, properties = properties, 
            getRadius = 500, radiusScale = 18, radiusMinPixels = 3, 
            radiusMaxPixels = 10, opacity = opacity)
}
