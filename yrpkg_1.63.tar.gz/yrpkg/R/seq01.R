seq01 <-
function (range, n = 6) 
{
    x <- seq(range[1], range[2], length.out = n)
    while (any(x < 0 | x > 1)) {
        x[x > 1] <- x[x > 1] - 1
        x[x < 0] <- x[x < 0] + 1
    }
    x
}
