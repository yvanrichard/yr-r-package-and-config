tile <-
function (n = 2, ratio = 0.80000000000000004, screen.size = c(1920, 
    1080), res = c(92, 91), smar = c(50, 50), dec = c(10, 30), 
    clean = T) 
{
    if (clean) {
        graphics.off()
        dn <- 2
    }
    else {
        if (!is.null(dev.list())) 
            dn <- max(dev.list())
        else dn <- 2
    }
    lay <- getmfrow(n, dim = c(1, ratio))
    W <- (screen.size[1] - smar[1] - lay[1] * dec[1])/lay[1]
    H <- (screen.size[2] - smar[2] - (lay[2] - 1) * dec[2])/lay[2]
    if (!is.na(ratio)) 
        H <- min(ratio * W, H)
    xposs <- smar[1] + ((1:lay[1]) - 1) * W + ((1:lay[1]) - 1) * 
        dec[1]
    yposs <- ((1:lay[2]) - 1) * H + ((1:lay[2]) - 1) * dec[2]
    ni = 0
    for (yi in 1:lay[2]) for (xi in 1:lay[1]) {
        ni <- ni + 1
        if (ni <= n) 
            x11(xpos = xposs[xi], ypos = yposs[yi], width = W/res[1], 
                height = H/res[2])
    }
    dev.set(dn)
}
