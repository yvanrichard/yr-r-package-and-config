myreplace <-
function (what, lookup, warn.not.in.data = T, warn.not.in.lookup = T, 
    verbose = T) 
{
    w <- what
    lkup <- matrix(lookup, ncol = 2, byrow = T)
    if (warn.not.in.lookup) {
        cond <- !(lkup[, 1] %in% what)
        if (any(cond)) 
            warning(sum(cond), " value(s) in lookup vector not in original data")
    }
    if (warn.not.in.data) {
        cond <- !(w %in% lkup[, 1])
        if (any(cond)) 
            warning(round(100 * mean(cond), 2), "% of data not in lookup vector")
    }
    c <- w %in% lkup[, 1]
    w[c] <- lkup[match(w[c], lkup[, 1]), 2]
    s <- sum(w != what, na.rm = T)
    if (verbose) 
        cat("\nReplaced ", s, " values out of ", length(w), " (", 
            round(100 * s/length(w), 2), "%).\n", sep = "")
    return(w)
}
