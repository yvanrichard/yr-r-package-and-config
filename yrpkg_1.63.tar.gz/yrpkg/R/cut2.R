cut2 <-
function (x, breaks) 
{
    if (is.integer(x)) {
        mids <- sprintf("%i - %i", breaks, data.table::shift(breaks, 
            1, type = "lead") - 1)[-length(breaks)]
    }
    else {
        mids <- sprintf("[%i,%i)", breaks, data.table::shift(breaks, 
            1, type = "lead"))[-length(breaks)]
    }
    labels <- c(paste0("< ", breaks[1]), mids, paste0(">= ", 
        tail(breaks, 1)))
    factor(labels[findInterval(x, breaks) + 1], levels = labels)
}
