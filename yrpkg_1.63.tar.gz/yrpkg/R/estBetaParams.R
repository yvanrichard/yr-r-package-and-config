estBetaParams <-
function (mu = NULL, var = NULL, alpha = NULL, beta = NULL) 
{
    if (is.null(alpha) & is.null(beta)) {
        alpha <- ((1 - mu)/var - 1/mu) * mu^2
        beta <- alpha * (1/mu - 1)
        return(list(alpha = alpha, beta = beta))
    }
    else if (is.null(mu) & is.null(var)) {
        mu <- alpha/(alpha + beta)
        var <- (alpha * beta)/((alpha * beta)^2 * (alpha + beta + 
            1))
        return(list(mu = mu, var = var))
    }
    else stop("Either `alpha` and `beta` or `mu` and `var` should be NULL")
}
