get_latex_paths <-
function (dir = getwd(), extensions = c("rnw", "tex", "Rnw"), 
    exclude = c("diff.tex", "cover.tex"), no.time = T) 
{
    cmd <- sprintf("find %s -maxdepth 1 \\( %s \\) | xargs grep -E \"%s\"", 
        dir, paste(sprintf("-name \"*.%s\"", extensions), collapse = " -o "), 
        "^[^#%].*[-a-zA-Z0-9_]+/[-a-zA-Z0-9_]+")
    res <- system(cmd, intern = T)
    split <- strsplit(res, ":")
    res <- data.table(source = sapply(split, "[", 1), content = sapply(split, 
        function(x) paste(x[2:length(x)], collapse = "")))
    res <- res[!(basename(source) %in% exclude)]
    res[, `:=`(content, sub(".*[^-a-zA-Z0-9._/]+([-a-zA-Z0-9._/]+/[-a-zA-Z0-9._/]+)[^-a-zA-Z0-9._/]*.*", 
        "\\1", content))]
    res[, `:=`(mdate, file.mtime(content))]
    setorder(res, mdate)
    if (no.time) 
        res[, `:=`(mdate, format(mdate, "%Y-%m-%d"))]
    return(res)
}
