webtab <-
function (d, rownames = T, fontsize = "10px", rounding = 5, serverside = F) 
{
    dd <- copy(d)
    for (x in names(dd)) {
        if (is.numeric(dd[[x]])) {
            dd[, `:=`(eval(x), round(get(x), rounding))]
        }
    }
    library(DT)
    dd <- as.data.frame(dd)
    datatable(dd, escape = F, extensions = c("Buttons"), options = list(autoWidth = FALSE, 
        paging = FALSE, searching = TRUE, info = TRUE, dom = "Bfrtip", 
        buttons = I("colvis")), rownames = rownames, filter = "top", 
        class = "stripe order-column hover compact")
}
