colorfrom <-
function (var, colors = c("black", "red", "gold", "darkgreen"), 
    ncolors = 100, alpha = 1, rev = F, ...) 
{
    library(RColorBrewer)
    if (is.factor(var) | is.character(var)) {
        if (!is.factor(var)) 
            var <- factor(var, levels = unique(var))
        colors <- rep(colors, length.out = nlevels(var))
        names(colors) <- levels(var)
        Cols <- colors[match(var, names(colors))]
    }
    else {
        if (rev) 
            colors <- rev(colors)
        cols <- colorRampPalette(colors)(ncolors)
        Cols <- cols[round(scaleminmax(var, out.min = 1, out.max = ncolors, 
            ...))]
    }
    return(alpha(Cols, alpha))
}
