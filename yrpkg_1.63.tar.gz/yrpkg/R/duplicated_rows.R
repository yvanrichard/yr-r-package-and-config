duplicated_rows <-
function (df, cols = names(df)) 
{
    id <- apply(df[, cols, drop = F], 1, paste, collapse = "_")
    isdup <- duplicated(df[, cols, drop = F])
    d <- df[id %in% id[isdup], , drop = F]
    id <- apply(d[, cols, drop = F], 1, paste, collapse = "_")
    return(d[order(id), , drop = F])
}
