paletteers <-
function () 
{
    library(paletteer)
    allpals <- rbind(rbindlist(lapply(names(palettes_d), function(x) {
        rbindlist(lapply(names(palettes_d[[x]]), function(y) {
            data.table(source = "palettes_d", pkg = x, pal = y, 
                n = 0, col = palettes_d[[x]][[y]])
        }))
    })), rbindlist(lapply(names(palettes_dynamic), function(x) {
        rbindlist(lapply(names(palettes_dynamic[[x]]), function(y) {
            rbindlist(lapply(seq_along(palettes_dynamic[[x]][[y]]), 
                function(z) {
                  data.table(source = "palettes_dynamic", pkg = x, 
                    pal = y, n = z, col = palettes_dynamic[[x]][[y]][[z]])
                }))
        }))
    })))
    allpals[, `:=`(lab, sprintf("%s | %s | %s | %s", source, 
        pkg, pal, n))]
    allpals[, `:=`(lab, factor(lab, levels = unique(lab)))]
    allpals[, `:=`(y, as.numeric(lab))]
    allpals[, `:=`(x, as.numeric(rowid(lab)))]
    allpals[, `:=`(xtop, max(x)), lab]
    allpals[, `:=`(xmin, scales::rescale(x, to = c(0, 1), from = c(1, 
        xtop + 1))), by = 1:nrow(allpals)]
    allpals[, `:=`(xmax, scales::rescale(x + 1, to = c(0, 1), 
        from = c(1, xtop + 1))), by = 1:nrow(allpals)]
    allpals[, `:=`(x, 0)]
    offset <- 1.3
    allpals[y >= max(y)/2, `:=`(xmin = xmin + offset, xmax = xmax + 
        offset, x = x + offset, y = y - max(y)/2 + 1)]
    g <- ggplot(allpals, aes(x = x, xmin = xmin, xmax = xmax, 
        y = y, ymin = y - 0.40000000000000002, ymax = y + 0.40000000000000002, 
        fill = col, label = lab)) + geom_rect() + geom_text(hjust = 1, 
        size = 0.59999999999999998) + scale_fill_identity() + 
        scale_x_continuous(expand = c(0.10000000000000001, 0.10000000000000001)) + 
        theme_void()
    tmpfile <- tempfile(fileext = ".pdf")
    ggsave(tmpfile, g, width = 7, height = 50, limitsize = F)
    system(sprintf("xdg-open %s", tmpfile))
}
