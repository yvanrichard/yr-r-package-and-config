shinyMCMC <-
function (mcmc, ...) 
{
    require(shiny)
    require(ggplot2)
    require(mcmcplots)
    require(coda)
    require(DT)
    require(data.table)
    shinyApp(ui = fluidPage(titlePanel("MCMC diagnostics"), tabsetPanel(tabPanel("Predictions", 
        sidebarLayout(sidebarPanel(width = 3, uiOutput("par")), 
            mainPanel(width = 9, plotOutput("theplot", height = "800px")))), 
        tabPanel("Correlations", plotOutput("corrplot", height = "800px")), 
        tabPanel("Posterior summaries", dataTableOutput("postsumm", 
            width = "100%")))), server = function(input, output) {
        output$par <- renderUI({
            selectInput("par", label = "Parameter", choices = varnames(mcmc), 
                selected = varnames(mcmc)[1])
        })
        output$theplot <- renderPlot({
            mcmcplot1(mcmc[, input$par, drop = F])
        })
        output$corrplot <- renderPlot({
            autocorr.plot(mcmc)
        })
        output$postsumm <- DT::renderDataTable({
            mcdt <- data.table(do.call("rbind", mcmc))
            mcdt[, `:=`(sample, 1:nrow(mcdt))]
            mcdtn <- melt(mcdt, id.vars = "sample")
            mcsumm <- mcdtn[, .(mean = mean(value), med = median(value), 
                lcl = quantile(value, 0.025000000000000001, names = F), 
                ucl = quantile(value, 0.97499999999999998, names = F)), 
                variable]
            DT::datatable(mcsumm, escape = F, options = list(autoWidth = FALSE, 
                paging = TRUE, searching = TRUE, info = TRUE, 
                pageLength = 30, iDisplayLength = 30), class = "stripe nowrap hover compact", 
                filter = "top", rownames = T)
        })
    })
}
