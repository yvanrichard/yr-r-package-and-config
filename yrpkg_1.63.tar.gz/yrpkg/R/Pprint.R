Pprint <-
function (x, sep = ",", quotes = "\"") 
{
    if (!is.null(quotes)) {
        out <- paste(sprintf("%1$s%2$s%1$s", quotes, x), collapse = sep)
    }
    else {
        out <- paste(sprintf("%s", x), collapse = sep)
    }
    cat(out, sep = "\n")
    return(invisible(out))
}
