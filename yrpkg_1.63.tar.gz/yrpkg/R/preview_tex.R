preview_tex <-
function (texfile, dir = ".") 
{
    if (dir != ".") {
        dir.create(dir)
        file.copy(texfile, sprintf("%s/", dir))
    }
    tex <- c("\n\\documentclass[a4paper,11pt]{article}\n\\usepackage{amsmath}\n\\usepackage{rotating}\n\\usepackage{Sweave}\n\\usepackage{lineno}\n\\usepackage{setspace}\n\\usepackage{dcolumn}\n\\usepackage{placeins}\n\\usepackage[utf8]{inputenc}\n\\newcolumntype{d}[0]{D{.}{.}{-1}}\n\\usepackage[margin=2.5cm]{geometry}\n\\usepackage{graphicx}\n\\usepackage{array}\n\\usepackage{multirow}\n\\usepackage{rotating}\n\\usepackage{engord}\n\\usepackage{textcomp}\n\\usepackage[perpage,para,symbol*]{footmisc}\n\\usepackage[T1]{fontenc}\n\\usepackage{times}\n\\usepackage{mathptmx} %% Times maths font\n\\DeclareMathSizes{11}{11}{8}{6}\n\\usepackage{tocloft}\n\\usepackage[usenames, dvipsnames]{color}\n\\usepackage{colortbl}\n\\usepackage{booktabs}\n\\usepackage{longtable}\n\\usepackage{textcomp}\n\\usepackage{hhline}\n\\usepackage[font={small,bf},captionskip=0pt,\n            nearskip=0pt,farskip=0pt,position=top,\n            justification=justified,singlelinecheck=false]{subfig}\n\\usepackage[perpage,para,symbol*]{footmisc}\n\\usepackage{hyperref}\n\n\\usepackage[bf,sf,pagestyles]{titlesec}\n\n\\newcommand{\\plaintitle}{Temp output}\n\\newcommand{\\reporttitle}{Temp output}\n\\newcommand{\\pdftitle}{Temp output}\n\\newcommand{\\pdfauthors}{authors}\n\\newcommand{\\reportno}{??}\n\n\\usepackage{type1cm}\n\\usepackage{eso-pic}\n\n%%\\input{/dragonfly/latex/mfish/aebr.tex}\n\n\\usepackage[textsize=scriptsize]{todonotes}\n\n\\begin{document}\n", 
        sprintf("\\input{%s}", sub(".tex", "", texfile)), "\\end{document}\n")
    writeLines(tex, sprintf("%s/tex_output.tex", dir), sep = "\n")
    system(sprintf("cd %s && xelatex tex_output && xdg-open tex_output.pdf", 
        dir))
}
