gain <-
function (from, to, initval = 1) 
{
    ((to/from) - 1) * initval
}
