nacolrm <-
function (x) 
{
    if (!("data.table" %in% class(x))) {
        x <- as.data.table(x)
    }
    x[, !sapply(x, function(y) all(is.na(y))), with = F]
}
