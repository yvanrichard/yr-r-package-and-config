parcount <-
function (x, type = "round") 
{
    if (type == "round") {
        chars <- c("(", ")")
    }
    else if (type == "square") {
        chars <- c("[", "]")
    }
    else if (type == "curly") {
        chars <- c("{", "}")
    }
    else stop("`type` needs to be one of `round`, `square`, or `curly`")
    xx <- strsplit(x, character(0), fixed = T)
    sapply(xx, function(z) {
        inc <- cumsum(z == chars[1])
        dec <- cumsum(z == chars[2])
        tail(inc - dec, 1)
    })
}
