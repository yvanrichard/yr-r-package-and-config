getcleaning <-
function (d, by = "record", rows = NULL, open = T, use.idvars = T, 
    format = "html") 
{
    library(knitr)
    library(kableExtra)
    grooms <- copy(attr(d, "datachanges"))
    if (!is.null(grooms)) {
        suppressWarnings(grooms[, `:=`(step, rleid(table, reason, 
            action, datetime))])
        if (!is.null(rows)) {
            grooms <- grooms[.rowid %in% rows]
        }
        if (by == "record") {
            selidvars <- attr(grooms, "idvars")
            if (!is.null(selidvars)) {
                selidvars2 <- c(selidvars, ".rowid")
                rowlabs <- apply(grooms[, ..selidvars2], 1, function(x) paste(x, 
                  collapse = "; "))
                grooms[, `:=`(rowlab, rowlabs)]
            }
            else grooms[, `:=`(rowlab, sprintf("Row %i", .rowid))]
            setorder(grooms, table, rowlab, change_id, field)
            options(knitr.kable.NA = "")
            t <- kable(grooms[, .(action, reason, cond, field, 
                expr, preval, postval)], col.names = c("Type", 
                "Reason", "Condition", "Field", "Action", "From", 
                "To"), format = format) %>% kable_styling(bootstrap_options = c("striped", 
                "hover", "condensed"), fixed_thead = T)
            for (gl in unique(grooms$rowlab)) {
                t <- t %>% group_rows(gl, grooms[, min(which(rowlab == 
                  gl))], grooms[, max(which(rowlab == gl))])
            }
        }
        else if (by == "action") {
            grooms[, `:=`(groomlab, fifelse(action == "Update", 
                sprintf("%i - UPDATE - %s: Do `%s` - when `%s` (%s)", 
                  change_id, reason, expr, cond, datetime), sprintf("%i - DELETION - %s - when `%s` (%s)", 
                  change_id, reason, cond, datetime)))]
            selidvars <- attr(grooms, "idvars")
            if (!is.null(selidvars) & use.idvars == T) {
                selidvars2 <- c(selidvars, ".rowid")
                rowlabs <- apply(grooms[, ..selidvars2], 1, function(x) paste(x, 
                  collapse = "; "))
                grooms[, `:=`(rowlab, rowlabs)]
            }
            else grooms[, `:=`(rowlab, sprintf("Row %i", .rowid))]
            setorder(grooms, table, change_id, groomlab, field)
            options(knitr.kable.NA = "")
            t <- kable(grooms[, .(rowlab, field, preval, postval)], 
                col.names = c("Row", "Field", "From", "To"), 
                format = format) %>% kable_styling(bootstrap_options = c("striped", 
                "hover", "condensed"), fixed_thead = T)
            for (gl in unique(grooms$groomlab)) {
                t <- t %>% group_rows(gl, grooms[, min(which(groomlab == 
                  gl))], grooms[, max(which(groomlab == gl))])
            }
        }
        if (open) {
            outhtml <- tempfile(, fileext = ".html")
            save_kable(t, outhtml)
            browseURL(outhtml)
        }
        return(t)
    }
    else cat("No datachanges applied yet")
}
