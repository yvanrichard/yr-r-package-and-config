progressbar <-
function (n, length = 50L) 
{
    if (length > n) 
        length <- n
    if (length >= 3L) {
        cat(sprintf("|%s|\n", paste(rep("-", length - 2L), collapse = "")))
    }
    else {
        cat(paste(c(rep("|", length), "\n"), collapse = ""))
    }
    s <- seq_len(n)
    sp <- s/n * length
    target <- seq_len(length)
    ids <- sapply(target, function(x) which.min(abs(sp - x)))
    return(ids)
}
