pick <-
function (x, n = 1, among_unique = T) 
{
    if (among_unique) {
        x %in% sample(unique(x), n)
    }
    else {
        x %in% sample(x, n)
    }
}
