longest_common_substring <-
function (a, b) 
{
    library(stringi)
    if (!is.na(a) & !is.na(b)) {
        nc <- nchar(b)
        is <- CJ(seq_len(nc), seq_len(nc))[V2 >= V1]
        sb <- stri_sub(b, is$V1, is$V2)
        sstr <- na.omit(stri_extract_all_coll(a, sb, simplify = TRUE))
        res <- sstr[which.max(nchar(sstr))]
        if (length(res)) {
            return(res)
        }
        else return(NA)
    }
    else return(NA)
}
