find_root_folder <-
function (from = getwd()) 
{
    fold <- from
    atroot <- file.exists(sprintf("%s/.git", fold))
    while (!atroot & fold != "/") {
        fold <- dirname(fold)
        atroot <- file.exists(sprintf("%s/.git", fold))
    }
    if (atroot) {
        return(fold)
    }
    else return(character(0))
}
