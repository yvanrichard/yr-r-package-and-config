pgBuffer <-
function (inname, width, outname = "out_buffer", incol = "geom", 
    outcol = "geom", dbname = "mygis", dbuser = "dba") 
{
    system(sprintf("psql %1$s -U %7$s -c 'drop table if exists %2$s;\n                    create table %2$s as select st_buffer(%3$s, %4$s) as %5$s from %6$s'", 
        dbname, outname, incol, width, outcol, inname, dbuser))
    return(outname)
}
