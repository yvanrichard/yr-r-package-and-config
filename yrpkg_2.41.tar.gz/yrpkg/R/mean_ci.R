mean_ci <-
function (x) 
return(c(mean = mean(x), lcl = quantile(x, 0.025, names = F), 
    ucl = quantile(x, 0.975, names = F)))
