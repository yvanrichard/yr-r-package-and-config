cv <-
function (x) 
sd(x)/mean(x)
