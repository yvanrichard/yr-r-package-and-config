ls.str.into <-
function (rdata) 
{
    e1 <- new.env()
    load(rdata, envir = e1)
    ls.str(envir = e1)
}
