takeout <-
function (what, from) 
return(from[!(from %in% what)])
