pgCmd <-
function (from, select, outname, dbname = "mygis", dbuser = "dba") 
{
    system(sprintf("psql %1$s -U %5$s -c 'drop table if exists %2$s;\n                    create table %2$s as select %3$s from %4$s'", 
        dbname, outname, select, from, dbuser))
    return(outname)
}
