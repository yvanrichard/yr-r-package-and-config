approximate_left_join <-
function (left, right, on.col = "datetime", take = "nearest", 
    nomatch = NA, id.col.left = NULL, id.col.right = NULL) 
{
    library(data.table)
    if (!is.data.table(left)) 
        left <- as.data.table(left)
    if (!is.data.table(right)) 
        right <- as.data.table(right)
    if (!(take %in% c("nearest", "lower", "higher"))) 
        stop("`take` needs to be one of `nearest`, `lower`, `higher`")
    roll <- switch(take, lower = Inf, higher = -Inf, "nearest")
    if (is.null(id.col.left)) {
        left[, `:=`(id.left, seq_len(.N))]
    }
    else left[, `:=`(id.left, get(id.col.left))]
    if (is.null(id.col.right)) {
        right[, `:=`(id.right, seq_len(.N))]
    }
    else right[, `:=`(id.right, get(id.col.right))]
    left[, `:=`(oncol, get(on.col))]
    right[, `:=`(oncol, get(on.col))]
    j <- right[left, on = "oncol", roll = roll, nomatch = nomatch]
    j[right, `:=`(value.joined, i.oncol), on = "id.right"]
    left[, `:=`(id.left, NULL)]
    right[, `:=`(id.right, NULL)]
    j <- j[, .(id.left, oncol, id.right, value.joined)]
    setnames(j, "id.left", ifelse(is.null(id.col.left), "id"))
    setnames(j, "id.right", ifelse(is.null(id.col.right), "id.joined"))
    setnames(j, c("oncol", "value.joined"), c(on.col, paste0(on.col, 
        "_joined")))
    return(j)
}
