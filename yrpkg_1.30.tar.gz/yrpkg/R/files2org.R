files2org <-
function (fold = ".", outfile = tempfile("file_list_", fileext = ".org"), 
    remove.base = T, open = T, details = T, ignore = c(".*~", 
        ".*/\\.git.*"), title = "File list") 
{
    library(data.table)
    fs1 <- system(sprintf("find -P %s %s", fold, paste(sprintf("\\( ! -regex '%s' \\)", 
        ignore), collapse = " ")), intern = T)
    invalidsymlinks <- system(sprintf("find %s -type l -xtype l", 
        fold), intern = T)
    fs1 <- fs1[!(fs1 %in% invalidsymlinks)]
    fs <- normalizePath(fs1)
    finfos <- file.info(fs)
    infos <- ifelse(finfos$isdir, sprintf("mod: %s", finfos$mtime), 
        sprintf("mod: %s - %s bytes", finfos$mtime, finfos$size))
    if (remove.base) 
        fs <- gsub(normalizePath(fold), "", fs)
    fs <- gsub("^/", "", fs)
    s <- strsplit(fs, "/")
    mx <- max(sapply(s, length))
    isdup <- duplicated(s)
    s <- s[which(!isdup)]
    infos <- infos[!isdup]
    finfos <- finfos[!isdup, ]
    s2 <- do.call("rbind", sapply(s, function(x) c(x, rep("", 
        mx - length(x))), simplify = F))
    s[sapply(s, length) == 0] <- ""
    so <- sapply(1:length(s), function(i) {
        x <- s[[i]]
        if (finfos$isdir[i]) {
            x[length(x)] <- paste0(x[length(x)], "/")
        }
        return(x)
    }, simplify = F)
    so <- do.call("rbind", sapply(so, function(x) c(x, rep("", 
        mx - length(x))), simplify = F))
    for (i in 1:ncol(so)) {
        c <- grepl("/$", so[, i])
        so[c, i] <- paste0("0000", so[c, i])
        c <- grepl("^\\.", so[, i])
        so[c, i] <- paste0("00", so[c, i])
    }
    ord <- do.call(order, data.frame(so))
    s2 <- s2[ord, ]
    infos <- infos[ord]
    finfos <- finfos[ord, ]
    if (mx > 1) {
        for (i in 1:mx) {
            c <- c(F, s2[2:nrow(s2), i] == s2[1:(nrow(s2) - 1), 
                i]) & c(F, s2[1:(nrow(s2) - 1), i] != "")
            s2[c, i] <- "*"
        }
    }
    s3 <- cbind("*", s2)
    s4 <- apply(s3, 1, function(x) paste(x, collapse = "/"))
    s4 <- gsub("//+", "/", s4)
    s4 <- gsub("/$", "", s4)
    s4 <- gsub("\\*/", "*", s4)
    s5 <- gsub("^([*]*)", "\\1 ", s4)
    s5 <- ifelse(finfos$isdir, paste0(s5, "/"), s5)
    if (details) {
        s6 <- sprintf("%s \t/%s/", s5, infos)
    }
    else s6 <- s5
    desc <- c(sprintf("Created: %s", Sys.time()), sprintf("Base: %s", 
        sQuote(normalizePath(fold))), sprintf("From computer: %s", 
        sQuote(system("hostname", intern = T))))
    s6 <- c(paste(desc, collapse = "\n\n"), "", s6)
    strout <- c(s6, "* org conf", "#+STARTUP:\tindent", "#+STARTUP:\tshowstars", 
        "#+STARTUP:\tshowall", "#+INFOJS_OPT:\tview:info toc:true view:content tdepth:2", 
        sprintf("#+TITLE:\t%s", title), sprintf("#+DATE:\t%s", 
            Sys.Date()), sprintf("#+DESCRIPTION:\t%s", paste(desc, 
            collapse = " - ")))
    writeLines(strout, outfile, sep = "\n")
    cat("File list written to", normalizePath(outfile), "\n")
    if (open) 
        system(sprintf("emacsclient -n %s", outfile), intern = F, 
            wait = F)
}
