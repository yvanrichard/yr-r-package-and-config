getfma <-
function (df, xcolumn, ycolumn) 
{
    library(rgdal)
    fmas <- readOGR("/dragonfly/gis/shapes/mfish", "fma")
    df$x <- df[[xcolumn]]
    df$y <- df[[ycolumn]]
    coordinates(df) = ~x + y
    proj4string(df) <- CRS("+proj=longlat +datum=WGS84")
    return(overlay(df, fmas))
}
