push_msg <-
function (title = "Automatic msg", body = "Test", url = NULL, 
    devices = 0, debug = F, verbose = F) 
{
    library(RPushbullet)
    if (is.null(getOption("rpushbullet.key"))) {
        stop("Pushbullet key not set. Please run `pbSetup()`.")
    }
    if (is.null(url)) {
        pbPost(type = "note", title = title, body = body, verbose = verbose, 
            debug = debug, recipients = devices)
    }
    else if (grepl("//", url)) {
        pbPost(type = "link", title = title, body = body, url = url, 
            verbose = verbose, debug = debug, recipients = devices)
    }
    else {
        pbPost(type = "file", url = url, verbose = verbose, debug = debug, 
            recipients = devices)
    }
}
