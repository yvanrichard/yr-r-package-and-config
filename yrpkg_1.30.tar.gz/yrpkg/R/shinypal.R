shinypal <-
function (...) 
{
    require(shiny)
    library(ggplot2)
    require(data.table)
    require(shinyjs)
    require(clipr)
    bezierCurve <- function(x, y, n = 10) {
        bez <- function(x, y, t) {
            outx <- 0
            outy <- 0
            n <- length(x) - 1
            for (i in 0:n) {
                outx <- outx + choose(n, i) * ((1 - t)^(n - i)) * 
                  t^i * x[i + 1]
                outy <- outy + choose(n, i) * ((1 - t)^(n - i)) * 
                  t^i * y[i + 1]
            }
            return(list(x = outx, y = outy))
        }
        outx <- NULL
        outy <- NULL
        i <- 1
        for (t in seq(0, 1, length.out = n)) {
            b <- bez(x, y, t)
            outx[i] <- b$x
            outy[i] <- b$y
            i <- i + 1
        }
        return(data.table(x = outx, y = outy))
    }
    shinyApp(ui = fluidPage(useShinyjs(), sidebarLayout(sidebarPanel(width = 2, 
        sliderInput("luminance", label = "Luminance", min = 0, 
            max = 100, value = 75, step = 1), sliderInput("chroma", 
            label = "Chroma factor", min = 0, max = 150, value = 100, 
            step = 1), checkboxInput("fixup", "Fixup colours", 
            value = F), radioButtons("mode", "Click action", 
            choices = c(`Pick individual colours` = "choose_colors", 
                `Draw Bezier curve` = "beziers")), sliderInput("n_cols", 
            label = "No. colours", min = 1, max = 20, value = 5, 
            step = 1), verbatimTextOutput("pal_string_rgb"), 
        verbatimTextOutput("pal_string_hcl"), actionButton("clip", 
            "Copy"), actionButton("clear_pal", "Clear palette")), 
        mainPanel(width = 10, fluidRow(column(8, plotOutput("theplot", 
            click = "plot_click", height = "700px")), column(2, 
            plotOutput("palette")), column(2, plotOutput("explot")))))), 
        server = function(input, output) {
            reacvals <- reactiveValues(xys = NULL, points = NULL, 
                palette = NULL, bezierpoints = NULL, gradient = NULL)
            observeEvent(input$plot_click, {
                reacvals$xys <<- c(reacvals$xys, list(input$plot_click[c("x", 
                  "y")]))
                whc <- wheel_colors()
                pal <- rbindlist(reacvals$xys)
                pal[, `:=`(col, sapply(1:nrow(pal), function(i) {
                  whc[whc[, which.min((x - pal[i, x])^2 + abs(y - 
                    pal[i, y])^2)], z]
                }))]
                reacvals$points <<- pal
            })
            observe({
                if (input$mode != "choose_colors") {
                  if (!is.null(reacvals$points) & !is.null(input$n_cols)) {
                    bxys <- reacvals$points[, bezierCurve(x, 
                      y, input$n_cols)]
                    whc <- wheel_colors()
                    bxys <- rbindlist(lapply(1:nrow(bxys), function(i) {
                      whc[whc[, which.min((x - bxys[i, x])^2 + 
                        abs(y - bxys[i, y])^2)]]
                    }))
                    bxys[, `:=`(col, z)]
                    reacvals$gradient <<- bxys
                  }
                }
                else {
                  if (!is.null(reacvals$points)) {
                    reacvals$palette <<- reacvals$points
                  }
                }
            })
            observeEvent(input$clear_pal, {
                reacvals$points <<- NULL
                reacvals$gradient <<- NULL
                reacvals$xys <<- NULL
                reacvals$palette <<- NULL
            })
            observeEvent(input$mode, {
                if (input$mode != "choose_colors") {
                  show("n_cols")
                }
                else hide("n_cols")
                reacvals$points <<- NULL
                reacvals$gradient <<- NULL
                reacvals$xys <<- NULL
                reacvals$palette <<- NULL
            })
            output$theplot <- renderPlot({
                wheel <- wheel_colors()
                if (!is.null(wheel)) {
                  par(mar = c(0, 0, 0, 0))
                  wheel[, plot(x, y, col = z, pch = 19, bty = "n", 
                    axes = F, xlab = NA, ylab = NA, asp = 1)]
                  if (!is.null(reacvals$points)) {
                    reacvals$points[, text(x, y, col = "black")]
                  }
                  if (!is.null(reacvals$gradient)) {
                    reacvals$gradient[, points(x, y, col = "black", 
                      type = "l", lwd = 1.5)]
                  }
                }
            })
            output$palette <- renderPlot({
                if (input$mode == "choose_colors") {
                  pal <- reacvals$palette
                }
                else {
                  pal <- reacvals$gradient
                }
                if (!is.null(pal)) {
                  pal[, `:=`(colr, factor(col, levels = unique(col)))]
                  cols <- as.character(pal$colr)
                  names(cols) <- as.character(pal$colr)
                  ggplot(pal, aes(xmin = -10, xmax = 10, ymin = -10, 
                    ymax = 10, fill = colr)) + geom_rect() + 
                    geom_text(x = 0, y = 0, aes(label = colr)) + 
                    scale_x_continuous(expand = c(0, 0)) + scale_y_continuous(expand = c(0, 
                    0)) + scale_fill_manual(values = cols) + 
                    facet_wrap(~colr, ncol = 1) + theme_void() + 
                    theme(legend.position = "none", panel.spacing = unit(0, 
                      "mm"), strip.text = element_blank(), plot.margin = unit(c(0, 
                      0, -1, -1), "mm"))
                }
            })
            output$explot <- renderPlot({
                if (input$mode == "choose_colors") {
                  pal <- reacvals$palette
                }
                else {
                  pal <- reacvals$gradient
                }
                if (!is.null(pal)) {
                  d1 <- data.table(x = rnorm(100), y = rnorm(100), 
                    z = sample(1:nrow(pal), 100, replace = T))
                  d2 <- data.table(x = unlist(sapply(1:nrow(pal), 
                    function(i) runif(1, 5, 100))))
                  d3 <- data.table(x = apply(matrix(rnorm(100 * 
                    nrow(pal)), nrow = nrow(pal)), 1, cumsum))
                  par(mfrow = c(3, 1), mar = c(0, 0, 0, 0), bty = "n")
                  d1[, plot(x, y, col = pal$col[z], pch = 19, 
                    bty = "n", axes = F)]
                  d2[, barplot(x, col = pal$col, bty = "n", axes = F)]
                  matplot(d3, type = "l", col = pal$col, lwd = 1.7, 
                    axes = F, bty = "n", xlab = NA, ylab = NA)
                }
            })
            wheel_colors <- reactive({
                if (!is.null(input$chroma) & !is.null(input$luminance) & 
                  !is.null(input$fixup)) {
                  r <- seq(0, 1, length = 201)
                  th <- seq(0, 2 * pi, length = 201)
                  gg <- data.table(expand.grid(r = r, th = th))
                  gg[, `:=`(x = r * sin(th), y = r * cos(th), 
                    h = 360 * th/(2 * pi), c = input$chroma * 
                      r, l = input$luminance)]
                  gg[, `:=`(z, hcl(h, c, l, fixup = input$fixup))]
                  return(gg)
                }
            })
            output$pal_string_rgb <- renderText({
                txt <- NULL
                if (input$mode == "choose_colors") {
                  if (!is.null(reacvals$palette)) {
                    txt <- sprintf("\"%s\"", paste(reacvals$palette$col, 
                      collapse = "\",\""))
                  }
                }
                else {
                  if (!is.null(reacvals$gradient)) {
                    txt <- sprintf("\"%s\"", paste(reacvals$gradient$col, 
                      collapse = "\",\""))
                  }
                }
                return(txt)
            })
            output$pal_string_hcl <- renderText({
                txt <- NULL
                if (input$mode == "choose_colors") {
                  if (!is.null(reacvals$palette)) {
                    txt <- sprintf("\"%s\"", paste(reacvals$palette[, 
                      sprintf("%s,%s,%s", h, c, l)], collapse = "\",\""))
                  }
                }
                else {
                  if (!is.null(reacvals$gradient)) {
                    txt <- sprintf("\"%s\"", paste(reacvals$gradient[, 
                      sprintf("hcl(h=%s,c=%s,l=%s)", h, c, l)], 
                      collapse = ","))
                  }
                }
                return(txt)
            })
            observeEvent(input$clip, clipr::write_clip(as.character(input$pal_string), 
                object_type = "character"))
            output$test <- renderPrint({
                if (input$mode == "choose_colors") {
                  print(reacvals$palette)
                }
                else {
                  print(reacvals$gradient)
                }
            })
        })
}
