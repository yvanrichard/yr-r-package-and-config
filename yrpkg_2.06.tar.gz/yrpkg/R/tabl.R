tabl <-
function (x, sort = T) 
{
    if (length(x)) {
        t = as.data.frame(table(x, useNA = "always"), stringsAsFactors = F)
        names(t) <- c("value", "freq")
        if (sort) 
            t <- t[order(t$freq, decreasing = T), ]
        return(t)
    }
    else stop("x is empty")
}
