sample_df <-
function (df, n = 10) 
{
    df[sort(sample(1:nrow(df))[1:n]), ]
}
