check.latex.deps <-
function (fold = ".", ignore = c("^/usr/|^/var/lib|^/etc/tex|sweave/|^/dragonfly|/share/"), 
    only = c("/"), recursive = T, save_untracked = T, use.xelatex = T) 
{
    alldeps <- NULL
    prevdir <- getwd()
    setwd(fold)
    rnw <- dir(".", "*.rnw$|*.Rnw$", recursive = recursive)
    basedir <- getwd()
    r1 = rnw[1]
    for (r1 in rnw) {
        cat("\n************  ", r1, "  ************\n")
        rdir <- dirname(r1)
        setwd(rdir)
        r2 <- basename(r1)
        r <- readLines(r2)
        c1 <- r[grepl("\\bload\\(", r) & !grepl("^[[:blank:]]*#", 
            r)]
        fs1 <- sub("load\\(['\"]+(.*)['\"]+.*", "\\1", c1)
        c2 <- r[grepl("\\bread.csv\\(", r) & !grepl("^[[:blank:]]*#", 
            r)]
        fs2 <- sub("read.csv\\(['\"]+(.*)['\"]+.*", "\\1", c2)
        fs <- c(fs1, fs2)
        c <- grepl("load\\([a-zA-Z]+", fs)
        alldeps1 <- sub("load\\(([a-zA-Z_.0-1]+).*\\)", "\\1", 
            fs[c])
        s <- unlist(sapply(dir(".", "*.mk.parsed"), function(mk) readLines(mk), 
            simplify = F))
        s1 <- do.call("rbind", strsplit(s, "[[:blank:]]*=[[:blank:]]*"))
        s2 <- sapply(alldeps1, function(x) s1[which(s1[, 1] %in% 
            x), 2], simplify = F)
        fs[c] <- ifelse(sapply(s2, length), sapply(s2, "[", 1), 
            names(s2))
        cat(paste(fs, collapse = "\n"), "\n")
        fs <- normalizePath(fs)
        alldeps <- c(alldeps, fs)
        setwd(basedir)
        cat("\n")
    }
    tex <- dir(".", "*.tex$", recursive = recursive)
    tex <- tex[!(tex %in% "aebr.tex")]
    basedir <- getwd()
    t = tex[3]
    for (t in tex) {
        cat("\n************  ", t, "  ************\n")
        tdir <- dirname(t)
        setwd(tdir)
        t2 <- basename(t)
        bt <- sub("\\.tex", "", t2)
        tmp <- readLines(t2)
        if (any(grepl("begin\\{document\\}", tmp))) {
            if (!use.xelatex) {
                s <- system(sprintf("pdflatex -recorder -interaction=nonstopmode %s", 
                  bt), intern = T)
            }
            else {
                s <- system(sprintf("xelatex -recorder -interaction=nonstopmode %s", 
                  bt), intern = T)
            }
            f <- sprintf("%s.fls", bt)
            if (file.exists(f)) {
                fls <- readLines(f)
                fls <- sapply(strsplit(fls, " "), function(x) x[2])
                fls <- sub("^\\./", "", fls)
                fls <- unique(fls)
                fls <- fls[!grepl(sprintf("^%s", bt), fls)]
                fls <- fls[!(fls %in% normalizePath(fold))]
                alldeps <- c(alldeps, normalizePath(fls))
                cat(paste(fls, collapse = "\n"))
                cat("\n")
            }
            else cat("fls file inexistent. There is a problem with this file...\n")
        }
        else cat("Not a master file. Skip...\n")
        setwd(basedir)
    }
    cat("\n\n")
    alldeps <- alldeps[!grepl("^[ ]*\\%", alldeps)]
    alldeps <- unique(alldeps)
    alldeps <- alldeps[!grepl(ignore, alldeps)]
    s <- sapply(alldeps, is.git.tracked)
    nt <- names(s)[!s]
    if (!is.null(nt)) {
        cat("************====  Files not tracked by GIT:  ====************\n")
        cat(paste(nt, collapse = "\n"))
        cat("\n\n")
        cat(paste(nt, collapse = "  "))
        cat("\n\n")
    }
    if (save_untracked) 
        write.csv(nt, "untracked-dependencies.csv", row.names = F)
    setwd(prevdir)
}
