insert.column <-
function (df, pos, stringsAsFactors = F, ...) 
{
    if (pos <= 1) 
        df <- cbind(..., df, stringsAsFactors = stringsAsFactors)
    else if (pos >= ncol(df)) 
        df <- cbind(df, stringsAsFactors = stringsAsFactors, 
            ...)
    else df <- cbind(df[, 1:(pos - 1), drop = F], ..., df[, pos:ncol(df), 
        drop = F], stringsAsFactors = stringsAsFactors)
    return(df)
}
