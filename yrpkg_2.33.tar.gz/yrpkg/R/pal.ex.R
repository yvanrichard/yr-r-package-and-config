pal.ex <-
function (cols, cex = 1.3) 
{
    ncols <- length(cols)
    par(mfrow = c(2, 2), mar = c(2, 2, 1, 1))
    x <- table(round(runif(100, 0.5, ncols + 0.5)))
    barplot(x, col = cols)
    plot(rnorm(1000), rnorm(1000), col = cols, pch = 20, cex = cex)
    nl <- max(10, ncols)
    x <- apply(matrix(rnorm(100 * nl), nrow = nl), 1, cumsum)
    matplot(x, type = "l", col = cols, lwd = cex)
    ncols <- ncols * 2
    plot(NA, xlim = c(0, 5), ylim = c(1, ncols + 1), axes = F, 
        xaxs = "i", yaxs = "i")
    cols1 <- rep(cols, each = 2)
    for (i in 1:ncols) rect(0, i, 1, i + 1, col = cols1[i], border = NA)
    for (i in 1:ncols) rect(4, i, 5, i + 1, col = rev(cols1)[i], 
        border = NA)
    cols2 <- c(cols, rev(cols))
    for (i in 1:ncols) rect(2, i, 3, i + 1, col = cols2[i], border = NA)
}
