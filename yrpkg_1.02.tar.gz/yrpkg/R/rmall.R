rmall <-
function () 
{
    rm(list = ls())
}
