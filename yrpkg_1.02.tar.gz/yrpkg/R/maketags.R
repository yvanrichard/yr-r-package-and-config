maketags <-
function (x) 
rtags(ofile = "TAGS", recursive = T)
