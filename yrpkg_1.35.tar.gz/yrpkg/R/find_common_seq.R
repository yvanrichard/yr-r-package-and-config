find_common_seq <-
function (v1, v2, size, na.rm = T, cores = 6) 
{
    library(data.table)
    library(parallel)
    if (!identical(class(v1), class(v2))) 
        stop("v1 and v2 are of different class")
    ids1 <- data.table(v = v1, id_ori = 1:length(v1))
    if (na.rm == T) 
        ids1 <- na.omit(ids1)
    ids1[, `:=`(id_new, 1:.N)]
    ids2 <- data.table(v = v2, id_ori = 1:length(v2))
    if (na.rm == T) 
        ids2 <- na.omit(ids2)
    ids2[, `:=`(id_new, 1:.N)]
    v1 <- ids1[, v]
    v2 <- ids2[, v]
    rbindlist(mclapply(1:(length(v1) - size), function(i) {
        x1 <- v1[i:(i + size - 1)]
        rbindlist(lapply(1:(length(v2) - size + 1), function(j) {
            x2 <- v2[j:(j + size - 1)]
            if (identical(x1, x2)) {
                return(data.table(seq = paste(x1, collapse = ","), 
                  i = ids1[id_new == i, id_ori], j = ids2[id_new == 
                    j, id_ori]))
            }
        }))
    }, mc.cores = cores))
}
