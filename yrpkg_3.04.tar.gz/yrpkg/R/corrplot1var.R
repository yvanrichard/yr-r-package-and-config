corrplot1var <-
function (dat, depvar, alpha = 0.3, psample = 1, colby = NULL) 
{
    library(ggplot2)
    library(data.table)
    corrvars <- setdiff(names(dat)[sapply(names(dat), function(v) class(dat[[v]])) %in% 
        c("numeric", "integer")], depvar)
    nvars <- length(corrvars)
    if (!is.null(colby)) {
        c <- rbindlist(lapply(corrvars, function(v) {
            d <- data.table(depvar = depvar, y = dat[[depvar]], 
                corrvar = v, x = dat[[v]], colby = dat[[colby]])
            return(d[sample(1:nrow(d), round(psample * nrow(d)))])
        }))
        g <- ggplot(c, aes(x = x, y = y, group = corrvar)) + 
            facet_wrap(~corrvar, scales = "free")
        if (!is.null(colby)) 
            g <- g + geom_point(aes(colour = colby), alpha = alpha)
    }
    else {
        c <- rbindlist(lapply(corrvars, function(v) {
            d <- data.table(depvar = depvar, y = dat[[depvar]], 
                corrvar = v, x = dat[[v]])
            return(d[sample(1:nrow(d), round(psample * nrow(d)))])
        }))
        g <- ggplot(c, aes(x = x, y = y, group = corrvar)) + 
            facet_wrap(~corrvar, scales = "free") + geom_point(alpha = alpha)
    }
    return(g)
}
