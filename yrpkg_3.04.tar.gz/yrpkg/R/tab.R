tab <-
function (x) 
{
    return(sort(table(x, useNA = "always"), decreasing = T))
}
