pgReturn <-
function (tablename = "tmpshp", outfile = "out_shp.shp", dbname = "mygis", 
    dbuser = "dba") 
{
    library(rgdal)
    system(sprintf("ogr2ogr -f \"ESRI Shapefile\" -overwrite %s PG:\"dbname=%s user=%s\" -sql \"select * from %s\"", 
        outfile, dbname, dbuser, tablename))
    shp <- readOGR(dirname(outfile), sub("\\..*$", "", basename(outfile)))
    return(shp)
}
