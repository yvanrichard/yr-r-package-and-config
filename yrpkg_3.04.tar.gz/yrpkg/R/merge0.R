merge0 <-
function (x, y, ...) 
{
    mrg <- merge(x, y, by = 0, ...)
    rownames(mrg) <- mrg$Row.names
    mrg$Row.names <- NULL
    return(mrg)
}
