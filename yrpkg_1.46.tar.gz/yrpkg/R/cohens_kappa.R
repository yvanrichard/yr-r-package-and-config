cohens_kappa <-
function (TP, FN, FP, TN) 
{
    return(2 * (TP * TN - FN * FP)/(TP * FN + TP * FP + 2 * TP * 
        TN + FN^2 + FN * TN + FP^2 + FP * TN))
}
