convert_files_to_txt <-
function (filepaths, mc.cores = 6) 
{
    conv.fun <- c(rtf = "unrtf --text --nopict \"%s\" | tail -n+5 > \"%s\"", 
        docx = "unzip -p \"%s\" word/document.xml | sed -e 's/<\\/w:p>/\\n/g; s/<[^>]\\{1,\\}>//g; s/[^[:print:]\\n]\\{1,\\}//g' > \"%s\"", 
        pdf = "pdftotext \"%s\" \"%s\"", odt = "unoconv -f txt --stdout \"%s\" > \"%s\"")
    ext <- tolower(sub(".*\\.([a-zA-Z0-9-]+)$", "\\1", filepaths))
    ext[ext %in% "pdf-1"] <- "pdf"
    outfiles <- paste0(filepaths, ".txt")
    res <- mclapply(seq_along(filepaths), function(i) {
        f <- filepaths[i]
        convf <- conv.fun[ext[i]]
        if (!is.na(convf)) {
            cmd <- sprintf(convf, f, outfiles[i])
            tryCatch(system(cmd, intern = T), warning = function(w) {
                cat("Warning with ", f, "\n")
            }, error = function(e) {
                cat("Error with ", f, "\n")
            })
        }
        else {
            warning(sprintf("No converter found for %s. Skipped.", 
                f))
        }
    }, mc.cores = mc.cores)
}
