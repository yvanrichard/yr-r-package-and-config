tad <-
function (df, ...) 
{
    localc(df, openwith = "tad", ...)
}
