datareport <-
function (dt, tmpfold = tempdir(), rmdfile = file.path(tmpfold, 
    "data-summary.Rmd"), htmlfile = file.path(tmpfold, "data-summary.html"), 
    ignore.cols = character(0)) 
{
    library(data.table)
    library(knitr)
    library(ggplot2)
    n <- nrow(dt)
    rmd <- sprintf("---\ntitle: Summary of %s\nauthor: datareport()\ndate: \"%s\"\noutput:\n  rmdformats::readthedown:\n    mathjax: null\n    use_bookdown: false\n    lightbox: true\n    thumbnails: false\n    css: ~/Dropbox/templates/report-html/custom.css\n    gallery: true\n    toc_depth: 3\n    toc_float:\n      collapsed: false\n      smooth_scoll: true\nmode: selfcontained\n---\n\n", 
        deparse(substitute(dt)), Sys.time())
    cat(rmd, file = rmdfile)
    cat("# General summary\n", file = rmdfile, append = T)
    cat(n, "rows\n\n", file = rmdfile, append = T)
    cat(kable(head(dt, 5), format = "html", caption = "First 5 rows", 
        padding = 1), file = rmdfile, append = T)
    cat(kable(tail(dt, 5), format = "html", caption = "Last 5 rows", 
        padding = 1), file = rmdfile, append = T)
    cat("# Map of missing values\n", file = rmdfile, append = T)
    nam <- namap(dt)
    namapfile <- file.path(tmpfold, "na-map.png")
    W <- 9
    H <- pmax(7, pmin(W * nam$h_w_ratio, 60))
    ggsave(namapfile, nam$plot, width = W, height = H, limitsize = F)
    cat(sprintf("<td><img src=\"%1$s\" alt=\"%1$s\" height=\"%2$0.2f\" width=\"900\"></td></tr>\n", 
        namapfile, 900 * H/W), file = rmdfile, append = T)
    cat("# Fields summary\n", file = rmdfile, append = T)
    colno <- 1
    for (z in names(dt)) {
        if (!(z %in% ignore.cols)) {
            cat(z, "\n")
            cat("\n##", colno, "-", z, "\n\n", file = rmdfile, 
                append = T)
            dt[, `:=`(zevalue, get(z))]
            x <- dt[[z]]
            cat("<table><tr><td><table><tr><td>\n", file = rmdfile, 
                append = T)
            un <- uniqueN(x)
            pun <- 100 * un/n
            nas <- sum(is.na(x))
            pnas <- 100 * nas/n
            cat(sprintf("Class: `%s`\n\nUnique values: `%i` (%0.2f%%)\n\nNAs: `%i` (%0.2f%%)\n\n", 
                class(x), un, pun, nas, pnas), file = rmdfile, 
                append = T)
            cat("</td></tr>", file = rmdfile, append = T)
            zz <- gsub("[^a-zA-Z0-9_-]", "", gsub("[[:blank:]]+", 
                "_", tolower(z)))
            densfile <- file.path(tmpfold, sprintf("density-%s.png", 
                zz))
            if (is.numeric(x)) {
                cat("<tr><td>", file = rmdfile, append = T)
                t <- kable(data.table(min = min(x, na.rm = T), 
                  lcl = quantile(x, 0.025, na.rm = T, names = F), 
                  mean = mean(x, na.rm = T), med = median(x, 
                    na.rm = T), ucl = quantile(x, 0.975, na.rm = T, 
                    names = F), max = max(x, na.rm = T)), format = "html")
                cat(t, file = rmdfile, append = T)
                cat("</td></tr></table></td>", file = rmdfile, 
                  append = T)
                g <- ggplot(dt, aes(zevalue)) + geom_density(fill = "#43A1C9AA", 
                  colour = "#225165") + scale_x_continuous(expand = c(0, 
                  0)) + scale_y_continuous(expand = c(0, 0)) + 
                  labs(x = z)
                ggsave(densfile, g, width = 6, height = 4)
                cat(sprintf("<td><img src=\"%1$s\" alt=\"%1$s\" height=\"400\" width=\"700\"></td></tr>\n", 
                  densfile), file = rmdfile, append = T)
            }
            else if (is.factor(x) | is.character(x) | lubridate::is.Date(x)) {
                if (is.factor(x) | lubridate::is.Date(x)) {
                  y <- as.character(x)
                }
                else y <- x
                suppressWarnings(ynum <- as.numeric(y))
                couldbenum <- ifelse(all(is.na(ynum)) | any(is.na(ynum) & 
                  !is.na(y)), F, T)
                cat(sprintf("<tr><td>Could be numeric: `%s`</td></tr>", 
                  couldbenum), file = rmdfile, append = T)
                cat("<tr><td>", file = rmdfile, append = T)
                t <- kable(data.table(min = min(nchar(y), na.rm = T), 
                  mean = mean(nchar(y), na.rm = T), med = median(nchar(y), 
                    na.rm = T), max = max(nchar(y), na.rm = T)), 
                  caption = "Number of characters", format = "html")
                cat(t, file = rmdfile, append = T)
                cat("</td></tr>", file = rmdfile, append = T)
                if (couldbenum & !is.factor(x)) {
                  dt[, `:=`(zevalue, round(as.numeric(zevalue), 
                    7))]
                  dt[, `:=`(zevalue, factor(zevalue))]
                }
                if (is.factor(x) | un <= 20) {
                  cat("<tr><td>", file = rmdfile, append = T)
                  t <- kable(dt[, .N, zevalue][order(-N)], col.names = c(z, 
                    "N"), format = "html", caption = "Frequency of all values")
                  cat(t, file = rmdfile, append = T)
                  cat("</td></tr></table></td>", file = rmdfile, 
                    append = T)
                  g <- ggplot(dt, aes(zevalue)) + geom_bar(fill = "#43A1C9AA", 
                    colour = "#225165") + labs(x = z) + theme(axis.text.x.bottom = element_text(angle = 45, 
                    hjust = 1))
                  ggsave(densfile, g, width = 6, height = 4)
                  cat(sprintf("<td><img src=\"%1$s\" alt=\"%1$s\" height=\"400\" width=\"700\"></td></tr>\n", 
                    densfile), file = rmdfile, append = T)
                }
                else {
                  cat("</table></td><td>", file = rmdfile, append = T)
                  t <- kable(dt[, .N, zevalue][order(-N)][1:pmin(.N, 
                    15)], col.names = c(z, "N"), format = "html", 
                    caption = "15 most common values")
                  cat(t, file = rmdfile, append = T)
                  cat("</td><td>", file = rmdfile, append = T)
                  t <- kable(dt[, .N, zevalue][order(N)][1:pmin(.N, 
                    15)], col.names = c(z, "N"), format = "html", 
                    caption = "15 least common values")
                  cat(t, file = rmdfile, append = T)
                  cat("</td></tr>", file = rmdfile, append = T)
                }
            }
            else {
                cat("</table></td><td>", file = rmdfile, append = T)
            }
            cat("</table>\n", file = rmdfile, append = T)
        }
        colno <- colno + 1
    }
    numcols <- sapply(dt, is.numeric)
    numcols <- names(numcols)[numcols == T]
    if (length(numcols) > 1) {
    }
    rmarkdown::render(input = rmdfile, output_file = htmlfile, 
        clean = T)
    system(sprintf("xdg-open %s", htmlfile), wait = F)
    dt[, `:=`(zevalue, NULL)]
    return(invisible(htmlfile))
}
