ghelp <-
function (topic, ext = "R", in_cran = ifelse(ext == "R", TRUE, 
    FALSE)) 
{
    require(htmltools)
    require(rvest)
    base_ext_url <- sprintf("https://github.com/search?utf8=%%%%E2%%%%9C%%%%93&q=%%s+extension%%%%3A%s", 
        ext)
    ext_url <- sprintf(base_ext_url, topic)
    if (in_cran) 
        ext_url <- paste(ext_url, "+user%3Acran", sep = "", collapse = "")
    if (packageVersion("rvest") < "0.2.0.9000") {
        require(XML)
        pg <- html(ext_url)
        res_div <- paste(capture.output(html_node(pg, "div#code_search_results")), 
            collapse = "")
    }
    else {
        require(xml2)
        pg <- read_html(ext_url)
        res_div <- as.character(html_nodes(pg, "div#code_search_results"))
    }
    res_div <- gsub("How are these search results\\? <a href=\"/contact\">Tell us!</a>", 
        "", res_div)
    res_div <- gsub("href=\"/", "href=\"http://github.com/", 
        res_div)
    for_view <- sprintf("<html><head><link crossorigin=\"anonymous\" href=\"https://assets-cdn.github.com/assets/github/index-4157068649cead58a7dd42dc9c0f2dc5b01bcc77921bc077b357e48be23aa237.css\" media=\"all\" rel=\"stylesheet\" /><style>body{padding:20px}</style></head><body><a href=\"%s\">Show on GitHub</a><hr noshade size=1/>%s</body></html>", 
        ext_url, res_div)
    html_print(HTML(for_view))
}
