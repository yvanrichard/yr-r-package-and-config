whichseason <-
function (d, starts, names) 
{
    library(lubridate)
    np <- length(starts)
    if (class(d) != "Date") 
        d <- as.Date(d)
    if (class(starts) != "Date") 
        starts <- as.Date(starts)
    startsyday <- c(lubridate::yday(starts), lubridate::yday(starts[1]) + 
        366)
    minyday <- startsyday[1]
    startsyday0 <- startsyday - minyday
    startsyday0 <- ifelse(startsyday0 < 0, startsyday0 + 366, 
        startsyday0)
    dyday <- lubridate::yday(d)
    dyday0 <- lubridate::yday(d) - minyday
    dyday0 <- ifelse(dyday0 < 0, dyday0 + 366, dyday0)
    pers <- cut(dyday0, breaks = startsyday0, right = F, labels = names)
    return(pers)
}
