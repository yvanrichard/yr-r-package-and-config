quantsmooth <-
function (x, y, ndivs = 20, ...) 
{
    qq <- sort(quantile(x, seq(0, 1, length.out = ndivs + 1)))
    qqmids <- (qq[2:length(qq)] + qq[1:(length(qq) - 1)])/2
    varcut <- qqmids[findInterval(x, qq, rightmost.closed = T, 
        all.inside = T)]
    varcutf <- factor(varcut, levels = qqmids)
    qqy <- as.numeric(tapply(y, varcutf, mean))
    df <- data.frame(midpt = qqmids, y = qqy)
    attr(df, "n") <- as.numeric(tapply(y, varcut, length))
    attr(df, "supsmu") <- supsmu(df$midpt, df$y)
    return(df)
}
