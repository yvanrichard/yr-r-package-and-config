movecolumns <-
function (df, cols, where = 1) 
{
    colids <- match(cols, colnames(df))
    others <- which(!(colnames(df) %in% cols))
    if (where == 1) 
        return(df[, c(colids, others)])
    else {
        if (where == ncol(df)) 
            return(df[, c(others, colids)])
        else {
            return(df[, c(others[others < where], colids, others[others >= 
                where])])
        }
    }
}
