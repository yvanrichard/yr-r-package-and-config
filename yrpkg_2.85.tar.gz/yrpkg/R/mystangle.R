mystangle <-
function (file, outfile = sub("(\\.[^.]+)$", "_stangled.R", file)) 
{
    rnw <- readLines(file)
    get.sexprs <- function(start, end) {
        poss <- start:end
        sexprs <- grep("Sexpr\\{", rnw[poss], val = F)
        if (length(sexprs)) {
            sxppos <- poss[sexprs]
            cmds <- sapply(1:length(sxppos), function(i) {
                rnw1 <- rnw[sxppos[i]]
                sxpstarts <- gregexpr("Sexpr", rnw1)[[1]]
                if (length(sxpstarts) == 1) {
                  cmd <- sub(".*Sexpr *\\{([^}]+)\\}.*", "\\1", 
                    rnw1)
                }
                else {
                  cmd <- sapply(1:length(sxpstarts), function(j) {
                    pos <- sxpstarts[j]
                    x <- substr(rnw1, pos, ifelse(j == length(sxpstarts), 
                      nchar(rnw1), sxpstarts[j + 1]))
                    return(sub(".*Sexpr *\\{([^}]+)\\}.*", "\\1", 
                      x))
                  })
                }
                cmd <- paste(c(paste0("## l. ", sxppos[i]), cmd), 
                  collapse = "\n")
            })
            return(c("\n\n#####  Sexpr expressions", cmds, "\n\n"))
        }
        else return()
    }
    all.cmds <- NULL
    cmd.blocks.pos <- grep("^<<", rnw)
    end.blocks.pos <- grep("^@", rnw)
    i = 1
    for (i in 1:length(cmd.blocks.pos)) {
        start <- cmd.blocks.pos[i]
        end <- end.blocks.pos[end.blocks.pos > start][1]
        blockname <- sub("<<(.*)>>=", "\\1", rnw[start])
        all.cmds <- c(all.cmds, "\n\n", paste0("######  Block \"", 
            blockname, "\" -- lines ", start, "-", end, "  ######\n"), 
            rnw[(start + 1):(end - 1)])
        all.cmds <- c(all.cmds, get.sexprs(end, ifelse((i + 1) <= 
            length(cmd.blocks.pos), cmd.blocks.pos[i + 1], length(rnw))))
    }
    cat("Results saved to", outfile, "\n")
    writeLines(all.cmds, outfile)
}
