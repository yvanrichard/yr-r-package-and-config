trim <-
function (x) 
{
    x2 <- sapply(x, function(y) gsub("^ *", "", y), USE.NAMES = F)
    x3 <- sapply(x2, function(y) gsub(" *$", "", y), USE.NAMES = F)
    return(x3)
}
