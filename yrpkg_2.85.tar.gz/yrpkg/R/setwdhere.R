setwdhere <-
function () 
{
    home <- Sys.getenv("HOME")
    here <- getwd()
    txt <- sprintf("setwd('%s')", sub(home, "~", here))
    cat(sprintf("\n%s\n\n", txt))
    File = pipe("xclip -i", "w")
    cat(txt, file = File)
    close(File)
}
