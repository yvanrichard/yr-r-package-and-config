sprect <-
function (xmin, xmax, ymin, ymax, p4s = "", ids = NULL, aslist = F) 
{
    n <- unique(c(length(xmin), length(xmax), length(ymin), length(ymax)))
    if (length(n) != 1) 
        stop("xmin, xmax, ymin, ymax do not have the same length")
    if (is.null(ids)) 
        ids <- as.character(1:n)
    rects <- sapply(1:n, function(i) {
        SpatialPolygons(list(Polygons(list(Polygon(cbind(x = c(xmin[i], 
            xmin[i], xmax[i], xmax[i], xmin[i]), y = c(ymin[i], 
            ymax[i], ymax[i], ymin[i], ymin[i])))), ids[i])), 
            proj4string = CRS(p4s))
    }, simplify = F)
    r <- rects[[1]]
    if (!aslist) {
        if (n > 1) {
            for (i in 2:n) {
                library(maptools)
                r <- spRbind(r, rects[[i]])
            }
        }
        return(r)
    }
    else return(rects)
}
