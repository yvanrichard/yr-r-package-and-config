get_stats <-
function (x, na.rm = T) 
{
    return(c(mean = mean(x, na.rm = na.rm), med = median(x, na.rm = na.rm), 
        lcl = quantile(x, 0.025000000000000001, names = F, na.rm = na.rm), 
        ucl = quantile(x, 0.97499999999999998, names = F, na.rm = na.rm)))
}
