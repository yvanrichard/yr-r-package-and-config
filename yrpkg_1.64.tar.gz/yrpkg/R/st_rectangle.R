st_rectangle <-
function (xmin, ymin, xmax, ymax, crs = 4326) 
{
    library(sf)
    rect <- st_polygon(list(matrix(c(xmin, ymin, xmin, ymax, 
        xmax, ymax, xmax, ymin, xmin, ymin), ncol = 2, byrow = T)))
    rect <- st_geometry(rect)
    st_crs(rect) <- crs
    return(rect)
}
