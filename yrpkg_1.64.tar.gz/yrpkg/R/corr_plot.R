corr_plot <-
function (df, with.diag.lines = F, use.dens.cols = T) 
{
    library(corrgram)
    panel.tri <- function(x, y, corr = NULL, col.regions, ...) {
        if (is.null(corr)) 
            corr <- cor(x, y, use = "pair")
        ncol <- 14
        pal <- col.regions(ncol)
        col.ind <- as.numeric(cut(corr, breaks = seq(from = -1, 
            to = 1, length = ncol + 1), include.lowest = TRUE))
        usr <- par("usr")
        rect(usr[1], usr[3], usr[2], usr[4], col = pal[col.ind], 
            border = NA)
        if (!is.na(corr)) {
            if (with.diag.lines) 
                rect(usr[1], usr[3], usr[2], usr[4], density = 5, 
                  angle = ifelse(corr > 0, 45, 135), col = "white")
            text(mean(usr[1:2]), mean(usr[3:4]), round(corr, 
                3), col = ifelse(abs(corr) > 0.55000000000000004, 
                "white", "black"))
        }
        box(col = "lightgray")
    }
    panel.diag <- function(x, corr = NULL, ...) {
        if (!is.null(corr)) 
            return()
        dd = density(x, na.rm = TRUE)
        xr = range(dd$x)
        yr = range(dd$y)
        par(usr = c(min(xr), max(xr), min(yr), max(yr) * 1.1000000000000001))
        plot.xy(xy.coords(dd$x, dd$y), type = "l", col = grey(0.69999999999999996), 
            ...)
        box(col = "lightgray")
        minx <- round(min(x, na.rm = TRUE), 2)
        maxx <- round(max(x, na.rm = TRUE), 2)
        usr <- par("usr")
        text(usr[1], usr[3], minx, cex = 0.80000000000000004, 
            adj = c(-0.10000000000000001, -0.10000000000000001))
        text(usr[2], usr[4], maxx, cex = 0.80000000000000004, 
            adj = c(1.1000000000000001, 1.1000000000000001))
    }
    panel.pts <- function(x, y, corr = NULL, col.regions, ...) {
        if (!is.null(corr)) 
            return()
        if (use.dens.cols) 
            cols <- densCols(x, y)
        else cols <- "#00000044"
        plot.xy(xy.coords(x, y), type = "p", col = cols, ...)
        box(col = "lightgray")
    }
    corrgram(df, order = FALSE, lower.panel = panel.tri, upper.panel = panel.pts, 
        text.panel = panel.txt, diag.panel = panel.diag, main = "", 
        pch = ".")
}
