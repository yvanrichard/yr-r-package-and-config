get_in_out_from_scripts <-
function (fold = ".", recursive = T, verbose = F, shorten.paths = T) 
{
    fls <- dir(fold, pattern = "\\.[rR]$|\\.[Rr]md$|\\.[Rr]nw", 
        full.names = T, recursive = recursive)
    istxt <- NULL
    for (i in seq_along(fls)) {
        a <- system(sprintf("file %s", fls[i]), intern = T)
        istxt <- c(istxt, ifelse(length(grep("text", a)), T, 
            F))
    }
    fls <- fls[istxt]
    outlist <- NULL
    for (f in fls) {
        if (verbose) {
            cat("\n")
            cat(f, ":\n")
            cat(paste(rep("-", nchar(f)), collapse = ""), "\n")
        }
        sc <- readLines(f)
        sc <- unwrap_cmds(sc)
        ins <- NULL
        rcsv <- grep("read\\.csv", sc, val = T)
        if (length(rcsv)) {
            withsq <- grepl("'.*'", rcsv)
            ins <- c(ins, gsub(".*'(.*)'.*", "\\1", rcsv[withsq]))
            withdq <- grepl("\".*\"", rcsv)
            ins <- c(ins, gsub(".*\"(.*)\".*", "\\1", rcsv[withdq]))
        }
        fcsv <- grep("fread\\(", sc, val = T)
        if (length(fcsv)) {
            withsq <- grepl("'.*'", fcsv)
            ins <- c(ins, gsub(".*'(.*)'.*", "\\1", fcsv[withsq]))
            withdq <- grepl("\".*\"", fcsv)
            ins <- c(ins, gsub(".*\"(.*)\".*", "\\1", fcsv[withdq]))
        }
        lds <- grep("load\\(", sc, value = T)
        if (length(lds)) {
            withsq <- grepl("'.*'", lds)
            ins <- c(ins, gsub(".*'(.*)'.*", "\\1", lds[withsq]))
            withdq <- grepl("\".*\"", lds)
            ins <- c(ins, gsub(".*\"(.*)\".*", "\\1", lds[withdq]))
        }
        rds <- grep("readRDS", sc, value = T)
        if (length(rds)) {
            withsq <- grepl("'.*'", rds)
            ins <- c(ins, gsub(".*'(.*)'.*", "\\1", rds[withsq]))
            withdq <- grepl("\".*\"", rds)
            ins <- c(ins, gsub(".*\"(.*)\".*", "\\1", rds[withdq]))
        }
        sources <- grep("source\\(", sc, value = T)
        if (length(sources)) {
            withsq <- grepl("'.*'", sources)
            ins <- c(ins, gsub(".*'(.*)'.*", "\\1", sources[withsq]))
            withdq <- grepl("\".*\"", sources)
            ins <- c(ins, gsub(".*\"(.*)\".*", "\\1", sources[withdq]))
        }
        if (is.null(ins)) 
            ins <- character(0)
        outs <- NULL
        rcsv <- grep("write\\.csv", sc, val = T)
        if (length(rcsv)) {
            withsq <- grepl("'.*'", rcsv)
            outs <- c(outs, gsub(".*'(.*)'.*", "\\1", rcsv[withsq]))
            withdq <- grepl("\".*\"", rcsv)
            outs <- c(outs, gsub(".*\"(.*)\".*", "\\1", rcsv[withdq]))
        }
        fcsv <- grep("fwrite", sc, val = T)
        if (length(fcsv)) {
            withsq <- grepl("'.*'", fcsv)
            outs <- c(outs, gsub(".*'(.*)'.*", "\\1", fcsv[withsq]))
            withdq <- grepl("\".*\"", fcsv)
            outs <- c(outs, gsub(".*\"(.*)\".*", "\\1", fcsv[withdq]))
        }
        lds <- grep("save\\(", sc, value = T)
        if (length(lds)) {
            withsq <- grepl("'.*'", lds)
            outs <- c(outs, gsub(".*'(.*)'.*", "\\1", lds[withsq]))
            withdq <- grepl("\".*\"", lds)
            outs <- c(outs, gsub(".*\"(.*)\".*", "\\1", lds[withdq]))
        }
        rds <- grep("saveRDS\\(", sc, value = T)
        if (length(rds)) {
            withsq <- grepl("'.*'", rds)
            outs <- c(outs, gsub(".*'(.*)'.*", "\\1", rds[withsq]))
            withdq <- grepl("\".*\"", rds)
            outs <- c(outs, gsub(".*\"(.*)\".*", "\\1", rds[withdq]))
        }
        ims <- grep("save\\.image\\(", sc, value = T)
        if (length(ims)) {
            withsq <- grepl("'.*'", ims)
            outs <- c(outs, gsub(".*'(.*)'.*", "\\1", ims[withsq]))
            withdq <- grepl("\".*\"", ims)
            outs <- c(outs, gsub(".*\"(.*)\".*", "\\1", ims[withdq]))
        }
        if (is.null(outs)) 
            outs <- character(0)
        outlist[[f]] <- list(ins = ins, outs = outs)
        if (verbose & length(c(ins, outs))) {
            cat("INPUTS:\n")
            print(ins)
            cat("OUTPUTS:\n")
            print(outs)
        }
    }
    inouts <- outlist
    dt <- rbindlist(lapply(names(inouts), function(r) {
        inputs <- inouts[[r]]$ins
        d <- as.data.table(rbind(stack(inouts[[r]]["ins"]), stack(inouts[[r]]["outs"])))
        d[, `:=`(script, r)]
        d
    }))
    dt[, `:=`(script, normalizePath(script))]
    dt[, `:=`(fold, dirname(script))]
    dt[, `:=`(dep, file.path(fold, values))]
    dt[, `:=`(exists, file.exists(dep))]
    dt[exists == T, `:=`(dep, normalizePath(dep))]
    dt[, `:=`(from, fifelse(ind == "ins", dep, script))]
    dt[, `:=`(to, fifelse(ind == "outs", dep, script))]
    if (shorten.paths) {
        paths <- dt[, tstrsplit(dep, "/")]
        ncommon <- which(apply(paths, 2, function(x) uniqueN(x) == 
            1) == F)[1] - 1
        if (ncommon > 0) {
            basedir <- paste0(do.call(file.path, paths[1, .SD, 
                .SDcols = names(paths)[seq_len(ncommon)]]), "/")
        }
        else basedir <- "/"
    }
    else basedir <- "/"
    dt[, `:=`(from, sub(basedir, "", from, fixed = T))]
    dt[, `:=`(to, sub(basedir, "", to, fixed = T))]
    dt[, `:=`(direction, fifelse(ind == "ins", "input", "output"))]
    dt <- dt[, .(direction, from, to, exists)]
    setattr(dt, "basedir", basedir)
    return(dt)
}
