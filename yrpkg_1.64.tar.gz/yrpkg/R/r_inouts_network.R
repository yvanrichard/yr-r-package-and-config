r_inouts_network <-
function (fold = ".", recursive = T, verbose = F) 
{
    inouts <- get_in_out_from_scripts(fold, recursive = recursive, 
        verbose = verbose)
    basedir <- attr(inouts, "basedir")
    nodes <- data.table(title = sort(unique(c(dt$from, dt$to))))
    nodes[, `:=`(type, fifelse(grepl("\\.[rR]$", title), "script", 
        fifelse(grepl("\\.[Rr]md$|\\.[Rr]nw$", title), "report", 
            fifelse(grepl("\\.png$|\\.pdf$", title), "output", 
                "data"))))]
    ncols <- c(script = "#4DAF4A", report = "#984EA3", output = "#377EB8", 
        data = "#FF7F00")
    nshps <- c(script = "square", report = "star", output = "diamond", 
        data = "triangle")
    nodes[, `:=`(id, sprintf("s%0.3i", seq_len(.N)))]
    nodes[, `:=`(exists, file.exists(file.path(basedir, title)))]
    nodes[, `:=`(shape, nshps[type])]
    nodes[, `:=`(shadow, !exists)]
    nodes[, `:=`(color, ncols[type])]
    nodes[exists == F, `:=`(color, "#E41A1C")]
    nodes[, `:=`(group, dirname(title))]
    nodes[, `:=`(label, basename(title))]
    nmasses <- c(script = 1, report = 10, output = 1, data = 5)
    nodes[, `:=`(mass, nmasses[type])]
    ecols <- c(input = "blue", output = "red")
    edges <- dt[, .(from_lab = from, to_lab = to, type = direction)]
    edges[nodes, `:=`(from, id), on = c(from_lab = "title")]
    edges[nodes, `:=`(to, id), on = c(to_lab = "title")]
    edges[, `:=`(color, ecols[type])]
    library(visNetwork)
    visNetwork(nodes, edges, width = "100%", height = "800px", 
        main = "Inputs/outputs in R scripts and documents", submain = paste0("File paths relative to ", 
            basedir)) %>% visEdges(arrows = "to", physics = T) %>% 
        visOptions(highlightNearest = list(enabled = T, degree = 1), 
            selectedBy = "type") %>% visIgraphLayout(physics = T, 
        smooth = F, type = "square", layout = "layout_with_mds")
}
