browsetable <-
function (dt, nowrap = F, ...) 
{
    DT::datatable(dt, filter = "top", class = sprintf("stripe %s hover compact", 
        fifelse(nowrap == T, "nowrap", "")), ...)
}
