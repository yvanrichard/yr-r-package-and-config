notif <-
function (title = "default title", text = "defaut message", apptoken = jsonlite::fromJSON("/home/yvan/.pushover")$apptoken, 
    usertoken = jsonlite::fromJSON("/home/yvan/.pushover")$usertoken) 
{
    if (text == "") 
        text <- "[no message]"
    system(sprintf("curl -s --form-string \"token=%s\" --form-string \"user=%s\" --form-string \"title=%s\" --form-string \"message=%s\" https://api.pushover.net/1/messages.json", 
        apptoken, usertoken, title, text))
    system(sprintf("notify-send \"%s\" \"%s\"", title, text))
}
