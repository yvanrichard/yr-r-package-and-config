latex.deps <-
function (depfile = "report.dep", root_dir = ".", git.add = T, 
    ctime = F, save = T, ext.ignore = c("sty", "def", "lbx", 
        "fd", "tfm", "cfg", "bbx", "cbx", "cnf", "clo", "fmt", 
        "cls", "map", "ldf", "dbx", "bbl", "out", "eps")) 
{
    if (!file.exists(depfile)) 
        stop("File `", depfile, "` does not exist. Make sure `\\RequirePackage{snapshot}` is in the tex file above `\\documentclass`")
    if (dirname(depfile) != ".") 
        stop("`depfile` needs to be in current directory")
    log <- readLines(depfile)
    log <- log[2L:(length(log) - 1)]
    deps <- data.table(type = sub("^[^{]+\\{([^{]+)\\}.*", "\\1", 
        log), file = sub("^[^{]+\\{[^{]+\\}[[:blank:]]*\\{([^{]+)\\}.*", 
        "\\1", log), version = sub("^[^{]+\\{[^{]+\\}[[:blank:]]*\\{[^{]+\\}[[:blank:]]*\\{([^{]+)\\}.*", 
        "\\1", log))
    deps[grep("[^.]+\\.", file), `:=`(ext, sub(".*[^.]+\\.([^.]+)$", 
        "\\1", file))]
    deps[, `:=`(exists, file.exists(file))]
    deps <- deps[exists & grepl("v0.0", version, fixed = T) & 
        !(ext %in% c(NA, ext.ignore))]
    deps <- deps[, .(source = sub(".dep", ".tex", depfile, fixed = T), 
        file)]
    rdatas <- system(sprintf("cd %s  &&  grep -i -R \"\\.rdata\" .", 
        root_dir), intern = T)
    csvs <- system(sprintf("cd %s  &&  grep -i -R \"\\.csv\" .", 
        root_dir), intern = T)
    rdss <- system(sprintf("cd %s  &&  grep -i -R \"\\.rds\" .", 
        root_dir), intern = T)
    txts <- system(sprintf("cd %s  &&  grep -i -R \"\\.txt\" .", 
        root_dir), intern = T)
    oth <- c(rdatas, csvs, rdss, txts)
    others <- data.table(match = c(rdatas, csvs, rdss, txts))
    others[, `:=`(source, sub("^\\./", "", sub("^([^:]+):.*", 
        "\\1", match)))]
    others[grep("[^.]+\\.", source), `:=`(ext, sub(".*[^.]+\\.([^.]+)$", 
        "\\1", source))]
    others <- others[ext %in% c("tex", "Rnw", "rnw")]
    others[grep("\\.rdata", match, ignore.case = T), `:=`(file, 
        sub(".*['\"]([-a-zA-Z0-9_/.]+)['\"].*", "\\1", match))]
    others[grep("\\.csv", match, ignore.case = T), `:=`(file, 
        sub(".*['\"]([-a-zA-Z0-9_/.]+)['\"].*", "\\1", match))]
    others[grep("\\.rds", match, ignore.case = T), `:=`(file, 
        sub(".*['\"]([-a-zA-Z0-9_/.]+)['\"].*", "\\1", match))]
    others[grep("\\.txt", match, ignore.case = T), `:=`(file, 
        sub(".*['\"]([-a-zA-Z0-9_/.]+)['\"].*", "\\1", match))]
    others[, `:=`(file, sprintf("%s/%s", root_dir, sub("^\\./", 
        "", file)))]
    others[, `:=`(source, sprintf("%s/%s", root_dir, source))]
    others <- others[, .(source, file)]
    deps <- rbind(others, deps)
    deps[, `:=`(ctime, file.info(file)$ctime)]
    deps[, `:=`(mtime, file.info(file)$mtime)]
    deps[, `:=`(tracked, sapply(file, is.git.tracked))]
    setorder(deps, -mtime)
    if (save) {
        fwrite(deps, "list-dependencies.csv")
    }
    cat("\n\n=== External files, sorted by mtime:\n\n")
    if (ctime) {
        print(deps[, .(source, file, ctime, mtime, tracked)])
    }
    else {
        print(deps[, .(source, file, mtime, tracked)])
    }
    if (git.add) {
        cat("\nGit command to add untracked files:\n```\ngit add -f", 
            deps[tracked == F, paste(file, collapse = " ")], 
            "\n```\n")
    }
}
