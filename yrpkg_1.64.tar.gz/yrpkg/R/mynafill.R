mynafill <-
function (x, ...) 
{
    if (!is.numeric(x)) {
        if (is.character(x)) {
            y <- factor(x)
            lvls <- levels(y)
        }
        else {
            y <- x
            lvls <- levels(x)
        }
        z <- nafill(as.integer(y), ...)
        z <- lvls[z]
    }
    else {
        z <- nafill(x, ...)
    }
    return(z)
}
