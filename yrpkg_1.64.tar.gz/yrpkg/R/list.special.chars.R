list.special.chars <-
function (txt, ok.chars = "-\na-zA-ZāēīōūĀĒĪŌŪï0-9 _,;.:@&%$?!=+()'\"/") 
{
    g <- regexpr(sprintf("[^%s]", ok.chars), txt)
    r <- regmatches(txt, g)
    d <- data.table(char = r)
    d <- d[, .N, char][order(-N)]
    d[, `:=`(ch_std, stringi::stri_escape_unicode(char))]
    return(d)
}
