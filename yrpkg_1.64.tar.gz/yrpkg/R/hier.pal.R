hier.pal <-
function (category, subcategory, spread.within = 0.29999999999999999, 
    chroma = 110, luminance = 70, alpha = 1) 
{
    cols0 <- data.table(id1 = category, id2 = subcategory)
    cols0[, `:=`(i, .I)]
    setkey(cols0, id1, id2)
    cols <- cols0[, .N, .(id1, id2)]
    ncats <- uniqueN(cols$id1)
    steps <- seq(0, 360, length.out = ncats + 1)
    diff <- steps[2] - steps[1]
    steps <- steps + diff/2
    steps <- head(steps, ncats)
    names(steps) <- unique(cols$id1)
    cols[, `:=`(step, steps[id1])]
    spread <- diff * spread.within/2
    cols[, `:=`(offset, seq(-spread, spread, length.out = .N)), 
        id1]
    cols[, `:=`(hue, step + offset)]
    cols[, `:=`(c, chroma + offset)]
    cols[, `:=`(l, luminance + offset)]
    cols[, `:=`(col, hcl(h = hue, c = c, l = l, alpha = alpha))]
    setorder(cols0, i)
    return(cols[cols0, col, on = c("id1", "id2")])
}
