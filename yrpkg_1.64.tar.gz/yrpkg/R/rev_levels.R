rev_levels <-
function (x) 
{
    if (is.factor(x)) {
        return(factor(as.character(x), levels = rev(levels(x))))
    }
    else warning(sQuote(eval(substitute(x))), " is not a factor. Not reversing levels")
}
