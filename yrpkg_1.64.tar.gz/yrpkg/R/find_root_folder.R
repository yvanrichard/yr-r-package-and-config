find_root_folder <-
function (from = getwd(), nullreturn = character(0)) 
{
    fold <- from
    atroot <- file.exists(sprintf("%s/.git", fold))
    while (!atroot & fold != "/") {
        fold <- dirname(fold)
        atroot <- file.exists(sprintf("%s/.git", fold))
    }
    if (atroot) {
        return(fold)
    }
    else return(nullreturn)
}
