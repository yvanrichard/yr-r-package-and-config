str2org <-
function (what, tmpfile = tempfile("str_output_"), open = T) 
{
    orgfile <- paste0(tmpfile, ".org")
    tryCatch({
        capture.output(str(what, list.len = 499), file = tmpfile)
    }, error = function(e) warning("Errors! ", as.character(e)))
    strout <- readLines(tmpfile)
    strout <- gsub("^([[:blank:].]*)\\.\\.\\$", "\\1.. .. $", 
        strout)
    strout <- gsub("^([[:blank:].]*)\\.\\.\\-", "\\1.. .. -", 
        strout)
    strout <- gsub("^[[:blank:]]*\\$", ".. $", strout)
    strout <- gsub("^([[:blank:].]*)\\[", "\\1.. [", strout)
    while (any(grepl("\\.\\. \\.", strout))) {
        strout <- gsub("[[:blank:]*]*\\.\\.([[:blank:]@$-]*[^.])", 
            "* \\1", strout)
    }
    strout <- sub(" - attr\\(\\*, ", "* (Attribute: ", strout)
    while (any(grepl("\\*[[:blank:]]+\\*", strout))) {
        strout <- gsub("\\*[[:blank:]]+\\*", "**", strout)
    }
    strout <- gsub("\\*[[:blank:]]+([$-])", "* \\1", strout)
    strout <- strout[!grepl("internal\\.selfref", strout)]
    strout <- strout[!grepl("__dim", strout)]
    strout <- strout[!grepl("Attribute.*index", strout)]
    strout <- c(strout, "* org conf", "#+STARTUP: indent", "#+STARTUP: showstars", 
        "#+STARTUP: showall", "#+INFOJS_OPT: view:info toc:true view:content tdepth:2", 
        "#+SETUPFILE: ~/.emacs.d/github_projects/org-html-themes/setup/theme-readtheorg.setup")
    writeLines(strout, orgfile, sep = "\n")
    if (open) 
        system(sprintf("emacsclient -n %s", orgfile), intern = F, 
            wait = F)
}
