namap <-
function (dt, alpha.trans = "sqrt") 
{
    namap0 <- as.data.table(lapply(dt, is.na))
    namap0 <- namap0[, .N, names(namap0)][order(-N)]
    na_n <- namap0$N
    namap0[, `:=`(row, seq_len(.N))]
    namap0[, `:=`(h, log(N + 1))]
    namap0[, `:=`(p, N/sum(N))]
    namap <- melt(namap0, id.vars = c("row", "N", "h", "p"), 
        measure.vars = setdiff(names(namap0), c("row", "N", "h", 
            "p")))
    g <- ggplot(namap, aes(x = variable, y = row, fill = value)) + 
        geom_tile(aes(alpha = N), size = 0, colour = "white") + 
        scale_fill_manual(name = "is NA?", values = c(`TRUE` = "#E41A1C", 
            `FALSE` = "#A6CEE3")) + scale_y_continuous(breaks = 1:max(namap$row), 
        labels = na_n, expand = c(0, 0), trans = "reverse") + 
        scale_x_discrete(position = "top") + scale_alpha_continuous(trans = alpha.trans, 
        guide = "none") + theme(axis.text.x.top = element_text(angle = 90, 
        hjust = 0, vjust = 0.5), panel.grid = element_blank()) + 
        labs(x = NULL, y = "No. rows")
    return(list(plot = g, h_w_ratio = nrow(namap0)/ncol(dt), 
        data = namap0))
}
