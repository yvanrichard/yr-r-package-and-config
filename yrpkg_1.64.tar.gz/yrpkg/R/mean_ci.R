mean_ci <-
function (x) 
return(c(mean = mean(x), lcl = quantile(x, 0.025000000000000001, 
    names = F), ucl = quantile(x, 0.97499999999999998, names = F)))
