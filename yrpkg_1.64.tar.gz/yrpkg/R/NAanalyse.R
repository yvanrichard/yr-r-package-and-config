NAanalyse <-
function (df, plotx = NULL, nx = 10, ncol = 4, mar = c(3, 3, 
    1, 1)) 
{
    library(data.table)
    if (!"data.table" %in% class(df)) 
        df <- data.table(df)
    sumna <- unlist(df[, lapply(.SD, function(x) sum(is.na(x)))])
    sna <- sort(sumna[sumna > 0], decreasing = T)
    cat("\n===", length(sna), "columns with some NAs (out of", 
        ncol(df), ",", round(100 * length(sna)/ncol(df), 1), 
        "%)\n")
    cat("\n-- Number of records that are NA:\n")
    print(sna)
    cat("\n-- Percentage of NAs:\n")
    propna <- sort(round(100 * sumna/nrow(df), 1), decreasing = T)
    print(propna[propna > 0])
    cat("\n===", sum(propna == 0), "columns without NAs:\n")
    print(names(propna[propna == 0]))
    naom <- na.omit(df)
    cat("\n===", nrow(naom), "rows without NAs (out of", nrow(df), 
        ",", round(100 * nrow(naom)/nrow(df), 1), "%)\n\n")
    if (!is.null(plotx)) {
        par(mfrow = c(ceiling(sum(sumna > 0)/ncol), ncol), mar = mar)
        for (v in names(df)) {
            if (any(is.na(df[[v]]))) {
                d1 <- unique(data.table(x = df[[plotx]], v = df[[v]]))
                d1 <- d1[order(d1$x), ]
                d2 <- d1[, .(nas = sum(is.na(x))), v]
                xx <- myreplace(pretty(1:nrow(d2), nx), c(0, 
                  1), verbose = F)
                xx <- xx[xx < length(d2)]
                xxl <- names(d2)[xx]
                plot(d2, type = "h", col = ifelse(d2 > 0, "red", 
                  "black"), axes = F, xlab = NA, ylab = NA)
                axis(1, at = xx, labels = xxl)
                axis(2, at = c(0, max(d2, na.rm = T)), las = 1)
                mtext(v, 3, line = -1.5, cex = 0.59999999999999998)
            }
        }
    }
}
