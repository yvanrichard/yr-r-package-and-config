minshareval <-
function (shares, wantedval) 
{
    wantedval/shares
}
