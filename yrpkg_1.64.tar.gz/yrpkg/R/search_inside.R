search_inside <-
function (l, what, simplify = T, fixed = T) 
{
    library(parallel)
    res <- lapply(seq_along(l), function(i) {
        cat("\n==============================\n", names(l)[i], 
            "\n")
        x <- l[[i]]
        if (is.function(x)) 
            return()
        if (!is.list(x)) {
            return(grep(what, x, fixed = fixed, val = T))
        }
        else if (length(dim(x)) > 0) {
            if (is.data.frame(x)) {
                xl <- as.list(x)
            }
            else {
                xl <- apply(x, 2, I)
            }
            r <- mclapply(xl, function(x1) {
                grep(what, x1, fixed = fixed)
            }, mc.cores = detectCores() - 1)
            r <- unlist(r)
            z <- nacolrm(x[r, ])
            return(z)
        }
        else return(search_inside(x, what))
    })
    names(res) <- names(l)
    if (simplify) 
        res <- res[sapply(res, length) > 0]
    return(res)
}
