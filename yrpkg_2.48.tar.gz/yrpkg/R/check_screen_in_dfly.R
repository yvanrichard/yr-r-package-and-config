check_screen_in_dfly <-
function (fold, comps = c("robin", "leon", "titi", "tieke", "frank", 
    "jeremy", "taiko"), user = "yvan") 
{
    cp <- comps[1]
    for (cp in comps) {
        cat("*****", cp, "\n")
        cmd <- sprintf("ssh -A %s@%s \"cd %s; tail screenlog.0\"", 
            user, cp, fold)
        cat(cmd, "\n")
        system(cmd, wait = T)
        cat("\n\n")
    }
}
