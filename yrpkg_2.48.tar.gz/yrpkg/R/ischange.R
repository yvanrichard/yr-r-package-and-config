ischange <-
function (x, first = T) 
{
    c(first, !x[1:(length(x) - 1)] == x[2:length(x)])
}
