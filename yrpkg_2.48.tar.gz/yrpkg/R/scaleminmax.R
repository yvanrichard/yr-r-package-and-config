scaleminmax <-
function (in.seq, out.min = 0, out.max = 1, in.ref.min = NA, 
    in.ref.max = NA) 
{
    if (!is.na(in.ref.min)) 
        in.seq <- c(in.ref.min, in.seq)
    if (!is.na(in.ref.max)) 
        in.seq <- c(in.ref.max, in.seq)
    in.max = max(in.seq, na.rm = T)
    in.min = min(in.seq, na.rm = T)
    in.range = diff(range(c(in.min, in.max)))
    out.range = diff(range(c(out.min, out.max)))
    if (in.range > 0) 
        ratio = out.range/in.range
    else ratio = 1
    out.seq <- (in.seq - in.min) * ratio + out.min
    if (!is.na(in.ref.max)) 
        out.seq <- out.seq[-1]
    if (!is.na(in.ref.min)) 
        out.seq <- out.seq[-1]
    return(out.seq)
}
