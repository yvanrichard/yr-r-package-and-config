draw.env <-
function (x = 1:length(lcl), lcl, ucl, fill = gray(0.9), line = gray(0.75)) 
{
    x = 1:length(lcl)
    polygon(c(x, rev(x), x[1]), c(ucl, rev(lcl), ucl[1]), border = NA, 
        col = fill)
    lines(x, ucl, col = line)
    lines(x, lcl, col = line)
}
