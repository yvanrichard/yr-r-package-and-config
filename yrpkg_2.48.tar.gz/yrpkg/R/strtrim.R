strtrim <-
function (x) 
{
    x2 <- gsub("^[[:blank:]]*", "", x)
    x3 <- gsub("[[:blank:]]*$", "", x2)
    return(x3)
}
