setupenv <-
function (envs = dir(".", "*.env$")) 
{
    parseval <- function(x) {
        done <- any(gregexpr("\\$\\([^\\)]+\\)", x)[[1]] == -1)
        while (!done) {
            locs <- gregexpr("\\$\\([^\\)]+\\)", x)[[1]]
            var <- substr(x, locs[1] + 2, locs[1] + attr(locs, 
                "match.length")[1] - 2)
            repl <- Sys.getenv(var)
            if (repl == "") {
                cat("\n")
                stop("Environment variable ", var, " not found in ", 
                  x)
            }
            x <- sub(sprintf("\\$\\(%s\\)", var), repl, x)
            done <- any(gregexpr("\\$\\([^\\)]+\\)", x)[[1]] == 
                -1)
        }
        return(x)
    }
    for (f in envs) {
        cat("\n=== Loading ", f, "\n")
        env <- readLines(f)
        env <- gsub("[[:blank:]]*=[[:blank:]]*", "=", gsub("[[:blank:]]+", 
            "", gsub("#.*$", "", env)))
        env <- env[env != ""]
        env <- do.call("rbind", strsplit(env, "="))
        for (i in 1:nrow(env)) {
            cat(env[i, 1], " ")
            repl <- parseval(env[i, 2])
            prev <- Sys.getenv(env[i, 1])
            if (prev != "" & prev != repl) 
                cat("\tOverwriting different value !!!\n\tWas:", 
                  prev, "\n\tNow:", repl)
            if (prev != "" & prev == repl) 
                cat("\tOverwriting same value")
            eval(parse(text = sprintf("Sys.setenv(%s = \"%s\")", 
                env[i, 1], gsub("\"", "", repl))))
            cat("\tok\n")
        }
        cat("\n")
    }
}
