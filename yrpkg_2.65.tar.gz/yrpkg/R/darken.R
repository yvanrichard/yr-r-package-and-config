darken <-
function (col, c = 0.3) 
{
    rgbs <- col2rgb(col, alpha = T)
    r <- rgbs["red", ]/255
    g <- rgbs["green", ]/255
    b <- rgbs["blue", ]/255
    a <- rgbs["alpha", ]/255
    rd <- r * (1 - c)
    gd <- g * (1 - c)
    bd <- b * (1 - c)
    newrgbs <- rgb(rd, gd, bd, a)
    names(newrgbs) <- names(col)
    return(newrgbs)
}
