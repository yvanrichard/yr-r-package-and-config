interms <-
function (y, min = 0) 
{
    if (max(y) < 5) 
        float = T
    else float = F
    x <- log(y + 1)
    x <- max(x)
    if (!float) 
        return(round(c(min, signif(exp(x/4) - 1, 1), signif(exp(x/2) - 
            1, 1), signif(exp(3 * x/4) - 1, 1), exp(x) - 1)))
    else return(c(min, signif(exp(x/4) - 1, 1), signif(exp(x/2) - 
        1, 1), signif(exp(3 * x/4) - 1, 1), round(exp(x) - 1, 
        3)))
}
