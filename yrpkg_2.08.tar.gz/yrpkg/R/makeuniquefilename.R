makeuniquefilename <-
function (x) 
{
    if (length(x) > 1) 
        stop("Function takes only one file name")
    x2 <- strsplit(x, ".", fixed = T)[[1]]
    x_1 <- paste(x2[1:(length(x2) - 1)], collapse = ".")
    ext <- ifelse(length(x2) > 1, sprintf(".%s", x2[length(x2)]), 
        "")
    fs <- grep(sprintf("^%s.*%s$", x_1, ext), dir(), value = T)
    fs1 <- sub(sprintf("%s", ext), "", fs)
    return(sprintf("%s%s", tail(make.names(c(fs1, x_1), unique = T), 
        1), ext))
}
