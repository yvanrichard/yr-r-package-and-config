checkgitprojects <-
function () 
{
    dirs <- system("ls -d ~/dragonfly/*/", intern = T)
    base <- getwd()
    for (d in dirs) {
        setwd(d)
        status <- suppressWarnings(system("git status", intern = T, 
            ignore.stderr = T))
        if (!length(attr(status, "status")) & !length(c(grep("nothing to commit", 
            status), grep("Not a git repository", status)))) {
            cat("\n######################################################################\n")
            cat("#### ", d, "\n")
            cat("######################################################################\n")
            cat(status, sep = "\n")
            cat("\n")
        }
    }
    setwd(base)
}
