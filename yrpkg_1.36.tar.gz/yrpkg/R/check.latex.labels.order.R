check.latex.labels.order <-
function (texbase = "./report.tex", with.inputs = T, ignores = c("sec", 
    "eq", "app")) 
{
    fold <- normalizePath(dirname(texbase))
    base <- basename(texbase)
    get.refs <- function(tex) {
        reflines <- grep("ref\\{", tex, val = T)
        r = reflines[1]
        refs <- as.vector(unlist(sapply(reflines, function(r) {
            matches <- gregexpr("ref\\{", r)[[1]]
            sapply(matches, function(m) {
                sub("ref\\{([^\\}]+)\\}.*", "\\1", substr(r, 
                  m, nchar(r)))
            })
        })))
        return(refs[!duplicated(refs)])
    }
    get.labels <- function(tex) {
        lablines <- grep("label\\{", tex, val = T)
        r = lablines[1]
        labs <- as.vector(unlist(sapply(lablines, function(r) {
            matches <- gregexpr("label\\{", r)[[1]]
            sapply(matches, function(m) {
                sub("label\\{([^\\}]+)\\}.*", "\\1", substr(r, 
                  m, nchar(r)))
            })
        })))
        return(labs)
    }
    tex <- readLines(texbase)
    inputs <- c(normalizePath(texbase), paste0(fold, "/", gsub(".*\\{(.*)\\}.*", 
        "\\1", grep("\\input\\{", tex, val = T)), ".tex"))
    allrefs <- do.call("rbind", sapply(inputs, function(inp) {
        tex <- readLines(inp)
        tex <- tex[!grepl("^[[:blank:]]*%", tex)]
        refs <- get.refs(tex)
        if (length(refs)) {
            return(data.frame(file = sub("\\.tex", "", basename(inp)), 
                ref = refs, stringsAsFactors = F))
        }
    }, simplify = F, USE.NAMES = F))
    alllabs <- do.call("rbind", sapply(inputs, function(inp) {
        tex <- readLines(inp)
        tex <- tex[!grepl("^[[:blank:]]*%", tex)]
        labs <- get.labels(tex)
        if (length(labs)) {
            return(data.frame(file = sub("\\.tex", "", basename(inp)), 
                lab = labs, stringsAsFactors = F))
        }
    }, simplify = F, USE.NAMES = F))
    if (any(duplicated(alllabs$lab))) {
        warning("Duplicated labels:  ", paste(alllabs$lab[duplicated(alllabs$lab)], 
            collapse = ", "))
    }
    for (i in ignores) {
        alllabs <- alllabs[!grepl(sprintf("^%s:", i), alllabs$lab), 
            ]
        allrefs <- allrefs[!grepl(sprintf("^%s:", i), allrefs$ref), 
            ]
        rownames(alllabs) <- NULL
        rownames(allrefs) <- NULL
    }
    cat("\n=== Labels not cited:\n")
    print(setdiff(alllabs$lab, allrefs$ref))
    alllabs$ref.pos <- match(alllabs$lab, allrefs$ref)
    alllabs$ref.file <- allrefs$file[match(alllabs$lab, allrefs$ref)]
    allrefs$lab.pos <- match(allrefs$ref, alllabs$lab)
    allrefs$lab.file <- alllabs$file[match(allrefs$ref, alllabs$lab)]
    return(list(labels = alllabs, refs = allrefs))
}
