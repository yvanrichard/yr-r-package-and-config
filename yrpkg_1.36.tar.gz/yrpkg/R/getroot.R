getroot <-
function (target = ".git") 
{
    path <- getwd()
    atroot <- file.exists(file.path(path, target))
    i <- 0
    while (!atroot & path != "/") {
        i <- i + 1
        path <- dirname(path)
        atroot <- file.exists(file.path(path, target))
    }
    if (!atroot & path == "/") {
        warning("Root path not found")
        return(character(0))
    }
    else return(normalizePath(path))
}
