replace_nas <-
function (DT) 
{
    for (j in seq_len(ncol(DT))) {
        if (is.numeric(DT[[j]])) 
            set(DT, which(is.na(DT[[j]])), j, 0)
    }
}
