distance2target <-
function (rast, target_value, na_value = -99999, use_input_nodata = T) 
{
    rast[is.na(rast)] <- na_value
    tmp <- tempfile()
    writeRaster(rast, tmp, "GTiff")
    system(sprintf("gdal_proximity.py %1$s.tif %1$s_out.tif -values %2$s -nodata %3$f -use_input_nodata %4$s", 
        tmp, target_value, na_value, ifelse(use_input_nodata, 
            "YES", "NO")))
    r <- raster(sprintf("%s_out.tif", tmp))
    r[r[] == na_value] <- NA
    return(r)
}
