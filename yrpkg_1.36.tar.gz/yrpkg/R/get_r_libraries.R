get_r_libraries <-
function (fold = ".") 
{
    library(data.table)
    cmd1 <- sprintf("grep -r --include=\"*.r\" --include=\"*.R\" \"library(\" %s", 
        fold)
    res1 <- suppressWarnings(system(cmd1, intern = T))
    cmd2 <- sprintf("grep -r --include=\"*.r\" --include=\"*.R\" \"require(\" %s", 
        fold)
    res2 <- suppressWarnings(system(cmd2, intern = T))
    res <- c(res1, res2)
    res <- as.data.table(do.call(rbind, strsplit(res, ":")))
    setnames(res, c("file", "library"))
    res <- res[!grepl("^[[:blank:]]*#", library)]
    res[, `:=`(library, trimws(library))]
    res[, `:=`(library, sub(".*library\\((.*)\\).*", "\\1", library))]
    res[, `:=`(library, sub(".*require\\((.*)\\).*", "\\1", library))]
    summ <- res[, .N, library]
    summ[, `:=`(lib, tolower(library))]
    setorder(summ, lib)
    print(summ[, -"lib", with = F])
    return(summ[, library])
}
