dfly_pal <-
function (what = NULL) 
{
    pal <- c(blue = "#43A1C9", grey = "#565659", cream = "#E5DECC", 
        green = "#50AD85", orange = "#EB7A59", red = "#CF4547", 
        purple = "#5B3456", mint = "#9DC4A9")
    if (is.null(what)) {
        return(pal)
    }
    if (is.character(what)) {
        if (what %in% names(pal)) {
            return(pal[what])
        }
        else stop("Colour not in palette")
    }
    else if (is.numeric(what)) {
        return(pal[what])
    }
}
