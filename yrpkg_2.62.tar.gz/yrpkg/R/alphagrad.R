alphagrad <-
function (n, grad = "exp", curv = 20, inv = F) 
{
    if (curv <= 1) 
        stop("Choose a value above 1")
    if (grad == "exp") {
        alphas <- exp(seq(curv, 1, length.out = n))
        alphas <- (alphas - min(alphas))/max(alphas - min(alphas))
    }
    else if (grad == "log") {
        alphas <- log(seq(curv, 1, length.out = n))
        alphas <- (alphas - min(alphas))/max(alphas - min(alphas))
    }
    else alphas <- seq(1, 0, length.out = n)
    if (inv) 
        cols <- rev(alpha(rep("#FFFFFF", n), alphas))
    else cols <- alpha(rep("#FFFFFF", n), alphas)
    return(cols)
}
