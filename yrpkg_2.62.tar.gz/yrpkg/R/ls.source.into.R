ls.source.into <-
function (sourcefile) 
{
    e1 <- new.env()
    source(sourcefile, local = e1)
    ls.str(envir = e1)
}
