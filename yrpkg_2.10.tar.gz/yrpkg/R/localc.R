localc <-
function (df, row.names = T, newl.at = 100, ...) 
{
    f <- makeuniquefilename("/tmp/temp.csv")
    if (!is.na(newl.at)) {
        nch = apply(df, 2, function(x) max(nchar(as.character(x))))
        toolongcols = names(nch[nch > newl.at])
        for (c in toolongcols) {
            df[, c] <- as.character(df[, c])
            toolongvals = nchar(df[[c]]) > newl.at
            df[toolongvals, c] <- sapply(df[toolongvals, c], 
                function(x) {
                  s = strsplit(x, "")[[1]]
                  s1 = grep("[[:blank:]]", s)
                  s0 = c(seq(1, nchar(x), newl.at), nchar(x))
                  i = findInterval(s1, s0, rightmost.closed = T)
                  s2 = s1[(i[-length(i)] - i[-1]) == -1]
                  s[s2] <- "\n"
                  return(paste(s, collapse = ""))
                })
        }
    }
    write.csv(as.data.frame(df), f, row.names = row.names, ...)
    res <- system(sprintf("localc %s", f), wait = F)
}
