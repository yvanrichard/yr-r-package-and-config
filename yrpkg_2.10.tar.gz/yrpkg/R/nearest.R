nearest <-
function (x, val = 0.2) 
{
    coeff <- 1/val
    return(round(x * coeff)/coeff)
}
