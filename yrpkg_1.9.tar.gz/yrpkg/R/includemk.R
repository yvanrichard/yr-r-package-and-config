includemk <-
function (mk = "vars.mk") 
{
    op <- options("useFancyQuotes")
    options(useFancyQuotes = F)
    mk <- readLines(mk)
    mk <- mk[grep("=", mk)]
    r <- rapply(strsplit(mk, "="), trim, how = "replace")
    txt <- sapply(r, function(x) {
        var <- x[1]
        val <- type.convert(x[2], as.is = T)
        if (typeof(val) == "character") 
            val <- sQuote(x[2])
        return(paste(var, val, sep = "="))
    })
    eval(parse(text = txt), envir = globalenv())
    options(useFancyQuotes = op)
}
