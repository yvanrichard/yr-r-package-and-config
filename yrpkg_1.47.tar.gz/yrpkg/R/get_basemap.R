get_basemap <-
function (x = NULL, y = NULL, xcent = NULL, ycent = NULL, zoom = NULL, 
    maptype = "roadmap", filename = "basemap", style = c(feature = "all", 
        element = "labels", visibility = "off"), color = "bw") 
{
    library(ggmap)
    if (is.null(xcent) & is.null(ycent)) {
        if (is.null(x) | is.null(y)) 
            stop("Need x and y to calculate missing centre x and y")
        xcent <- mean(range(x), na.rm = T)
        ycent <- mean(range(y), na.rm = T)
    }
    if (is.null(zoom)) {
        if (is.null(x) | is.null(y)) 
            stop("Need x and y to calculate zoom")
        zoom <- calc_zoom(extendrange(x), extendrange(y))
    }
    gm <- get_googlemap(c(xcent, ycent), zoom = zoom, maptype = "roadmap", 
        filename = "roadmap", style = c(feature = "all", element = "labels", 
            visibility = "off"), color = "bw")
    bb <- unlist(attr(gm, "bb"))
    while (any(x < bb[["ll.lon"]] | x > bb[["ur.lon"]] | y < 
        bb[["ll.lat"]] | y > bb[["ur.lat"]])) {
        zoom <- zoom - 1
        gm <- get_googlemap(c(xcent, ycent), zoom = zoom, maptype = maptype, 
            filename = filename, style = style, color = color)
        bb <- unlist(attr(gm, "bb"))
    }
    cat(sprintf("Basemap with zoom = %i, X center = %f, Y center = %f\n", 
        zoom, xcent, ycent))
    return(gm)
}
