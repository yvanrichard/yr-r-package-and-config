color.gradient <-
function (x, colors = c("red", "yellow", "green"), colsteps = 100) 
{
    return(colorRampPalette(colors)(colsteps)[findInterval(x, 
        seq(min(x), max(x), length.out = colsteps))])
}
