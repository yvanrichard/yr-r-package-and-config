get_fishing_group <-
function (method = NA, fishery = NA, target = NA, vessel = NA, 
    class = NA, start_date = NA) 
{
    ifelse(fishery == "FLAT", 20, ifelse(fishery == "INST" | 
        (fishery %in% c("LINT", "MIDT", "HAKT", "HOKT") & class == 
            "S"), 1, ifelse(class == "S" & fishery == "BNSB", 
        4, ifelse(class == "S" & fishery %in% c("HAPB", "MINB"), 
            5, ifelse(class == "S" & fishery %in% c("LINB"), 
                23, ifelse(class == "S" & fishery %in% c("SNAB"), 
                  6, ifelse(class == "L" & method == "BLL", 9, 
                    ifelse((class == "L" | (is.na(class) & fishery == 
                      "STNS")) & method == "SLL", 10, ifelse(class == 
                      "S" & method == "SLL" & fishery != "SWOS", 
                      11, ifelse(class == "S" & method == "SLL" & 
                        fishery == "SWOS", 22, ifelse(class == 
                        "L" & fishery %in% c("LINT", "MIDT", 
                        "HAKT", "HOKT") & (vessel %in% c(15169, 
                        12487, 12906, 12903, 15289, 20687, 6620, 
                        11036, 15042, 15398, 13006, 6061, 15585, 
                        11644, 8591, 20876, 5995, 6610, 15014, 
                        15500, 6618, 6138, 15039, 13313, 5530, 
                        5933, 6154, 21482) | (vessel == 12368 & 
                        as.Date(start_date) >= as.Date("2001-01-01"))), 
                        12, ifelse(class == "L" & fishery %in% 
                          c("LINT", "MIDT", "HAKT", "HOKT") & 
                          (vessel %in% c(3725, 15532, 8609, 8601, 
                            333, 6129, 11138, 5250, 1193, 1195, 
                            8800, 327, 13106, 360, 3763, 9259, 
                            12600, 11338, 5262, 5247, 8700, 20809, 
                            359, 804) | (vessel == 6096 & as.Date(start_date) < 
                            as.Date("2007-01-01"))), 13, ifelse(class == 
                          "L" & fishery %in% c("LINT", "MIDT", 
                          "HAKT", "HOKT") & (vessel %in% c(3704, 
                          5558, 8040, 21356, 20610, 20884, 20864, 
                          6984, 5663, 13521, 6944, 5458, 6473, 
                          6645, 5981, 8804, 5906, 5921, 5803, 
                          13009, 1356, 12599, 6730, 6489, 3351, 
                          20766, 5605, 1282, 15256, 9921) | (vessel == 
                          12368 & as.Date(start_date) < as.Date("2001-01-01")) | 
                          (vessel == 6096 & as.Date(start_date) >= 
                            as.Date("2007-01-01"))), 2, ifelse((is.na(class) | 
                          class == "L") & fishery %in% c("LINT", 
                          "MIDT", "HAKT", "HOKT"), 3, ifelse(fishery == 
                          "SBWT", 15, ifelse(fishery == "SCIT", 
                          16, ifelse(fishery == "MACT", 17, ifelse(fishery == 
                            "SQUT", 18, ifelse(fishery == "DPWT", 
                            19, ifelse(method == "SN", 21, 0))))))))))))))))))))
}
