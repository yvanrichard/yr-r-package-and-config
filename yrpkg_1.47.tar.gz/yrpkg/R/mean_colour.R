mean_colour <-
function (twocols = c("#fff3e1", "#fcb045")) 
{
    if (length(twocols) != 2) 
        stop("A vector of two colors is needed")
    return(colorRampPalette(twocols)(3)[2])
}
