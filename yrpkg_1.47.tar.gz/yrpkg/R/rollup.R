rollup <-
function (x, j, by, level = FALSE) 
{
    library(data.table)
    stopifnot(is.data.table(x), is.character(by), length(by) >= 
        2L, is.logical(level))
    j = substitute(j)
    aggrs = rbindlist(c(lapply(1:(length(by) - 1L), function(i) x[, 
        eval(j), c(by[1:i])][, `:=`((by[-(1:i)]), NA)]), list(x[, 
        eval(j), c(by)]), list(x[, eval(j)][, `:=`(c(by), NA)])), 
        use.names = TRUE, fill = FALSE)
    if (level) 
        aggrs[, `:=`(c("level"), sum(sapply(.SD, is.na))), 1:nrow(aggrs), 
            .SDcols = by]
    setcolorder(aggrs, neworder = c(by, names(aggrs)[!names(aggrs) %in% 
        by]))
    setorderv(aggrs, cols = by, order = 1L, na.last = TRUE)
    return(aggrs[])
}
