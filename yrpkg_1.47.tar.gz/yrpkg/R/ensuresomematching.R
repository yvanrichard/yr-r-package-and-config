ensuresomematching <-
function (x, outfun = warning) 
{
    condtxt <- deparse(substitute(x))
    if (class(x) == "logical") {
        if (!any(x)) {
            outfun(sQuote(condtxt), " does not match any record")
        }
    }
    else {
        if (!length(x)) {
            outfun(sQuote(condtxt), " does not match any record")
        }
    }
    return(x)
}
