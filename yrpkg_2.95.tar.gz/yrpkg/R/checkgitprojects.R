checkgitprojects <-
function () 
{
    dirs <- system("ls -d ~/dragonfly/*/", intern = T)
    base <- getwd()
    d = dirs[1]
    for (d in dirs) {
        cat("\n######################################################################\n")
        cat("#### ", d, "\n")
        cat("######################################################################\n")
        setwd(d)
        status <- system("git status", intern = T)
        cat(status, sep = "\n")
        cat("\n")
    }
    setwd(base)
}
