corr <-
function (dat, depvar, corrtype = "spearman") 
{
    library(data.table)
    corrvars <- setdiff(names(dat)[sapply(names(dat), function(v) class(dat[[v]])) == 
        "numeric"], depvar)
    corrs <- rbindlist(lapply(corrvars, function(v) {
        if (sd(dat[[v]]) > 0) {
            corr <- cor(dat[[depvar]], dat[[v]], method = corrtype)
        }
        else corr <- NA
        data.table(depvar = depvar, corrvar = v, corr = corr, 
            corrtype = corrtype)
    }))
    return(corrs[order(-abs(corr))])
}
