clicks2extent <-
function (verbose = T) 
{
    xys <- locator(2)
    xys <- matrix(c(range(xys$x), range(xys$y)), nrow = 2, byrow = T)
    ext <- extent(xys)
    if (verbose) 
        dput(ext)
    return(ext)
}
