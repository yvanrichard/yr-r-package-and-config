read.mcmc.dt <-
function (fold) 
{
    library(data.table)
    chain.files <- sort(dir(fold, "CODAchain", full.names = T))
    mc <- rbindlist(lapply(1:length(chain.files), function(i) {
        cat("Reading chain", i, "\n")
        v <- fread(chain.files[i])
        cbind(ch = i, idx = 1:nrow(v), v)
    }))
    if (!length(index.file)) 
        stop("Index file not found")
    index.file <- sort(dir(fold, "CODAindex", full.names = T))
    index <- fread(index.file)
    index[, `:=`(variable, sub("\\[[0-9]+\\]", "", V1))]
    index[, `:=`(variable, factor(variable, levels = unique(variable)))]
    index[, `:=`(V1, factor(V1, levels = unique(V1)))]
    inds <- tstrsplit(index[, ifelse(grepl("\\[", V1), sub(".*\\[(.*)\\].*", 
        "\\1", V1), NA)], ",", type.convert = T, names = F)
    names(inds) <- paste0("ind", 1:length(inds))
    index <- cbind(index, as.data.table(inds))
    setkey(index, variable, V1)
    ind <- index[, .(idx = V2:V3), keyby = .(variable, V1)][index]
    setnames(ind, "V1", "par")
    mc <- merge(mc, ind[, -c("V2", "V3"), with = F], by = "idx", 
        sort = F, all.x = T)
    setnames(mc, c("V1", "V2"), c("iter", "value"))
    setorder(mc, variable, par, ch, idx)
    mc[, `:=`(sample, 1:.N), par]
    return(mc)
}
