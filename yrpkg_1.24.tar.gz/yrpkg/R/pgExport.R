pgExport <-
function (shp, tablename = "tmpshp", dbname = "mygis", dbuser = "dba", 
    verb = T) 
{
    if (!grepl("^Spatial[PL]", class(shp))) 
        stop("Object to export is not spatial")
    if (!is.null(attr(suppressWarnings(system(sprintf("psql -lqt | cut -d \\| -f 1 | grep -w %s", 
        dbname), intern = T)), "status"))) {
        if (verb) 
            cat("\nCreating mygis database...\n")
        system(sprintf("createdb %s", dbname))
        system(sprintf("psql -c 'create extension postgis' %s -U %s", 
            dbname, dbuser))
        system(sprintf("psql -c 'create extension postgis_topology' %s -U %s", 
            dbname, dbuser))
    }
    library(rgdal)
    if (verb) 
        cat(sprintf("\nExporting to %s database...\n", dbname))
    if (!grepl("DataFrame", class(shp))) 
        shp <- as(shp, paste0(class(shp), "DataFrame"))
    writeOGR(shp, "/tmp", tablename, "ESRI Shapefile", overwrite_layer = T)
    system(sprintf("psql %s -U %s -c 'drop table if exists %s'", 
        dbname, dbuser, tablename))
    system(sprintf("shp2pgsql /tmp/%s.shp | psql %s -U %s", tablename, 
        dbname, dbuser))
    proj <- proj4string(shp)
    if (grepl("epsg:[0-9]+ ", proj)) {
        proj4 <- sub(".*epsg:([0-9]+) .*", "\\1", proj)
        system(sprintf("psql %s -U %s -c 'update %s set geom = st_setsrid(geom, %s)'", 
            dbname, dbuser, tablename, proj4))
    }
    else warning("No epsg found in input object, projection not set in Postgres")
}
