makeseq <-
function (x) 
{
    if (class(x) != "character") 
        return(NA)
    x <- unlist(strsplit(x, ","))
    areranges <- grepl("-", x)
    return(sort(unique(c(as.numeric(x[!areranges]), unlist(sapply(x[areranges], 
        function(x) {
            x <- as.numeric(unlist(strsplit(x, "-")))
            return(seq(x[1], x[2]))
        }))))))
}
