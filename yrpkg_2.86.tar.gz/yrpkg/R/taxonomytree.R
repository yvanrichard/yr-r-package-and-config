taxonomytree <-
function (spp, clean.names = T, verbose = T) 
{
    library(taxize)
    library(data.table)
    if (clean.names) {
        sppp <- gsub("_", " ", as.character(spp))
        sppp <- sub("\\bsubsp.*$", "", sppp)
        sppp <- gsub("[0-9]", "", sppp)
        sppp <- gsub("\\(.*\\)", "", sppp)
        sppp <- gsub("\\bsp\\.", "", sppp)
        sppp <- gsub("\\b[a-zA-Z]\\b", "", sppp)
        sppp <- gsub("^[[:blank:]]+|[[:blank:]]+$", "", sppp)
    }
    else sppp <- spp
    if (verbose) 
        cat("Getting uids...\n")
    uid <- get_uid(sppp)
    if (verbose) 
        cat("Getting classification...\n")
    cl <- classification(uid)
    if (verbose) 
        cat("Re-organising results...\n")
    l <- lapply(cl, function(x) {
        print(tail(x, 1))
        if (class(x) == "data.frame") {
            y <- x[x$rank != "no rank", ]
            dt <- as.data.table(t(y$name))
            setnames(dt, names(dt), y$rank)
        }
        else {
            dt <- data.table(kingdom = NA, order = NA, family = NA, 
                genus = NA, species = NA)
        }
        return(dt)
    })
    l2 <- rbindlist(l, fill = T)
    l2 <- l2[, names(l[[which.max(sapply(l, length))]]), with = F]
    l3 <- data.table(orig_spp = sppp, l2)
    return(l3)
}
