graph_makefile <-
function (makefile = "makefile") 
{
    opt <- options("useFancyQuotes")
    options(useFancyQuotes = FALSE)
    cola <- "\"#FFC6AF\""
    colp <- "\"#FFF8AF\""
    cold <- "\"#97DDBF\""
    colg <- "\"#B89DDC\""
    colf <- "\"#C2C2C2\""
    colu <- "\"#E2E2E2\""
    colc <- "grey98"
    progtypes <- "\\.r\"|\\.py\"|\\.bug\"|\\.cmd\"|\\.sh\""
    datatypes <- "\\.rdata\"|\\.csv\"|\\.Rdata\""
    graphtypes <- "\\.pdf\"|\\.png\""
    gettype <- function(z) {
        pp <- grep(progtypes, z, value = T)
        dd <- grep(datatypes, z, value = T)
        gg <- grep(graphtypes, z, value = T)
        ff <- z[!grepl("\\.", z) & !(z %in% c(pp, dd, gg))]
        uu <- z[!(z %in% c(pp, dd, ff, gg))]
        return(list(u = paste(uu, collapse = " "), p = paste(pp, 
            collapse = " "), g = paste(gg, collapse = " "), f = paste(ff, 
            collapse = " "), d = paste(dd, collapse = " ")))
    }
    mdir <- dirname(makefile)
    mk <- readLines(makefile, warn = F)
    mk <- gsub("^ *", "", mk)
    mk <- mk[grepl("^\t", mk) | !grepl("=", mk) | grepl("=[']", 
        mk)]
    mk <- mk[!(grepl("^include", mk))]
    mk <- mk[!(grepl("\\.PHONY", mk))]
    parts <- mk[(!grepl("#+.*:", mk) & grepl(":", mk) & !grepl("^\t", 
        mk)) | grepl("<!.*!>", mk)]
    ispart <- grepl("<!.*!>", parts)
    if (any(ispart)) {
        partlabs <- ifelse(grepl("<!.*!>", parts), trim(gsub(".*<!(.*)!>.*", 
            "\\1", parts)), NA)
        ts <- cumsum(is.na(partlabs))
        ps <- list()
        wh <- which(!is.na(partlabs))
        for (i in 1:length(wh)) ps[[partlabs[wh[i]]]] <- ts[(wh[i] + 
            1):ifelse(i != length(wh), wh[i + 1] - 1, length(ts))]
        nps <- ts[is.na(partlabs) & !(ts %in% unlist(ps))]
        withclusters <- T
    }
    else withclusters <- F
    mk <- mk[!grepl("^#", mk)]
    mk <- sub("\t$", "", mk)
    mk <- sub("([^ ])\\\\", "\\1 \\\\", mk)
    mk <- mk[mk != ""]
    c <- grepl(":", mk) & !grepl("^\t", mk) & !grepl("#.*:", 
        mk)
    mk[c] <- gsub("\t", " ", mk[c])
    mk2 <- paste(mk, collapse = "&&&&")
    mk3 <- gsub("&&&&&&&&*", "&&&&", mk2)
    mk4 <- gsub("\\\\&&&&*\t*", "", mk3)
    mk5 <- gsub("&&&&\t", "\t", mk4)
    mk5 <- gsub("::+", "**", mk5)
    m <- strsplit(mk5, "&&&&")[[1]]
    withaction <- grepl("\t", m)
    notarget <- !grepl(":", m)
    if (any(notarget)) {
        print(m[notarget])
        stop("Some targets missing")
    }
    sm <- strsplit(m, ":")
    all <- sapply(sm, function(x) {
        targs <- x[1]
        other <- sapply(x[-1], function(y) strsplit(y, "\t")[[1]], 
            USE.NAMES = F, simplify = F)[[1]]
        if (!grepl("^ *$", other[1])) {
            deps <- gsub("  +", " ", trim(other[1]))
            deps <- strsplit(deps, " ")[[1]]
            acts <- other[-1]
            if (!length(other[-1])) 
                acts <- NA
        }
        else {
            deps <- NA
            acts <- other[-1]
        }
        return(list(targs = trim(targs), deps = trim(deps), acts = trim(acts)))
    }, simplify = F)
    all <- rapply(all, function(x) gsub("'|\"", "", x), how = "replace")
    if (withclusters) 
        clusters <- sapply(ps, function(x) sapply(all[x], function(y) y$targs), 
            simplify = F)
    all2 <- all
    all2 <- sapply(all2, function(x) {
        y <- x$acts
        y <- gsub("\"", "", y)
        y <- unlist(strsplit(y, " *&& *"))
        if (!any(is.na(y))) 
            y <- paste(y, collapse = "\\n")
        x$acts <- y
        return(x)
    }, simplify = F)
    all2 <- rapply(all2, function(x) return(ifelse(is.na(x), 
        NA, dQuote(x))), how = "replace")
    gf <- "digraph G {\nrankdir=BT; nodesep=0.1; ranksep=0.2; ratio=0.66; margin=1;\n"
    if (withclusters) {
        for (i in 1:length(ps)) {
            a <- all2[ps[[i]]]
            td <- unique(unlist(sapply(a, function(x) return(na.omit(c(x$targs, 
                x$deps))))))
            ac <- unique(unlist(sapply(a, function(x) return(na.omit(x$acts)))))
            els <- gettype(td)
            gf <- c(gf, sprintf("subgraph cluster%1$i {\nlabel=%2$s; style=\"rounded,filled\"; color=gray50; fillcolor=%3$s; fontcolor=red; fontsize=20;", 
                i, dQuote(names(ps)[i]), colc))
            gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;", 
                colu, els$u))
            gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;", 
                colp, els$p))
            gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;", 
                cold, els$d))
            gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;", 
                colg, els$g))
            gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;", 
                colf, els$f))
            gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;}", 
                cola, paste(ac, collapse = " ")))
        }
    }
    if (withclusters) {
        nodesinclust <- na.omit(unlist(all2[unlist(ps)]))
        a <- all2[nps]
    }
    else {
        a <- all2
        nodesinclust <- NULL
    }
    targsdeps <- unique(unlist(sapply(a, function(x) return(na.omit(c(x$targs, 
        x$deps))))))
    targsdeps <- targsdeps[!(targsdeps %in% nodesinclust)]
    acts <- unique(unlist(sapply(a, function(x) return(na.omit(x$acts)))))
    acts <- acts[!(acts %in% nodesinclust)]
    td <- unique(unlist(sapply(a, function(x) return(na.omit(c(x$targs, 
        x$deps))))))
    ac <- unique(unlist(sapply(a, function(x) return(na.omit(x$acts)))))
    els <- gettype(td)
    gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;", 
        colu, els$u))
    gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;", 
        colp, els$p))
    gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;", 
        cold, els$d))
    gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;", 
        colg, els$g))
    gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;", 
        colf, els$f))
    gf <- c(gf, sprintf("node [fontsize=16, height=.3, style=\"rounded,filled\", fillcolor=%1$s, shape=rectangle] %2$s;", 
        cola, paste(ac, collapse = " ")))
    i = 2
    for (i in 1:length(all)) {
        op <- all2[[i]]
        if (!is.na(op$acts)) {
            if (all(!is.na(op$deps))) {
                gf <- c(gf, sprintf("{%s} -> %s;", paste(op$deps, 
                  collapse = "; "), paste(op$acts, collapse = "\\n")))
            }
            gf <- c(gf, sprintf("%s -> %s;", paste(op$acts, collapse = "\\n"), 
                op$targs))
        }
        else {
            gf <- c(gf, sprintf("{%s} -> %s;", paste(op$deps, 
                collapse = "; "), op$targs))
        }
    }
    gf <- c(gf, "}")
    dotfile <- sprintf("%s/graph-makefile.dot", mdir)
    pdffile <- sub(".dot", ".pdf", dotfile, fixed = T)
    cat(gf, sep = "\n", file = dotfile)
    options(useFancyQuotes = opt)
    system(sprintf("dot -Tpdf %s -o %s", dotfile, pdffile))
    system(sprintf("xdot %s", dotfile), wait = F)
}
