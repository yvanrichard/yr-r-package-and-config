cbind0 <-
function (x, y) 
{
    row.names <- sort(unique(c(rownames(x), rownames(y))))
    z <- as.data.frame(cbind(x[row.names, , drop = F], y[row.names, 
        , drop = F]))
    rownames(z) <- row.names
    return(z)
}
