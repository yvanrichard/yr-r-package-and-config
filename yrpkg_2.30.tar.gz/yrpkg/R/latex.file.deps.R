latex.file.deps <-
function (fold = ".", ignore = c("^/usr/|^/var/lib|^/etc/tex"), 
    only = c("/"), recursive = T, save_untracked = T) 
{
    alldeps <- NULL
    prevdir <- getwd()
    setwd(fold)
    rnw <- dir(".", "*.rnw$|*.Rnw$", recursive = recursive)
    r1 = rnw[1]
    for (r1 in rnw) {
        cat("\n************  ", r1, "  ************\n")
        r <- readLines(r1)
        c1 <- grep("\\bload\\(", r, value = T)
        fs <- sub("load\\('(.*)'\\)$", "\\1", c1)
        alldeps <- c(alldeps, fs)
        cat(paste(fs, collapse = "\n"))
        cat("\n")
        c2 <- grep("\\bread.csv\\(", r, value = T)
        fs <- sub("read.csv\\('(.*)'\\)$", "\\1", c2)
        alldeps <- c(alldeps, fs)
        cat(paste(fs, collapse = "\n"))
        cat("\n")
    }
    tex <- dir(".", "*.tex$", recursive = recursive)
    tex <- tex[!(tex %in% "aebr.tex")]
    t = tex[12]
    for (t in tex) {
        cat("\n************  ", t, "  ************\n")
        bt <- sub("\\.tex", "", t)
        tmp <- readLines(t)
        if (any(grepl("begin\\{document\\}", tmp))) {
            s <- system(sprintf("pdflatex -recorder -interaction=nonstopmode %s", 
                bt), intern = T)
            f <- sprintf("%s.fls", bt)
            if (file.exists(f)) {
                fls <- readLines(f)
                fls <- sapply(strsplit(fls, " "), function(x) x[2])
                fls <- sub("^\\./", "", fls)
                fls <- unique(fls)
                fls <- fls[!grepl(ignore, fls)]
                fls <- fls[!grepl(sprintf("^%s", bt), fls)]
                fls <- fls[!(fls %in% normalizePath(fold))]
                alldeps <- c(alldeps, fls)
                cat(paste(fls, collapse = "\n"))
                cat("\n")
            }
            else cat("fls file inexistent. There is a problem with this file...\n")
        }
        else cat("Not a master file. Skip...\n")
    }
    cat("\n\n")
    s <- sapply(alldeps, is.git.tracked)
    nt <- names(s)[!s]
    if (!is.null(nt)) {
        cat("************====  Files not tracked by GIT:  ====************\n")
        cat(paste(nt, collapse = "\n"))
        cat("\n")
    }
    if (save_untracked) 
        write.csv(nt, "untracked-dependencies.csv", row.names = F)
    setwd(prevdir)
}
