lighten <-
function (col, c = 0.5) 
{
    rgbs <- col2rgb(col)
    r <- rgbs["red", ]/255
    g <- rgbs["green", ]/255
    b <- rgbs["blue", ]/255
    rd <- r + c * (1 - r)
    gd <- g + c * (1 - g)
    bd <- b + c * (1 - b)
    return(rgb(rd, gd, bd))
}
