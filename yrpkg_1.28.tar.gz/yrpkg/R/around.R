around <-
function (x, idx, plusminus = 5) 
{
    return(x[(idx - plusminus):(idx + plusminus), ])
}
