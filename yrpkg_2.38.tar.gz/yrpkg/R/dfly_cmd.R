dfly_cmd <-
function (cmd, comps = c("robin", "leon", "titi", "tieke", "frank", 
    "taiko", "tui"), user = "yvan", wait = T) 
{
    cp = comps[1]
    for (cp in comps) {
        cat("*****", cp, "\n")
        cmd2 <- sprintf("ssh -A %s@%s \"%s\"", user, cp, cmd)
        cat(cmd2, "\n\n")
        system(cmd2, wait = wait)
        cat("\n\n")
    }
}
